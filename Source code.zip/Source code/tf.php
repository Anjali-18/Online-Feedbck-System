<?php

$conn=mysqli_connect("localhost","root","","feedback");
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}


session_start();
$sem=$_SESSION['sem'];
$bt=$_SESSION['batch'];
$grno=$_SESSION['grno'];


echo "Sem no:",$sem;
echo "\n Gr no is: ",$grno;
echo "\n Batch is\n",$bt;


$s1q1=$_POST['s1q1'];
echo $s1q1;
$s1q2=$_POST['s1q2'];
$s1q3=$_POST['s1q3'];
$s1q4=$_POST['s1q4'];
$s1q5=$_POST['s1q5'];

$avrS1=($s1q1+$s1q2+$s1q3+$s1q4+$s1q5)/5;
echo "Average1:",$avrS1;

//+++++SUBJECT 2+++++

$s2q1=$_POST['s2q1'];
$s2q2=$_POST['s2q2'];
$s2q3=$_POST['s2q3'];
$s2q4=$_POST['s2q4'];
$s2q5=$_POST['s2q5'];

/*echo $s2q1;
echo $s2q2;*/

$avrS2=($s2q1+$s2q2+$s2q3+$s2q4+$s2q5)/5;
echo "\nAverage 2:",$avrS2;

//+++++SUBJECT 3+++++

$s3q1=$_POST['s3q1'];
$s3q2=$_POST['s3q2'];
$s3q3=$_POST['s3q3'];
$s3q4=$_POST['s3q4'];
$s3q5=$_POST['s3q5'];

/*echo $s2q1;
echo $s2q2;*/

$avrS3=($s3q1+$s3q2+$s3q3+$s3q4+$s3q5)/5;
echo "\nAverage 3:",$avrS3;

//+++++SUBJECT 4+++++
$s4q1=$_POST['s4q1'];
$s4q2=$_POST['s4q2'];
$s4q3=$_POST['s4q3'];
$s4q4=$_POST['s4q4'];
$s4q5=$_POST['s4q5'];

/*echo $s2q1;
echo $s2q2;*/

$avrS4=($s4q1+$s4q2+$s4q3+$s4q4+$s4q5)/5;
echo "\nAverage 4: ",$avrS4;

/*$s5q1=$_POST['s5q1'];
$s5q2=$_POST['s5q2'];
$s5q3=$_POST['s5q3'];
$s5q4=$_POST['s5q4'];
$s5q5=$_POST['s5q5'];*/

/*echo $s2q1;
echo $s2q2;*/

// $avrS5=($s5q1+$s5q2+$s5q3+$s5q4+$s5q5)/5;
// echo $avrS5;


// $s6q1=$_POST['s6q1'];
// $s6q2=$_POST['s6q2'];
// $s6q3=$_POST['s6q3'];
// $s6q4=$_POST['s6q4'];
// $s6q5=$_POST['s6q5'];

// /*echo $s2q1;
// echo $s2q2;*/

// $avrS6=($s6q1+$s6q2+$s6q3+$s6q4+$s6q5)/5;
// echo $avrS6;

//+++ELECTIVE 1+++
$s7q1=$_POST['s7q1'];
$s7q2=$_POST['s7q2'];
$s7q3=$_POST['s7q3'];
$s7q4=$_POST['s7q4'];
$s7q5=$_POST['s7q5'];

$avrS7=($s7q1+$s7q2+$s7q3+$s7q4+$s7q5)/5;
echo "\nElective :",$avrS7;

$theory_total_avg=($avrS1+$avrS2+$avrS3+$avrS4+$avrS7)/5;
echo"\n Total avg is: ",$theory_total_avg;

// $s8q1=$_POST['s8q1'];
// $s8q2=$_POST['s8q2'];
// $s8q3=$_POST['s8q3'];
// $s8q4=$_POST['s8q4'];
// $s8q5=$_POST['s8q5'];

// $avrS8=($s8q1+$s8q2+$s8q3+$s8q4+$s8q5)/5;
// echo $avrS8;


//THEORY FEEDBACK
if($sem==6)
{	
	$qn_val="INSERT INTO theoryfeed_sem6(`grno`, `s1q1`, `s1q2`, `s1q3`, `s1q4`, `s1q5`,
								 		`s2q1`, `s2q2`, `s2q3`, `s2q4`, `s2q5`, 
								 		`s3q1`, `s3q2`, `s3q3`, `s3q4`, `s3q5`, 
								 		`s4q1`, `s4q2`, `s4q3`, `s4q4`, `s4q5`, 
								 		`s5q1`, `s5q2`, `s5q3`, `s5q4`, `s5q5`) VALUES 
								('$grno','$s1q1','$s1q2','$s1q3','$s1q4','$s1q5',
										'$s2q1','$s2q2','$s2q3','$s2q4','$s2q5',
										'$s3q1','$s3q2','$s3q3','$s3q4','$s3q5',
										'$s4q1','$s4q2','$s4q3','$s4q4','$s4q5',
										'$s7q1','$s7q2','$s7q3','$s7q4','$s7q5')";

	$qn_save=mysqli_query($conn,$qn_val);
	

	$sql="INSERT INTO theory_avg_sem6(`grno`,`sub1`,`sub2`,`sub3`,`sub4`,`sub5`,`total_avg`)VALUES ('$grno','$avrS1','$avrS2','$avrS3','$avrS4','$avrS7','$theory_total_avg')";
	$result=mysqli_query($conn,$sql) or die(mysqli_error($conn));

}else
{
	if($sem==5)
	{
		$qn_val="INSERT INTO theoryfeed_sem5(`grno`, `s1q1`, `s1q2`, `s1q3`, `s1q4`, `s1q5`,
								 		`s2q1`, `s2q2`, `s2q3`, `s2q4`, `s2q5`, 
								 		`s3q1`, `s3q2`, `s3q3`, `s3q4`, `s3q5`, 
								 		`s4q1`, `s4q2`, `s4q3`, `s4q4`, `s4q5`, 
								 		`s5q1`, `s5q2`, `s5q3`, `s5q4`, `s5q5`) VALUES 
								('$grno','$s1q1','$s1q2','$s1q3','$s1q4','$s1q5',
										'$s2q1','$s2q2','$s2q3','$s2q4','$s2q5',
										'$s3q1','$s3q2','$s3q3','$s3q4','$s3q5',
										'$s4q1','$s4q2','$s4q3','$s4q4','$s4q5',
										'$s7q1','$s7q2','$s7q3','$s7q4','$s7q5')";

		$qn_save=mysqli_query($conn,$qn_val);
		

		$sql="INSERT INTO theory_avg_sem5(`grno`,`sub1`,`sub2`,`sub3`,`sub4`,`sub5`,`total_avg`)VALUES ('$grno','$avrS1','$avrS2','$avrS3','$avrS4','$avrS7','$theory_total_avg')";
		$result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
	}

}
//-------------------------------------
//PRACTICAL FEEDBACK

//+++PRACTICAL 1+++
// $p1q1=$_POST['p1q1'];
// $p1q2=$_POST['p1q2'];
// $p1q3=$_POST['p1q3'];
// $p1q4=$_POST['p1q4'];

// $avrP1=($p1q1+$p1q2+$p1q3+$p1q4)/4;
// echo "\nPractical 1",$avrP1;

// //+++PRACTICAL 2+++
// $p2q1=$_POST['p2q1'];
// $p2q2=$_POST['p2q2'];
// $p2q3=$_POST['p2q3'];
// $p2q4=$_POST['p2q4'];

// $avrP2=($p2q1+$p2q2+$p2q3+$p2q4)/4;
// echo "\nPractical 2:",$avrP2;


// //+++PRACTICAL 3+++
// $p3q1=$_POST['p3q1'];
// $p3q2=$_POST['p3q2'];
// $p3q3=$_POST['p3q3'];
// $p3q4=$_POST['p3q4'];

// $avrP3=($p3q1+$p3q2+$p3q3+$p3q4)/4;
// echo "\n Practical 3:",$avrP3;

// //+++PRACTICAL 4+++
// $p4q1=$_POST['p4q1'];
// $p4q2=$_POST['p4q2'];
// $p4q3=$_POST['p4q3'];
// $p4q4=$_POST['p4q4'];

// $avrP4=($p4q1+$p4q2+$p4q3+$p4q4)/4;
// echo "\n Practical 4:",$avrP4;

// //+++PRACTICAL 5+++
// $p5q1=$_POST['p5q1'];
// $p5q2=$_POST['p5q2'];
// $p5q3=$_POST['p5q3'];
// $p5q4=$_POST['p5q4'];

// $avrP5=($p5q1+$p5q2+$p5q3+$p5q4)/4;
// echo "\n Practical 5:",$avrP5;

// // total_avg=($avrP1+$avrP2+$avrP3+$avrP4+$avrP5)/5;
// // echo "Total avg is:",$total_avg;
// $prac_total_avg=($avrP1+$avrP2+$avrP3+$avrP4+$avrP5)/5;
//  echo "Total avg is:",$prac_total_avg;

// if($sem==6)
// {	
// 	$qn_val="INSERT INTO pracfeed_sem5(`grno`, `p1q1`, `p1q2`, `p1q3`, `p1q4`, 
// 													`p2q1`, `p2q2`, `p2q3`, `p2q4`, 
// 													`p3q1`, `p3q2`, `p3q3`, `p3q4`, 
// 													`p4q1`, `p4q2`, `p4q3`, `p4q4`, 
// 													`p5q1`, `p5q2`, `p5q3`, `p5q4`) VALUES (
// 											'$grno','$p1q1','$p1q2','$p1q3','$p1q4',
// 													'$p2q1','$p2q2','$p2q3','$p2q4',
// 													'$p3q1','$p3q2','$p3q3','$p3q4',
// 													'$p4q1','$p4q2','$p4q3','$p4q4',
// 													'$p5q1','$p5q2','$p5q3','$p5q4'";

// 		$qn_save=mysqli_query($conn,$qn_val);
	

// 	$sql="INSERT INTO prac_avg_sem6(`grno`,`sub1`,`sub2`,`sub3`,`sub4`,`sub5`,`total_avg`)VALUES ('$grno','$avrP1','$avrP2','$avrP3','$avrP4','$avrP5','$prac_total_avg')";
// 	$result=mysqli_query($conn,$sql) or die(mysqli_error($conn));

// }else
// {
// 	if($sem==5)
// 	{
// 		$qn_val="INSERT INTO pracfeed_sem6(`grno`,`batch`, `p1q1`, `p1q2`, `p1q3`, `p1q4`, 
// 															`p2q1`, `p2q2`, `p2q3`, `p2q4`, 
// 															`p3q1`, `p3q2`, `p3q3`, `p3q4`, 
// 															`p4q1`, `p4q2`, `p4q3`, `p4q4`, 
// 															`p5q1`, `p5q2`, `p5q3`, `p5q4`) VALUES (
// 											'$grno',''$bt', '$p1q1','$p1q2','$p1q3','$p1q4',
// 															'$p2q1','$p2q2','$p2q3','$p2q4',
// 															'$p3q1','$p3q2','$p3q3','$p3q4',
// 															'$p4q1','$p4q2','$p4q3','$p4q4',
// 															'$p5q1','$p5q2','$p5q3','$p5q4'";

// 		$qn_save=mysqli_query($conn,$qn_val);
		

// 		$sql="INSERT INTO prac_avg_sem5(`grno`,`sub1`,`sub2`,`sub3`,`sub4`,`sub5`,`total_avg`)VALUES ('$grno','$avrP1','$avrP2','$avrP3','$avrP4','$avrP5','$prac_total_avg')";
// 		$result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
// 	}

// }

// //-------------------------------------
// //Libraryyyy


// $libq1=$_POST['libq1'];
// $libq2=$_POST['libq2'];
// $libq3=$_POST['libq3'];
// $libq4=$_POST['libq4'];

// $library_avg=(($libq1+$libq2+$libq3+$libq4)/5);
// echo "Library avg is: ",$library_avg;

// $lib="INSERT INTO library_feedback(`grno`, `sem`, `q1`, `q2`, `q3`, `q4`, `avg`) VALUES ('$grno','$sem','$libq1','$libq2','$libq3','$libq4','$library_avg')";



//-------------------------------------
//Other facilities ka feedback
/*

write code here. . . 

*/

?>