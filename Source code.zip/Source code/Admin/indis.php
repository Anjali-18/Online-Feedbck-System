<!DOCTYPE html>
<html>
<head>
	<title>display</title>

	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<style type="text/css">
	.colr{
		color: yellow;
	}
	.co{
		color: blue;
	}
</style>

</head>
<body>
	<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="indis.php">Student information</a>
          <a class="dropdown-item" href="dispoint.php">Student Marks</a>
        </div>
      </li>
       <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Subject
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="theory_display.php">Regular subject</a>
          <a class="dropdown-item" href="Displayelec.php">Elective subject</a>
          <a class="dropdown-item" href="Displayprac.php">Practical subject</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Diselecdetail.php">Elective details</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.html">Log out</a>
      </li>
     
    </ul>
  </div>
 </nav>
 <!-- navbar end -->
	<div>
		<h3 class="mt-5 text-center bg-dark text colr">STUDENT INFORMATION</h3>
		<br>
		<!-- <button id="displayinfo" class="btn btn-danger">Display</button>

 -->
		<table class="table table-striped table-bordered text-center">
			<thead>
				<th class="co">GR NO.</th>
				<th class="co">Name</th>
				<th class="co">phone NO</th>
				<th class="co">Admission yr</th>
				<th class="co">DOB</th>
				<th class="co">Age</th>
				<th class="co">Dept</th>
				<th class="co">Bloodgp</th>
				<th class="co">caste</th>
				<th class="co">Subcaste</th>
			</thead>
			<tbody id="response">
				
			</tbody>
		</table>
		<section>
			<center><button class="btn btn-success" onclick="window.location.href ='info.php';">Export To Excel</button>
		</center></section>
	</div>

	<script type="text/javascript">
		$(document).ready(function(){
			var from=$('#myform');
			$('#submit').click(function(){
				$.ajax(
				{
					url:from.attr("action"),
					type:'post',
					data:$("#myform input").serialize(),

					success:function(data){
						console.log(data);
					}

				});
			});
		

			Display();
		/*$('#displayinfo').click(function(){*/
			function Display(){
			$.ajax({
				url:'displayinfo.php',
				type:'post',

				success:function(responsedata){
					$('#response').html(responsedata);
				}
			});
		}
		/*});*/
	});

	</script>

</body>
</html>