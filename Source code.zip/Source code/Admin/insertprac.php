<?php

include 'conn.php';

if(isset($_POST['done'])){
$Sr_no = $_POST['sr_no'];
 $Sem = $_POST['Sem'];
 $Batch=$_POST['Batch'];
 $Subject=$_POST['Subject'];
 $Faculty = $_POST['Faculty'];
 $q = " INSERT INTO pracs (sr_no,sem,batch,subject_name,faculty_name) VALUES ('$Sr_no','$Sem','$Batch','$Subject','$Faculty')";

 $query = mysqli_query($con,$q);
 header('location:Displayprac.php');
}

?>

<!DOCTYPE html>
<html>
<head>
 <title></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">  Insert Operation </h1>
 </div><br>

 <label> Sr_no: </label>
 <input type="text" name="sr_no" class="form-control"> <br>

 <label> Sem: </label>
 <input type="text" name="Sem" class="form-control"> <br>
  <label> Batch: </label>
 <input type="text" name="Batch" class="form-control"> <br>
  <label> Subject: </label>
 <input type="text" name="Subject" class="form-control"> <br>
  <label> Faculty: </label>
 <input type="text" name="Faculty" class="form-control"> <br>
 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>

 </div>
 </form>
 </div>
</body>
</html>