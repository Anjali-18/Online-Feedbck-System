<?php

include 'conn.php';

if(isset($_POST['done'])){

 $sr_no=$_GET['sr_no'];
 $sem = $_POST['sem'];
 $batch=$_POST['batch'];
 $subject_name = $_POST['subject_name'];
 $faculty_name=$_POST['faculty_name'];

 $q = " INSERT INTO pracs (sr_no,sem,batch,subject_name,faculty_name) VALUES ($sr_no,$sem,$batch,'$subject_name','$faculty_name')";
 echo $q;
 $query = mysqli_query($conn,$q);
 header('location:Displayprac.php');
}
?>

<!DOCTYPE html>
<html>
<head>
 <title></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">  Insert Operation </h1>
 </div><br>

 <label> Sr_no: </label>
 <input type="text" name="sr_no" id="srno" class="form-control" required>
 <h6 id="srnocheck"></h6>
  <br>

 <label> Sem: </label>
 <input type="text" name="sem" id="psem" class="form-control" required>
 <h6 id="semcheck"></h6>
 <br>

 <label> Batch: </label>
 <input type="text" name="batch" id="pbatch" class="form-control" required>
 <h6 id="batcheck"></h6>
 <br>

 <label> Subject Name: </label>
 <input type="text" name="subject_name" id="psubname" class="form-control" required>
 <h6 id="subnamecheck"></h6>
 <br>

 <label> Faculty_name: </label>
 <input type="text" name="faculty_name" id="pfacname" class="form-control" required>
 <h6 id="facnamecheck"></h6>
 <br>

 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>

 </div>
 </form>
 </div>

 <script type="text/javascript">
 	$(document).ready(function(){
 		$('#srnocheck').hide();
 		$('#semcheck').hide();
 		$('#batcheck').hide();
 		$('#subnamecheck').hide();
 		$('#facnamecheck').hide();

 		var srno_err=true;
 		var sem_err=true;
 		var batch_err=true;
 		var subname_err=true;
 		var facname_err=true;

 		$('#srno').keyup(function(){
 			srno_check();
 		})
 		function srno_check(){
 			var srno_val= $('#srno').val();

 			if(isNaN(srno_val)){
 				$('#srnocheck').show();
 				$('#srnocheck').html("*Please enter valid Semester number");
 				$('#srnocheck').focus();
 				$('#srnocheck').css("color","red");
 				srno_err=false;
 				return false;
 			}else{
 				$('#srnocheck').hide();
 			}

 		}

 		$('#psem').keyup(function(){
 			sem_check();
 		})
 		function sem_check(){
 			var sem_val= $('#psem').val();

 			if(isNaN(sem_val)){
 				$('#semcheck').show();
 				$('#semcheck').html("*Please enter valid Semester number");
 				$('#semcheck').focus();
 				$('#semcheck').css("color","red");
 				sem_err=false;
 				return false;
 			}else{
 				$('#semcheck').hide();
 			}

 			if(sem_val.length>1){
 				$('#semcheck').show();
 				$('#semcheck').html("*Please enter valid Semester number");
 				$('#semcheck').focus();
 				$('#semcheck').css("color","red");
 				sem_err=false;
 				return false;
 			}else{
 				$('#semcheck').hide();
 			}
 		}

 		$('#pbatch').keyup(function(){
 			batch_check();
 		})
 		function batch_check(){
 			var batch_val= $('#pbatch').val();

 			if(isNaN(batch_val)){
 				$('#batcheck').show();
 				$('#batcheck').html("*Please enter valid Semester number");
 				$('#batcheck').focus();
 				$('#batcheck').css("color","red");
 				batch_err=false;
 				return false;
 			}else{
 				$('#batcheck').hide();
 			}

 			if(batch_val.length>1){
 				$('#batcheck').show();
 				$('#batcheck').html("*Please enter valid Semester number");
 				$('#batcheck').focus();
 				$('#batcheck').css("color","red");
 				batch_err=false;
 				return false;
 			}else{
 				$('#batcheck').hide();
 			}
 		}

 		$('#psubname').keyup(function(){
 			subname_check();
 		})
 		function subname_check(){
 			var subname_val=$('#psubname').val();

 			if(!isNaN(subname_val)){
 				$('#subnamecheck').show();
 				$('#subnamecheck').html("*Please Enter valid subject name.");
 				$('#subnamecheck').focus();
 				$('#subnamecheck').css("color","red");
 				subname_err=false;
 				return false;
 			}else{
 				$('#subnamecheck').hide();
 			}
 		}

 		$('#pfacname').keyup(function(){
 			facname_check();
 		})
 		function facname_check(){
 			var facname_val=$('#pfacname').val();

 			if(!isNaN(facname_val)){
	 			$('#facnamecheck').show();
	 			$('#facnamecheck').html("*Please enter valid Faculty name");
	 			$('#facnamecheck').focus();
	 			$('#facnamecheck').css("color","red");
	 			facname_err=false;
	 			return false;
	 		}else{
	 			$('facnamecheck').hide();
	 		}
	 	}

 	})
 </script>
</body>
</html>
