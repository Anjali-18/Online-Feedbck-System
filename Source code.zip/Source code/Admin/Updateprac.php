<?php

 include 'conn.php';

 if(isset($_POST['done'])){

 $Sr_no = $_GET['sr_no'];
/* $Sem = $_POST['Sem'];
 $Batch=$_POST['Batch'];
 $Subject=$_POST['Subject'];*/
 $Faculty = $_POST['Faculty'];
 $q = "UPDATE pracs set faculty_name='$Faculty' where sr_no=$Sr_no ";
echo "$q";
 $query = mysqli_query($conn,$q);

 header('location:Displayprac.php');
 }

?>

<!DOCTYPE html>
<html>
<head>
 <title></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">  Update Operation </h1>
 </div><br>

 <!-- <label> Sr_no: </label>
 <input type="text" name="Sr_no" class="form-control"> <br>

 <label> Sem: </label>
 <input type="text" name="Sem" class="form-control"> <br>
  <label> Batch: </label>
 <input type="text" name="Batch" class="form-control"> <br>
  <label> Subject: </label>
 <input type="text" name="Subject" class="form-control"> <br> -->

 <label> Faculty: </label>
 <input type="text" name="Faculty" id="facname" class="form-control"> 
 <h6 id="facnamecheck"></h6>
 <br>

 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>

 </div>
 </form>
 </div>

 <script type="text/javascript">
 	$('document').ready(function(){
 		$('#facnamecheck').hide();

 		var facname_err=true;

 		$('#facname').keyup(function(){
 			facname_check();
 		})
 		function facname_check(){
 			var facname_val=$('#facname').val();

	 		if(!isNaN(facname_val)){
	 			$('#facnamecheck').show();
	 			$('#facnamecheck').html("**Please enter valid faculty name");
	 			$('#facnamecheck').focus();
	 			$('#facnamecheck').css("color","red");
	 			facname_err=false;
	 			return false;
	 		}else{
	 			$('facnamecheck').hide();
	 		}
 		}
 	})

 </script>
</body>
</html>