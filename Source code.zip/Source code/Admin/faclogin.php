<?php
$grno = $_POST["grno"];
$pass = $_POST["password"];

$conn=mysqli_connect("localhost","root","","feedback");
if(!$conn){
	die("connection_failed:".mysqli_connect_error());

}

$sql="select  id,password from facregi where id='$grno' and password='$pass'";
$result=mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
    
	echo '<script>
    		 alert("Login successfully");
    		 window.location="Admin/main1.html";
    		</script>
    		';


}else{
	echo'<script>
    		 alert("Login Failed");
    		 window.location = "faclogin.html";
    	</script>';
}
mysqli_close($conn);

?>