<?php

$servername="localhost";
	$username="root";
	$password="";
	$dbname="feedback";
$conn=new mysqli($servername,$username,$password,$dbname);

$sql="SELECT * FROM  elecdetail ORDER BY grno ASC";
$query=mysqli_query($conn,$sql);
if(mysqli_num_rows($query)>0){
	while($result=mysqli_fetch_array($query)){
		?>
		<tr>
			<td><?php echo $result['grno'] ?></td>
			<td><?php echo $result['name'] ?></td>
			<td><?php echo $result['sem'] ?></td>
			<td><?php echo $result['batch'] ?></td>
			<td><?php echo $result['elective_subject1'] ?></td>
			<td><?php echo $result['faculty_name1'] ?></td>
			<td><?php echo $result['elective_subject2'] ?></td>
			<td><?php echo $result['faculty_name2'] ?></td>
		</tr>
<?php
	}
}
?>
