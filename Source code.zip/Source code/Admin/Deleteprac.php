<?php

include 'conn.php';

$sr_no = $_GET['sr_no'];

$q = "DELETE FROM pracs WHERE sr_no = '$sr_no'";
echo $q;
mysqli_query($conn,$q);

header('location:Displayprac.php');

?>