<?php

	$servername="localhost";
	$username="root";
	$password="";
	$dbname="feedback";	

	$conn=new mysqli($servername,$username,$password,$dbname); 
	 if($conn->connect_error)
	 {
	 	die("connectivity Error:".$conn->connect_error);
	 }

	if(isset($_POST['register'])){
		session_start();
	// $_SESSION['full_name']=$full_name;

	$full_name=$_POST['full_name'];
	$email=$_POST['email'];
	$grno=$_POST['grno'];
	$Branch=$_POST['Branch'];
	$Adyr=$_POST['Adyr'];
	$pass=$_POST['confirmPassword'];

	$sql_u= "SELECT* FROM registration WHERE full_name='$full_name' ";
	/*echo $sql_u;*/
	$sql_e= "SELECT * FROM registration WHERE email='$email' ";
	$sql_g= "SELECT * FROM registration WHERE grno='$grno' ";
	$res_u=mysqli_query($conn, $sql_u);
	$res_e=mysqli_query($conn, $sql_e);
	$res_g=mysqli_query($conn, $sql_g);
	
	if(mysqli_num_rows($res_u)> 0 && mysqli_num_rows($res_g)> 0){
		$name_error= "User name already exist... ";
	}
	if(mysqli_num_rows($res_e)> 0){
		$email_error="Email already exiest...";
	}
	if(mysqli_num_rows($res_g)> 0){
		$grno_error="Grno already exist";
	}
	else{

	 $sql="insert into registration(grno,full_name,email,Branch,Adyr,password)values('$grno','$full_name','$email','$Branch','$Adyr','".md5($pass)."')";

	 if(mysqli_query($conn,$sql)){
	 /*	echo'sweetalert('Congratulations!', 'Your message has been successfully sent', 'success')';
	*//*echo '<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<script> swal({
                    title:"successfully submitted",
                    icon:"success",
                    button:"ok",
                      
                }).then(function() {
                window.location = "login.html";
                      });
	 	</script>';*/
	 	echo'<script>alert("Registration successfully");
            window.location = "login.html";
            </script>';
	 }
	 else
	 {
	 	echo '<script>alert("You have already registered ");
            window.location = "login.html";
            </script>';
	 }
	}
	}

	 $conn->close();
?>
