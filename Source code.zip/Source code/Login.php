<?php
$grno = $_POST["grno"];
$pass = $_POST["password"];


session_start();
   $_SESSION['grno'] = "$grno";

$conn=mysqli_connect("localhost","root","","feedback");
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}
$sql="select grno,password from registration where grno='$grno' and password='$pass'";
$result=mysqli_query($conn,$sql);


if(mysqli_num_rows($result)>0){
    
	echo '<script>
    		 confirm("Login successfully");
    		 window.location="main.html";
    		</script>
    		';


}else{
	echo'<script>
    		 alert("Login Failed");
    		 window.location = "Login.html";
    	</script>';
}
mysqli_close($conn);

?>

	
