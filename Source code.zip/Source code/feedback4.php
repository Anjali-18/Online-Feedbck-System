<?php
session_start();
$sem=$_SESSION['sem'];
$bt=$_SESSION['batch'];
$grno=$_SESSION['grno'];

$_SESSION['grno']=$grno;
echo $grno;
?> 


<!DOCTYPE html>
<html>
<head>
    <title></title>
      <link rel="stylesheet" class="bootswatcher" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/yeti/bootstrap.min.css" />
    <link href="css.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- Ajax Query -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquer0y.min.js"></script>
    </head>
    <body>
        <nav class="navbar navbar-default" role="navigation">
            <div class="container-fluid"> 
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="#"><img src="//www.sce.edu.in/files/images/revera.png" height="45" class="pull-left" style="margin:  -15px 10px 0 10px;" />Saraswati College of Engineering</a>
                </div>
            </div>
            <!-- /.container-fluid -->
        </nav>

<style>
    .color{
        color: blue;
    }
</style>

<script>
    $(document).ready(function(){

         if ('3'== <?php echo $sem ?>)
        {
            $("#e1").hide();
            $("#e2").hide();
        }

         if ('4'== <?php echo $sem ?>)
        {
            $("#e1").hide();
            $("#e2").hide();
        }

        if ('5'== <?php echo $sem ?>)
        {
            $("#t6").hide();
            $("#e2").hide();
            $("#p5").hide();
        }

        if ('6'== <?php echo $sem ?>)
        {
            $("#t5").hide();
            $("#t6").hide();
            $("#e2").hide();
        }


        if ('7'== <?php echo $sem ?>)
        {
            $("#t4").hide();
            $("#t5").hide();
            $("#t6").hide();
        }

        if ('8'== <?php echo $sem ?>)
        {
            $("#t4").hide();
            $("#t5").hide();
            $("#t6").hide();
        }

        });
</script>

</head>
<body>
 
    


<div class="container">
    <div class="clearfix"></div>
    <h3 style="text-align: center; margin: 30px; color: green;">Student Feedback</h3>
     <p class="pull-left well color">
TE A Computer Engineering    </p>
    <p class="pull-right well  color">Date : <?php echo date("D, d-M-yy")."\n"; ?></p>
    <div class="clearfix"></div>
  <ul class="nav nav-tabs" role="tablist" style="text-align:center">
    <li class="active"><a data-toggle="tab" href="#Theory">Theory Feedback</a></li>
    <li><a data-toggle="tab" href="#Practical">Practical Feedback</a></li>
    <li><a data-toggle="tab" href="#Library">Library Feedback</a></li>
    <li><a data-toggle="tab" href="#Other">Other Feedback</a></li>
  </ul>

<div class="tab-content">
    <div id="Theory" class="tab-pane fade in active">
        <form action="tf.php" method="POST">
                <?php include('feed.php');
                            $sql="select subject_name from theory_subjects where sem_no=$sem";
                            $query=mysqli_query($conn, $sql);
                            $datas= array();
                            if(mysqli_num_rows($query)>0){
                                while($row= mysqli_fetch_assoc($query)){
                                    $datas[]= $row;
                                }}

                            
                            $sql1="select faculty_name from theory_subjects where sem_no=$sem";
                            $query1=mysqli_query($conn, $sql1);
                            $datas1= array();
                            if(mysqli_num_rows($query1)>0){
                                while($row1= mysqli_fetch_assoc($query1)){
                                    $datas1[]= $row1;
                                }
                            }

                            $sql2="select elective_subject1 from elecdetail where sem=$sem";
                            $query2=mysqli_query($conn, $sql2);
                            $datas2= array();
                            if(mysqli_num_rows($query2)>0){
                                while($row2= mysqli_fetch_assoc($query2)){
                                    $datas2[]= $row2;
                                }
                            }
                            $sql3="select faculty_name1 from elecdetail where sem=$sem";
                            $query3=mysqli_query($conn, $sql3);
                            $datas3= array();
                            if(mysqli_num_rows($query3)>0){
                                while($row3= mysqli_fetch_assoc($query3)){
                                    $datas3[]= $row3;
                                }
                            }

                            $sql4="select elective_subject2 from elecdetail where sem=$sem";
                            $query4=mysqli_query($conn, $sql4);
                            $datas4= array();
                            if(mysqli_num_rows($query4)>0){
                                while($row4= mysqli_fetch_assoc($query4)){
                                    $datas4[]= $row4;
                                }
                            }

                            $sql5="select faculty_name2 from elecdetail where sem=$sem";
                            $query5=mysqli_query($conn, $sql5);
                            $datas5= array();
                            if(mysqli_num_rows($query5)>0){
                                while($row5= mysqli_fetch_assoc($query5)){
                                    $datas5[]= $row5;
                                }
                            }
                            //print_r($datas);
                ?>
                <div id="t1">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                        <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas[0] as $data){echo $data;}?></h5>
                                <h4 class="mb-4"><?php foreach($datas1[0] as $data1){echo $data1;}?></h4>
                            </div><br>
                            <input type='hidden' name='fac1' value="tf1" />
                            <input type='hidden' name='sub1' value="ts1" />
                            <div class="form-group mt-4">
                                <select name="s1q1" class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class="form-group mt-4">
                                <select name="s1q2" class='form-control  mt-4'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name="s1q3" class='form-control '>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name="s1q4" class='form-control '>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name="s1q5" class='form-control '>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>

                </div>

                <div id="t2">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div> 
                        <div class='col-md-4 '>
                            <div class="fac mt-4">
                                <h5><?php foreach($datas[1] as $data){echo $data;}?></h5>
                                <h4><?php foreach($datas1[1] as $data1){echo $data1;}?></h4>
                            </div><br>
                            <input type='hidden' name='fac2' value='6542' />
                            <input type='hidden' name='sub2' value='SE' />
                            <div class='form-group'>
                                <select name='s2q1' class='form-control '>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s2q2' class='form-control '>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s2q3' class='form-control '>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s2q4' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s2q5' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="t3">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                         <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas[2] as $data){echo $data;}?></h5>
                                <h4><?php foreach($datas1[2] as $data1){echo $data1;}?></h4>
                            </div><br>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='s3q1' class='form-control '>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s3q2' class='form-control '>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s3q3' class='form-control '>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s3q4' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s3q5' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

               <div id="t4">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                         <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas[3] as $data){echo $data;}?></h5>
                                <h4><?php foreach($datas1[3] as $data1){echo $data1;}?></h4>
                            </div><br>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='s4q1' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s4q2' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s4q3' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s4q4' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s4q5' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
               </div>

                <div id="t5">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                         <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas[4] as $data){echo $data;}?></h5>
                                <h4><?php foreach($datas1[4] as $data1){echo $data1;}?></h4>
                            </div><br>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='s5q1' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s5q2' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s5q3' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s5q4' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s5q5' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="t6">
                    <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                         <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas[5] as $data){echo $data;}?></h5>
                                <h4><?php foreach($datas1[5] as $data1){echo $data1;}?></h4>
                            </div><br>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='s6q1' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s6q2' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s6q3' class='form-control '>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s6q4' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s6q5' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="e1">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                        <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas2[0] as $data2){echo $data2;}?></h5>
                                <h4><?php foreach($datas3[0] as $data3){echo $data3;}?></h4>
                            </div><br>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='s7q1' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s7q2' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s7q3' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s7q4' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s7q5' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>

                </div>

               <div id="e2">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                        <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas4[0] as $data4){echo $data4;}?></h5>
                                <h4><?php foreach($datas5[0] as $data5){echo $data5;}?></h4>
                            </div><br>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='s8q1' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s8q2' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s8q3' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s8q4' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s8q5' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>

               </div>

               <div class="row">

                   <center><button class="btn-success btn">Submit</button></center>

               </div>

</form>
</div>

<div id="Practical" class="tab-pane fade">
<form action="" method="POST">

                <?php
                    $sql4="select subject_name from pracs where sem='$sem' and batch='$bt'";
                    //echo $sql4;
                    $query4=mysqli_query($conn, $sql4);
                    $datas4= array();
                    if(mysqli_num_rows($query4)>0){
                        while($row4= mysqli_fetch_assoc($query4)){
                                    $datas4[]= $row4;
                            }
                    }   
                    //print_r($datas4);
                    $sql5="select faculty_name from pracs where sem='$sem' and batch='$bt'";
                    $query5=mysqli_query($conn, $sql5);
                    $datas5= array();
                    if(mysqli_num_rows($query5)>0){
                        while($row5= mysqli_fetch_assoc($query5)){
                                    $datas5[]= $row5;
                            }
                    }          
       

                ?>

                <div id="p1">
                <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>               
                </ol>
                </div>
                         <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas4[0] as $data4){echo $data4;}?></h5>
                                <h4><?php foreach($datas5[0] as $data5){echo $data5;}?></h4>
                            </div>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="p2">
                <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>               
                </ol>
                </div>
                         <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas4[1] as $data4){echo $data4;}?></h5>
                                <h4><?php foreach($datas5[1] as $data5){echo $data5;}?></h4>
                            </div>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="p3">
                <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>               
                </ol>
                </div>
                         <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas4[2] as $data4){echo $data4;}?></h5>
                                <h4><?php foreach($datas5[2] as $data5){echo $data5;}?></h4>
                            </div>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="p4">
                <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>               
                </ol>
                </div>
                         <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas4[3] as $data4){echo $data4;}?></h5>
                                <h4><?php foreach($datas5[3] as $data5){echo $data5;}?></h4>
                            </div>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="p5">
                <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>               
                </ol>
                </div>
                        <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5><?php foreach($datas4[4] as $data4){echo $data4;}?></h5>
                                <h4><?php foreach($datas5[4] as $data5){echo $data5;}?></h4>
                            </div>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control '>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>

                </div>
    
</form>
</div>

    <div id="Library" class="tab-pane fade">
        <form action="" method="POST">
            <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol >
                    <li>Availability of books set / issue</li>
                    <li>Adequate seating arrangement</li>
                    <li>Digital library/National internal journal</li>
                    <li>Other reading facility</li>  
                </ol>
                </div>
                        <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5></h5>
                                <h4></h4>
                            </div>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
        </form>        

</div>

    <div id="Other" class="tab-pane fade">
      <form action="" method="POST">
           <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Conveyence</li>
                    <li>Girl/Boys Room</li>
                    <li>Lift Facilities</li>
                    <li>Classrooms</li>
                    <li>Gymkhana</li>
                    <li>Student Activities</li>
                    <li>Canteen</li>
                    <li>Drinking Water</li>
                    <li>Account section</li>
                    <li>Student Section</li>
                    <li>Internet Facilities</li>
                    <li>Exam Section</li>
                </ol>
                </div>
                        <div class='col-md-4 item active'>
                            <div class="fac">
                                <h5></h5>
                                <h4></h4>
                            </div>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='6542[]' class='form-control'>
                                    <option value='xx'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>

      </form>         

    </div>
  </div>
</div>


</body>
</html>



