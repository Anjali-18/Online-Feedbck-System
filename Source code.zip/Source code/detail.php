<?php
$grno = $_POST["grno"];
$pass = $_POST["password"];
$batch=$_POST["batch"];
$sem=$_POST["sem"];


session_start();
   $_SESSION['grno'] = $grno;
   $_SESSION['batch']=$batch;
   $_SESSION['sem']=$sem;


$conn=mysqli_connect("localhost","root","","feedback");
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}
$sql="select grno,password from registration where grno='$grno' and password='$pass'";
$result=mysqli_query($conn,$sql);


if(mysqli_num_rows($result)>0){
    
	echo '<script>
    		 confirm("Login successfully");
    		 window.location="feedback4.php";
    		</script>
    		';


}else{
	echo'<script>
    		 alert("Login Failed");
    		 window.location = "detail.html";
    	</script>';
}
mysqli_close($conn);

?>

	
