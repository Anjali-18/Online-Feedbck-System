<?php
	
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="feedback";

	$e1=$_POST['e1'];
	$e2=$_POST['e2'];
	$e3=$_POST['e3'];
	$e4=$_POST['e4'];
	$bt=$_POST['bt'];
	$elec=$_POST['elec'];

	if($elec==1)
	{
		$e3='none';
		$e4='none';
	}

	session_start();
	$grno=$_SESSION['grno'];
	$name=$_SESSION['name'];
	$sem=$_SESSION['sem'];
	$_SESSION['bt']=$bt;

	
	$conn=new mysqli($servername, $username, $password, $dbname);
	if ($conn->connect_error){
		die("Connection failed:" .$conn->connect_error);
	}
	else
	{
			$sql="insert into elecdetail (grno,name,sem,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2) VALUES ('$grno', '$name', '$sem', '$bt', '$e1', '$e2', '$e3', '$e4')";
			if(mysqli_query($conn,$sql))
			{
				echo "success";
			}
			else{
				die("Error:".mysqli_connect_error());
			}
	}
	
?>