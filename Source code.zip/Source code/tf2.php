<?php

session_start()
$grno=$_SESSION['grno'];
echo grno;

$conn=mysqli_connect("localhost","root","","feedback");
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}

	/*$sql="Select * from stuinfo where grno='$grno'";
	echo $sql;
	$result=mysqli_query($conn,$sql);
	echo $result;*/


$s1q1=$_POST['s1q1'];
$s1q2=$_POST['s1q2'];
$s1q3=$_POST['s1q3'];
$s1q4=$_POST['s1q4'];
$s1q5=$_POST['s1q5'];

/*echo $s1q1;
echo $s1q2;*/

$avrS1=($s1q1+$s1q2+$s1q3+$s1q4+$s1q5)/5;
echo $avrS1;

$s2q1=$_POST['s2q1'];
$s2q2=$_POST['s2q2'];
$s2q3=$_POST['s2q3'];
$s2q4=$_POST['s2q4'];
$s2q5=$_POST['s2q5'];

/*echo $s2q1;
echo $s2q2;*/

$avrS2=($s2q1+$s2q2+$s2q3+$s2q4+$s2q5)/5;
echo $avrS2;

$s3q1=$_POST['s3q1'];
$s3q2=$_POST['s3q2'];
$s3q3=$_POST['s3q3'];
$s3q4=$_POST['s3q4'];
$s3q5=$_POST['s3q5'];

/*echo $s2q1;
echo $s2q2;*/

$avrS3=($s3q1+$s3q2+$s3q3+$s3q4+$s3q5)/5;
echo $avrS3;


$s4q1=$_POST['s4q1'];
$s4q2=$_POST['s4q2'];
$s4q3=$_POST['s4q3'];
$s4q4=$_POST['s4q4'];
$s4q5=$_POST['s4q5'];

/*echo $s2q1;
echo $s2q2;*/

$avrS4=($s4q1+$s4q2+$s4q3+$s4q4+$s4q5)/5;
echo $avrS4;


/*$s5q1=$_POST['s5q1'];
$s5q2=$_POST['s5q2'];
$s5q3=$_POST['s5q3'];
$s5q4=$_POST['s5q4'];
$s5q5=$_POST['s5q5'];*/

/*echo $s2q1;
echo $s2q2;*/

// $avrS5=($s5q1+$s5q2+$s5q3+$s5q4+$s5q5)/5;
// echo $avrS5;


// $s6q1=$_POST['s6q1'];
// $s6q2=$_POST['s6q2'];
// $s6q3=$_POST['s6q3'];
// $s6q4=$_POST['s6q4'];
// $s6q5=$_POST['s6q5'];

// /*echo $s2q1;
// echo $s2q2;*/

// $avrS6=($s6q1+$s6q2+$s6q3+$s6q4+$s6q5)/5;
// echo $avrS6;


// $s7q1=$_POST['s7q1'];
// $s7q2=$_POST['s7q2'];
// $s7q3=$_POST['s7q3'];
// $s7q4=$_POST['s7q4'];
// $s7q5=$_POST['s7q5'];

// /*echo $s2q1;
// echo $s2q2;*/

// $avrS7=($s7q1+$s7q2+$s7q3+$s7q4+$s7q5)/5;
// echo $avrS7;


// $s8q1=$_POST['s8q1'];
// $s8q2=$_POST['s8q2'];
// $s8q3=$_POST['s8q3'];
// $s8q4=$_POST['s8q4'];
// $s8q5=$_POST['s8q5'];

// /*echo $s2q1;
// echo $s2q2;*/

// $avrS8=($s8q1+$s8q2+$s8q3+$s8q4+$s8q5)/5;
// echo $avrS8;
?>