<?php
session_start();
$grno=$_SESSION['grno'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Information</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <!-- Popper JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
  <header>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="main.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="studinfo.php">Information</a>
          <a class="dropdown-item" href="point1.php">Marks</a>
        </div>
      </li>
   
      <li class="nav-item">
        <a class="nav-link" href="detail.php">Feedback</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.html" style="color: aqua">Log out <?php echo $grno;?></a>
      </li>
     
    </ul>
  </div>
 </nav>
 <!-- navbar end -->
</header>

 <center> <h2 style="color: green;" class="mt-5">Feedback Login</h2></center>
<form  method="POST" autocomplete="off">
  <div class="Container">
    <div class="row mt-5">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      GR NO.:
      <input type="text" name="grno" class="form-control">
    </div>
    </div>

    <div class="row mt-3">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      Academic Year:
      <select class="form-control" name="Adyr">
          <option></option>
          <option>FE</option>
          <option>SE</option>
          <option>TE</option>
          <option>BE</option>
        </select>
    </div>
    </div>

    <div class="row mt-3">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      SEMESTER:
      <select name="sem"  id="selection" class="form-control" required>
        <option value="#">Select Semester</option>
        <option value="7">Sem 7</option>
        <option value="8">Sem 8</option>
      </select>
    </div>
    </div>

    <div class="row mt-3">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      PASSWORD:
      <input type="password" name="password" class="form-control">
    </div>
    </div>

    <div class="row mt-5">
      <div class="col-md-4"></div>
      <div class="col-md-4">
      <center><button type="submit" name="submit" class="btn btn-success form-control">SUBMIT</button>
        <?php
           include('eleconn.php');
           if(isset($_POST['submit'])){
            $grno = $_POST["grno"];
            $pass = $_POST["password"];
            $Adyr=$_POST["Adyr"];
            $sem=$_POST["sem"];

            $SE='SE';
            $TE='TE';
            $BE='BE';

            /*session_start();
               $_SESSION['grno'] = $grno;
               $_SESSION['Adyr']=$Adyr;
               $_SESSION['sem']=$sem;
            */
            $conn=mysqli_connect("localhost","root","","college");

            if(!$conn){
              die("connection failed:".mysqli_connect_error());
            }
            $r=mysqli_query($conn,"SELECT password as password FROM reg_it where grno='$grno'");
            $row = mysqli_fetch_array($r);
            $password = $row['password'];
            //echo "$password";
            //$sec_pass=password_verify($pass, $password);
            //echo"$sec_pass";
            // if(password_verify($pass, $password)){
            //   echo "hii";
            // }else{
            //   echo"bye";
            // }

            $sql="select grno,password from reg_it where grno='$grno'";
            $result=mysqli_query($conn,$sql);

            if($SE==$Adyr){
              $sql1="select eligible,feedback_given from studinfo_it_se where grno='$grno'";
              $result1=mysqli_query($conn,$sql1);
            }elseif ($TE==$Adyr) {
              $sql1="select eligible,feedback_given from studinfo_it_te where grno='$grno'";
              $result1=mysqli_query($conn,$sql1);
            }elseif ($BE==$Adyr) {
              $sql1="select eligible,feedback_given from studinfo_it_be where grno='$grno'";
              $result1=mysqli_query($conn,$sql1);
            }


            /*$sql2= "select `elec_no`,`batch` from elecdetail_it_se where grno='$grno'";
                        $res=mysqli_query($conn,$sql2);*/
                        while($row=$result1->fetch_assoc()){
                            $eligible = $row ['eligible'];
                            //echo"\n $eligible";
                            $feedback_given= $row['feedback_given'];
                           //echo "\n $feedback_given";
                        }

                        if($eligible!='No'&& $feedback_given!='Yes'  ){
                               // if($feedback_given!='Yes'||$feedback_given=='No' ){
                                  if( mysqli_num_rows($result)>0 && password_verify($pass, $password)){
                                  echo'<script>
                                     alert("Give Feedback");
                                     window.location = "feedback.php";
                                  </script>';
                                }
                           // }
                          }
                          else{
                              if($eligible=='No'){
                                  if(mysqli_num_rows($result1)>0 && password_verify($pass, $password) ) {
                                    echo '<script>
                                           confirm("you are not eligible for feedback");
                                           window.location = "detail_be.php";
                                          </script>
                                          ';
                                    }
                                }
                              if($feedback_given=='Yes'){
                                  if(mysqli_num_rows($result1)>0 && password_verify($pass, $password)) {
                                  echo'<script>
                                       alert("Feedback already given");
                                       window.location = "detail_be.php";
                                    </script>';
                                  }
                                }

                          }

            mysqli_close($conn);

           }
            ?>

      </center>
      </div>
    </div>

  </div>

</form>
</body>
</html>