<!DOCTYPE html>
<html>
<head>
 <title>BE IT -Elective Subjects</title>

 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

 <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
   <script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

 <!-- Bootnavbar.css -->
<link href="css/bootnavbar.css" rel="stylesheet">

</head>
<body>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark" id="main_navbar">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College of Engineering</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">

                <!-- HOME  -->
                <li class="nav-item active">
                    <a class="nav-link" href="main1.html">Home <span class="sr-only">(current)</span></a>
                </li>
                <!-- STUDENT -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        Student
                    </a>

                    <!-- STUDENT MARKS -->
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student Marks
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="dispoint_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="dispoint_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="dispoint_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                            <!-- STUDENT INFORMATION -->

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student information
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="indis_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="indis_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="indis_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                    </ul>
                    <!-- SUBJECT -->
    <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Subject
            </a>
         
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        
                        <!-- THEORY SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Theory Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="theory_display_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="theory_display_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="theory_display_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                        <!-- Elective SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Elective Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayelec_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="displayelec_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="displayelec_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                        <!-- PRACTICAL SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Practical Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayprac_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="displayprac_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="displayprac_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
            </ul>
      </li>

      <!--Elective Details  -->
       <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Elective Details
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">SE</a>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">TE</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_be.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">BE</a>  
                        </li>
            </ul>
      </li>

      <!-- FEEDBACK -->
      <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Feedback
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Theory</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="tft_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="tft_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="tft_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Practical</a> 
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="pft_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="pft_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="pft_be.php">BE</a></li>
                                    
                                    </li>
                                </ul> 
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="lfb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Library</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="ofb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Other Facilities</a>  
                        </li>
            </ul>
      </li>

      <!-- ELIGIBILITY -->
       <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Eligibility
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">SE</a>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">TE</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_be.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">BE</a>  
                        </li>
            </ul>
      </li>
    <!-- LOG OUT -->
      <li class="nav-item">
        <a class="nav-link" href="faclogin.html">Log out</a>
      </li>
                    
                       
 </ul>        
        </div>
    </nav>

 <!-- navbar end -->

 <div class="container">
 <div class="col-lg-12">
 <br><br>
 <h1 class="text-warning text-center" >BE IT - Elective Subjects</h1>
 <br>
 <table  id="tabledata" class=" table table-striped table-hover table-bordered">
 
 <tr class="bg-dark text-white text-center">
 
 <th> Sem </th>
 <th> Subject_code </th>
 <th> Elective_Subject_Name </th>
 <th> Faculty_name </th>
 <th> Delete </th>
 <th> Update </th>
 
 </tr >

 <?php

 include 'conn.php'; 
 $q = "SELECT * FROM elec_it WHERE `sem_no`= 7 OR `sem_no` = 8 ORDER BY sem_no ASC";
 

 $query = mysqli_query($conn,$q);

 while($res = mysqli_fetch_array($query)){
 ?>
 <tr class="text-center">
 <td> <?php echo $res['sem_no'];  ?> </td>
 <td> <?php echo $res['subject_code'];  ?> </td>
 <td> <?php echo $res['subject_name'];  ?> </td>
 <td> <?php echo $res['faculty_name'];  ?> </td>
 <td> <button class="btn-danger btn"> <a href="Deleteelec.php?subject_code=<?php echo $res['subject_code']; ?>" class="text-white"> Delete </a>  </button> </td>
 <td> <button class="btn-primary btn"> <a href="Updateelec.php?subject_code=<?php echo $res['subject_code']; ?>" class="text-white"> Update </a> </button> </td>

 </tr>

 <?php 
 }
  ?>
 
 </table>  

 </div>
 </div>
 <center><button class="btn-primary btn mt-4"><a href="insertelective.php" class="text-white">ADD</a></button></center>

 <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 });
 
 </script>

<!-- Js for Navbar, Multi-level dropdown -->
  <script src="js/bootnavbar.js" ></script>
    <script>
        $(function () {
            $('#main_navbar').bootnavbar({
                //option
                //animation: false
            });
        })
    </script>

    

</body>
</html>