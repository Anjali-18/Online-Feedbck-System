<?php
$servername="localhost";
$username="root";
$password="";
$dbname="college";

$sem=$_POST['sem'];
$M1=$_POST['p1'];
$M2=$_POST['p2'];
$M3=$_POST['p3']; 
$M4=$_POST['p4'];
$M5=$_POST['p5'];
$M6=$_POST['p6'];
$M7=$_POST['p7'];
$M8=0.0;
$SE='SE';
$TE='TE';
$BE='BE';

session_start(); 
   $grno=$_SESSION['grno'];
   $name=$_SESSION['name'];
   $Adyr=$_SESSION['Adyr'];
   $_SESSION['sem']=$sem;
   // $rno=$_SESSION['rno'];
   //echo $rno;

	$conn=new mysqli($servername,$username,$password,$dbname);

	if($sem=='1'){
			$M1=0.0;
			$M2=0.0;
			$M3=0.0;
			$M4=0.0;
			$M5=0.0;
			$M6=0.0;
			$M7=0.0;
			$M8=0.0; 
		}
		else if ($sem=='2') {
			$M2=0.0;
			$M3=0.0;
			$M4=0.0;
			$M5=0.0;
			$M6=0.0;
			$M7=0.0;
			$M8=0.0;
		}
		else if ($sem=='3') {
			$M3=0.0;
			$M4=0.0;
			$M5=0.0;
			$M6=0.0;
			$M7=0.0;
			$M8=0.0;
		}
		else if ($sem=='4') {
			$M4=0.0;
			$M5=0.0;
			$M6=0.0;
			$M7=0.0;
			$M8=0.0;
		}
		else if ($sem=='5') {
			$M5=0.0;
			$M6=0.0;
			$M7=0.0;
			$M8=0.0;
		}
		else if ($sem=='6') {
			$M6=0.0;
			$M7=0.0;
			$M8=0.0;
		}
		else if ($sem=='7') {
			$M7=0.0;
			$M8=0.0;
		}	
		else if ($sem=='8') {
			$M8=0.0;
		}
		
	if($conn->connect_error)
	{
		die("Connectivity Error:".$conn->connect_error);
	}

	
			/*$q="SELECT grno FROM point_it_be WHERE grno='$grno'";
				$result=mysqli_query($conn,$q);
				if(mysqli_num_rows($result)>0){
					echo "data already present";
					$u="UPDATE `point_it_be` SET `grno`='$grno',`name`='$name',`sem1`='$sem1',`sem2`='$sem2',`sem3`='$sem3',`sem4`='$sem4',`sem5`='$sem5',`sem6`='$sem6',`sem7`='$sem7',`sem8`='$sem8' WHERE grno='$grno' ";
					if(mysqli_query($conn,$u)){
						echo "Updated";
					}else{
						echo"Not updated";
					}
				}else{
					echo "not present";
				}*/

			if($SE==$Adyr){
							$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_it_se where grno='$grno'");
					 		$row = mysqli_fetch_array($result);
    						$rno = $row['rno'];
    						//echo "$rno";
    						//$rno=$rno+1;


				$sql="insert into point_it_se(grno,rno,name,sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8)values('$grno','$rno','$name','$M1','$M2','$M3','$M4','$M5','$M6','$M7','$M8')";
				//echo "$sql";
				if(mysqli_query($conn,$sql))
				{
		 			echo'<script>alert("successfully submitted");
		 			window.location="e1_se.php";
	            	</script>';
		 		}else{
		 			echo'<script>alert("Already Submitted");
		 			window.location="e1_se.php";
	            	</script>';
		 		}
			}else{
				if($TE==$Adyr){
							$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_it_te WHERE grno='$grno'");
					 		$row = mysqli_fetch_array($result);
    						$rno = $row['rno'];

					$sql="insert into point_it_te(grno,rno,name,sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8)values('$grno','$rno','$name','$M1','$M2','$M3','$M4','$M5','$M6','$M7','$M8')";

					if(mysqli_query($conn,$sql) )
					{
			 			echo'<script>alert("successfully submitted");
			 			window.location="e1_te.php";
		            	</script>';
			 		}else{
			 			echo'<script>alert("Already Submitted");
			 			window.location="e1_te.php";
		            	</script>';
			 		}
				}else{
					if($BE==$Adyr){
							$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_it_be where grno='$grno'");
					 		$row = mysqli_fetch_array($result);
    						$rno = $row['rno'];
    						//echo "$rno";

						$sql="insert into point_it_be(grno,rno,name,sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8)values('$grno','$rno','$name','$M1','$M2','$M3','$M4','$M5','$M6','$M7','$M8')";
						//echo $sql;

						if(mysqli_query($conn,$sql))
						{
				 			echo'<script>alert("successfully submitted");
				 			window.location="e1_be.php";
			            	</script>';
				 		}else{
				 			echo'<script>alert("Already Submitted");
				 			window.location="e1_be.php";
			            	</script>';
				 		}
					}
				}
			}		
	 		/*header('location:e1.php');*/
/*	}*/


		
		

	

	$conn->close();


?>

