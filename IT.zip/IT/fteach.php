<?php
error_reporting(0);
$conn=mysqli_connect("localhost","root","","college");
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}

$f="Select distinct fac1 from feedback_auto_be where fac1!='NULL'";
    $s=mysqli_query($conn,$f);
    $datas= array();
    if(mysqli_num_rows($s)>0){
    while($row= mysqli_fetch_assoc($s)){
        $datas[]= $row;
    }
}
    print_r($datas);
?>
<!DOCTYPE html>
<html>
<head>
	<title>calculation average</title>

 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

</head>
<body>
 <div class="container">
 <div class="col-lg-12">
 <br><br>
 <h1 class="text-warning text-center" > Display Table Data </h1>
 <br>
 <table  id="tabledata" class=" table table-striped table-hover table-bordered">
 
 <tr class="bg-dark text-white text-center">
 
 <th> s1q1 </th>
 <th> s1q2</th>
 <th> s1q3 </th>
 <th> s1q4</th>
 <th> avg1</th> 

 </tr >

 <?php

 include 'conn.php'; 
 for ($i=0; $i < 2 ; $i++) { 
 	foreach($datas[$i] as $data)
 	$q = "select s1q1,s1q2,s1q3,s1q4,avg1,distinct sub1,fac1 from feedback_auto_be where fac1= $data";
 	echo $q;
 	$query = mysqli_query($conn,$q);
 
 

 while($res = mysqli_fetch_array($query)){
 ?>
 <tr class="text-center">
 <td> <?php echo $res['s1q1'];  ?> </td>
 <td> <?php echo $res['s1q2'];  ?> </td>
 <td> <?php echo $res['s1q3'];  ?> </td>
 <td> <?php echo $res['s1q4'];  ?> </td>
 <td> <?php echo $res['s1q5'];  ?> </td>
 <td> <?php echo $res['avg1'];  ?> </td>
 </tr>

 <?php 
 }
}
  ?>
 
 </table>  

 </div>
 </div>
 <center><button class="btn-primary btn mt-4"><a href="insertelec.php" class="text-white">ADD</a></button></center>

 <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 });
 
 </script>

</body>
</html>
