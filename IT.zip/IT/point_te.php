<?php
session_start();
$grno=$_SESSION['grno'];
?>
<!DOCTYPE html>
<html>
<head>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>


 	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <style>
    .colr{
      color: blue;
    }
  </style>


<script>
	$(document).ready(function(){
    $('#selection').on('change', function() {
    	if ( this.value == '2')
      {
        $("#sem2").show();
      	$("#sem8").hide();
         $("#sem7").hide();
      	 $("#sem6").hide();
      	 $("#sem5").hide();
      	 $("#sem4").hide();
      	 $("#sem3").hide();
      	 
      }
      else if(this.value == '3')
      {
        $("#sem3").show();
        $("#sem2").show();
        $("#sem8").hide();
        $("#sem7").hide();
      	$("#sem6").hide();
      	$("#sem5").hide();
      	$("#sem4").hide();
      	
      }
      else if(this.value=='4'){
      	$("#sem4").show();
        $("#sem3").show();
      	$("#sem2").show();
      	$("#sem8").hide();
      	$("#sem7").hide();
      	$("#sem6").hide();
      	$("#sem5").hide();
      	

      }
      else if(this.value=='5'){
      	 $("#sem5").show();
      	  $("#sem4").show();
      	 $("#sem3").show();
      	 $("#sem2").show();
      	 $("#sem8").hide();
      	 $("#sem7").hide();
      	 $("#sem6").hide();

      }
      else if(this.value=='6'){
      	$("#sem6").show();
      	$("#sem5").show();
      	$("#sem4").show();
      	$("#sem3").show();
      	$("#sem2").show();
      	$("#sem8").hide();
      	$("#sem7").hide();
      }
      else if(this.value=='7'){
      	$("#sem7").show();
      	$("#sem6").show();
      	$("#sem5").show();
      	$("#sem4").show();
      	$("#sem3").show();
      	$("#sem2").show();
      	$("#sem8").hide();
      }
      else if(this.value=='8'){
      	$("#sem8").show();
      	$("#sem7").show();
      	$("#sem6").show();
    	  $("#sem5").show();
      	$("#sem4").show();
      	$("#sem3").show();
      	$("#sem2").show();
      }
      else
      {
      	$("#sem7").hide();
      	$("#sem6").hide();
      	$("#sem5").hide();
      	$("#sem4").hide();
      	$("#sem3").hide();
      	$("#sem2").hide();
      	$("#sem8").hide();
      }
     
    });
});
</script>
</head>
<body>
<header>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="main.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="studinfo.php">Information</a>
          <a class="dropdown-item" href="point1.php">Marks</a>
        </div>
      </li>
   
      <li class="nav-item">
        <a class="nav-link" href="detail.php">Feedback</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.html" style="color: aqua">Log out <?php echo $grno;?></a>
      </li>
     
    </ul>
  </div>
 </nav>
 <!-- navbar end -->
</header>


	<form class="container" action="point.php" method="POST" autocomplete="off">
			<center><h4 style="color: blue;" class="mt-5"><label>SEMESTER POINTER</label></h4></center>
				<div class="row">
				    <div class="col-md-3">
						<label class="colr">Select your Semester</label>
					    <select name="sem"  id="selection" class="form-control" required>
		            		  <option value="#">Select an option</option>
					           	<option value="5" id="s5">Sem 5</option>
					           	<option value="6" id="s6">Sem 6</option>
					   </select>
					</div>
				</div><br>
				<section>
					<label class="colr">Enter your Semester pointer</label>
					<div class="row">
						<div style='display: none;' id="sem2" class="col-md-3"> 
							<label>Sem 1</label>
							<input type="float" name="p1" class="form-control">
						</div>
						<div style='display: none;' id='sem3' class="col-md-3">
							<label>sem 2</label>
							<input type="float" name="p2" class="form-control">
						</div>
						<div style='display: none;' id='sem4' class="col-md-3">
							<label>sem 3</label>
							<input type="float" name="p3" class="form-control">
						</div>
						<div style='display: none;' id='sem5' class="col-md-3" >
							<label>sem 4</label>
							<input type="float" name="p4" class="form-control">
						</div>
        			</div>
        			<div class="row">
        				<div style='display: none;' id='sem6' class="col-md-3">
							<label>sem 5</label>
							<input type="float" name="p5" class="form-control">
						</div>
						<div style='display: none;' id='sem7' class="col-md-3">
							<label>sem 6</label>
							<input type="float" name="p6" class="form-control">
						</div>
						<div style='display: none;' id='sem8' class="col-md-3">
							<label>sem 7</label>
							<input type="float" name="p7" class="form-control">
						</div>
        				
        			</div>
        	</section>
			
        	<div class="mt-5">
        		<center><button class="btn btn-primary" name="Submit">Submit</button></center>
			    </div>

        	</form>
</body>
</html>