<?php
session_start();
$Adyr=$_SESSION['Adyr'];
echo "$Adyr";
$SE='SE';
$TE='TE';
$BE='BE';

if($SE==$Adyr){
  header('location:detail_se.php'); 
}elseif ($TE==$Adyr) {
  header('location:detail_te.php'); 
}elseif($BE==$Adyr){
  header("location:detail_be.php");
}

?>