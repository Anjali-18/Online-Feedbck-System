<?php
           $grno = $_POST["grno"];
           $pass = $_POST["password"];
           $Adyr=$_POST["Adyr"];
           $sem=$_POST["sem"];
          // $dept=$_POST['department'];
           $division=$_POST['division'];
           
            $FE='FE';


          session_start();
             $_SESSION['grno'] = $grno;
             $_SESSION['Adyr']=$Adyr;
             $_SESSION['sem']=$sem;
             $_SESSION['division']=$division;

               

          $conn=mysqli_connect("localhost","root","","college");

          if(!$conn){
            die("connection failed:".mysqli_connect_error());
          }

          $r=mysqli_query($conn,"SELECT password as password FROM reg_fe where grno='$grno'");
          $row = mysqli_fetch_array($r);
          $password = $row['password'];

          $sql="select grno from reg_fe where grno='$grno'";
          $result=mysqli_query($conn,$sql);



          if($FE==$Adyr){
            $sql1="select eligible,feedback_given from studinfo_fe where grno='$grno'";
            $result1=mysqli_query($conn,$sql1);
          }

                      while($row=$result1->fetch_assoc()){
                          $eligible = $row ['eligible'];
                          //echo"\n $eligible";
                          $feedback_given= $row['feedback_given'];
                         //echo "\n $feedback_given";
                      }

                      if($eligible!='No'&& $feedback_given!='Yes' ){
                             // if($feedback_given!='Yes'||$feedback_given=='No' ){
                                if( mysqli_num_rows($result)>0  && password_verify($pass, $password)){
                                echo'<script>
                                   alert("Give Feedback");
                                   window.location = "feedback.php";
                                </script>';
                              }
                         // }
                        }
                        else{
                            if($eligible=='No'){
                                if(mysqli_num_rows($result1)>0  && password_verify($pass, $password) ) {
                                  echo '<script>
                                         confirm("you are not eligible for feedback");
                                         window.location = "detail1.php";
                                        </script>
                                        ';
                                  }
                                // $error1="you are not eligible for feedback ";
                                // echo $error1;
                              }
                            if($feedback_given=='Yes'){
                                if(mysqli_num_rows($result1)>0  && password_verify($pass, $password) ) {
                                echo'<script>
                                     alert("Feedback already given");
                                     window.location = "detail1.php";
                                  </script>';
                                }
                                // $error2="Feedback already given";
                                // echo "$error2";
                              }

                        }

                     
                        
                      
          //
          mysqli_close($conn);
          

          ?>
     