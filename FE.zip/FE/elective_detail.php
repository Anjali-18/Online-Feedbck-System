<?php
	
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";

	$e1=$_POST['e1'];
	$e2=$_POST['e2'];
	$e3=$_POST['e3'];
	$e4=$_POST['e4'];
	$e5=$_POST['e5'];
	$e6=$_POST['e6'];
	$bt=$_POST['bt'];
	$elec=$_POST['elec'];

	// if($elec==1)
	// {
	// 	$e3='none';
	// 	$e4='none';
	// 	$e5='none';
	// 	$e6='none';

	// }else if($elec==2)
	// {
	// 	$e5='none';
	// 	$e6='none';

	// }

	session_start();
	$grno=$_SESSION['grno'];
	$name=$_SESSION['name'];
	$sem=$_SESSION['sem'];
	$division=$_SESSION['division'];
	//$_SESSION['bt']=$bt;
	$Adyr=$_SESSION['Adyr'];
	$dept=$_SESSION['department'];
	//echo $Adyr;
    $FE='FE';
   	
	$conn=new mysqli($servername, $username, $password, $dbname);
	if ($conn->connect_error){
		die("Connection failed:" .$conn->connect_error);
	}
	else
	{
			if($FE==$Adyr){
				$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_fe where grno='$grno'");
				$row = mysqli_fetch_array($result);
    			$rno = $row['rno'];
 				echo "$rno";

				$elec=0;
				$sql="insert into elecdetail_fe(grno,rno,name,sem,elec_no,Department,division,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno' ,'$name', '$sem','$elec','$dept','$division', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
						//echo $sql;
						if(mysqli_query($conn,$sql)/*or die(mysqli_error($conn))*/)
						{
				 			echo'<script>alert("successfully submitted");
				 			window.location="detail1.php";
			            	</script>';
				 		}else{
				 			echo'<script>alert("Submission failed, you have already submitted");
				 			window.location="detail1.php";
			            	</script>';
				 		}
			}
	}
	
?>






































