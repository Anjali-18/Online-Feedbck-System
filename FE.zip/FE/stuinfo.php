<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";

	$name=$_POST['name']; 
	//echo $name;
	$grno=$_POST['grno'];
	$phone=$_POST['phone'];
	$Adyr=$_POST['Adyr'];
	$DOB=$_POST['DOB'];
	$division=$_POST['division'];     
	$dept=$_POST['dept'];
	$blogp=$_POST['blogp'];
	$caste=$_POST['caste'];
	$subcaste=$_POST['subcaste'];
	$FE='FE';
	/*$SE='SE';
	$TE='TE';
	$BE='BE';*/
	
	session_start();
	$_SESSION['division'] = $division;
   	$_SESSION['name'] = "$name";
   	
	

   	$conn=new mysqli($servername,$username,$password,$dbname);
   //	echo "connected";
	if($conn->connect_error)
	{
		die("Connectivity Error:".$conn->connect_error);
	}
	else
	{
		if($FE==$Adyr){
			$sql="insert into studinfo_fe(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
				//echo $sql;
				if(mysqli_query($conn,$sql))
				{
					echo'<script>alert("successfully submitted");
			 		  window.location = "point.html";
		            </script>';
			 	}
				 else
			 	{
			 		echo '<script>alert("Already Submitted");
		             window.location = "point.html";
		            </script>';
			 	}
			 }else{
			 	echo '<script>alert("Student must be from FE");
		             window.location = "studinfo.php";
		            </script>';
			 }
			
	}

	$conn->close();
?>
