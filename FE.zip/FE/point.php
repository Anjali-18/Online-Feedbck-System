<?php
$servername="localhost";
$username="root";
$password="";
$dbname="college";

$sem=$_POST['sem'];
$M1=$_POST['p1'];
$M2=$_POST['p2'];
$M3=$_POST['p3']; 
$M4=$_POST['p4'];
$M5=$_POST['p5'];
$M6=$_POST['p6'];
$M7=$_POST['p7'];
$M8=0.0;
$FE='FE';
// $TE='TE';
// $BE='BE';

session_start(); 
   $grno=$_SESSION['grno'];
   $name=$_SESSION['name'];
   $Adyr=$_SESSION['Adyr'];
   $division=$_SESSION['division'];
   echo "$division";
   $dept=$_SESSION['department'];
   echo "$dept";
   $_SESSION['sem']=$sem;

	$conn=new mysqli($servername,$username,$password,$dbname);

	if($sem=='1'){
			$M1=0.0;
			$M2=0.0;
			$M3=0.0;
			$M4=0.0;
			$M5=0.0;
			$M6=0.0;
			$M7=0.0;
			$M8=0.0; 
		}
		else if ($sem=='2') {
			$M2=0.0;
			$M3=0.0;
			$M4=0.0;
			$M5=0.0;
			$M6=0.0;
			$M7=0.0;
			$M8=0.0;
		}
		else if ($sem=='3') {
			$M3=0.0;
			$M4=0.0;
			$M5=0.0;
			$M6=0.0;
			$M7=0.0;
			$M8=0.0;
		}
		else if ($sem=='4') {
			$M4=0.0;
			$M5=0.0;
			$M6=0.0;
			$M7=0.0;
			$M8=0.0;
		}
		else if ($sem=='5') {
			$M5=0.0;
			$M6=0.0;
			$M7=0.0;
			$M8=0.0;
		}
		else if ($sem=='6') {
			$M6=0.0;
			$M7=0.0;
			$M8=0.0;
		}
		else if ($sem=='7') {
			$M7=0.0;
			$M8=0.0;
		}	
		else if ($sem=='8') {
			$M8=0.0;
		}
		
	if($conn->connect_error)
	{
		die("Connectivity Error:".$conn->connect_error);
	}

			if($FE==$Adyr){
				$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_fe where grno='$grno'");
				$row = mysqli_fetch_array($result);
    			$rno = $row['rno'];
 				echo "$rno";
				
				$sql="insert into point_fe(grno,rno,name,Department,division,sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8) values('$grno','$rno','$name','$dept','$division','$M1','$M2','$M3','$M4','$M5','$M6','$M7','$M8') ";
               // echo "$sql";
				if(mysqli_query($conn,$sql) /*or die(mysqli_error($conn))*/)
				{
		 			echo'<script>alert("successfully submitted");
		 			window.location = "e1.php";
	            	</script>';
		 		}else{
		 			echo'<script>alert("Already Submitted");
		 			 window.location = "e1.php";
	            	</script>';
		 		}
		 	
			}
	$conn->close();


?>

