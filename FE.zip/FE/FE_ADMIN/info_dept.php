<?php  
$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";

	$conn=new mysqli($servername,$username,$password,$dbname);
  session_start();
  $dept=$_SESSION['Department'];

$sql = "SELECT id,grno,name,rno,sts,phone,Adyr,DOB,division,dept,blogp,caste,subcaste FROM studinfo_fe where division='$division'";

$setRec = mysqli_query($conn, $sql); 
$columnHeader = '';  
$columnHeader = "Sr.No." . "\t" ."Grno" . "\t" . "Name" . "\t" ."Roll No" . "\t" ."Status" . "\t" . "phone" . "\t"."Adyr"."\t"."DOB"."\t"."Division" . "\t" ."dept"."\t"."blogp"."\t"."caste"."\t"."Subcaste"."\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=studentinfo.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n"; 
 
?> 