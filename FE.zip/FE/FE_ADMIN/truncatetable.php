<?php
include('conn.php');

  if(isset($_POST['truncatetable'])){
  $sql1="TRUNCATE table studinfo_auto ";
  if(mysqli_query($conn,$sql1)){
    echo "<script>
    alert(window.location.href ='indis.php')
    </script>";
  }
  else{
    echo "not truncate"; 
  }
}

?>