<?php
				
			include 'conn.php';
				session_start();
				$division=$_SESSION['division'];
				$_SESSION['division']=$division;
				
				$id = $_GET['id'];

				$q = "DELETE FROM studinfo_fe WHERE id = '$id'";
				echo $q;
				if(mysqli_query($conn,$q)){
					echo "deleted";
				}

				header('location:indisdivision.php');
					
?>