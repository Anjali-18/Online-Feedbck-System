<?php
include 'conn.php';
$div=$_POST['division'];

echo $div;
session_start();
	$_SESSION['div']=$div;
$sem="1";
	 	switch($sem)
		{
			case '1': header('location:displayprac.php'); 
			//			break;
		}
?>