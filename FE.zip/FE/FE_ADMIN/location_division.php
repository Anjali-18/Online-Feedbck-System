<?php
$division=$_POST['division'];

session_start();
$_SESSION['division']=$division;

header('location:indisdivision.php');
?>