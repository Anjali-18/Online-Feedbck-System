<?php

 include 'conn.php';
	
	session_start();
		$div=$_SESSION['division'];
		$_SESSION['division']=$div;

		echo $div;

if(isset($_POST['done'])){

 $Sr_no = $_GET['sr_no'];
 //$sem = $_POST['sem'];
 //$Batch=$_POST['Batch'];
 //$Subject=$_POST['Subject'];
 	 $Faculty = $_POST['Faculty'];

$sr_no = $_GET['sr_no'];

$query = "SELECT `sem`,`division` FROM prac_fe WHERE `sr_no` = '$sr_no'";

$res=mysqli_query($conn,$query);
while($row=$res->fetch_assoc()){
	$sem = $row ['sem'];
	$division = $row ['division'];
	echo $sem;
}



 $q = "UPDATE prac_fe set faculty_name='$Faculty' where sr_no=$sr_no ";
echo "$q";
 // $query = mysqli_query($conn,$q);

 // header('location:Displayprac.php');

if(mysqli_query($conn,$q))
 {

	 	switch($sem)
		{
			case '1': header('location:displayprac.php'); 
						break;
			case '2': header('location:displayprac.php'); 
						break;
			
		}
	 }else
 	{
 		echo "error";
 	}

 }

?>