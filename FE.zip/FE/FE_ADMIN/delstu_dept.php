<?php
				
			include 'conn.php';
			session_start();
 				$dept=$_SESSION['Department'];
 				$_SESSION['Department']=$dept;

				$id = $_GET['id'];
				echo $dept;

				$q = "DELETE FROM studinfo_fe WHERE id = '$id'";
				echo $q;
				if(mysqli_query($conn,$q)){
					echo "deleted";
				}

				header('location:indisdept.php');
					
?>