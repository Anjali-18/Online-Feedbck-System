<?php
session_start();
  $div=$_SESSION['div'];
?>
<!DOCTYPE html>
<html>
<head>
 <title>BE AUTO - Theory Subjects</title>

 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

 <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
   <script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

    <!-- Bootnavbar.css -->

     <link href="css/bootnavbar.css" rel="stylesheet">
     

</head>
<body>
 <header>
    <!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main1.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="choose.php">Student information</a>
          <a class="dropdown-item" href="dispoint.php">Student Marks</a>
        </div>
      </li>
       <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Subject
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="theory_division.php">Regular subject</a>
          <a class="dropdown-item" href="elec_division.php">Elective subject</a>
          <a class="dropdown-item" href="prac_division.php">Practical subject</a>
        </div>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="elecdetail1.php">Elective details</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="eligible1.php">Eligible</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tft_division.php">Feedback</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.html">Log out</a>
      </li>
     
    </ul>
  </div>
 </nav>

 <!-- navbar end -->
 </header>

 <div class="container">
 <div class="col-lg-12">
 <br><br>
 <h1 class="text-warning text-center" >Theory Subjects</h1>
 <br>
 <table  id="tabledata" class=" table table-striped table-hover table-bordered">
 
 <tr class="bg-dark text-white text-center">
 
 <th> ID </th>
 <th> Sem </th>
 <th> Division </th>
 <th> Subject_code </th> 
 <th> Theory_Subject_Name </th>
 <th> Faculty_name </th>
 <th> Delete </th>
 <th> Update </th>
 
 </tr >

<?php

 include 'conn.php'; 
$q = "SELECT * FROM theory_fe WHERE division='$div'";

 $query = mysqli_query($conn,$q);

 while($res = mysqli_fetch_array($query)){
 ?>
 <tr class="text-center">
 <td> <?php echo $res['id'];  ?> </td>
 <td> <?php echo $res['sem_no'];  ?> </td>
 <td> <?php echo $res['division'];  ?> </td>
 <td> <?php echo $res['subject_code'];  ?> </td>
 <td> <?php echo $res['subject_name'];  ?> </td>
 <td> <?php echo $res['faculty_name'];  ?> </td>
 <td> <button class="btn-danger btn"> <a href="theory_delete.php?id=<?php echo $res['id']; ?>" class="text-white"> Delete </a>  </button> </td>
 <td> <button class="btn-primary btn"> <a href="updatetheory.php?id=<?php echo $res['id']; ?>" class="text-white"> Update </a> </button> </td>

 </tr>

 <?php 
 }
  ?>
 
 </table>  

 </div>
 </div>
 <center><button class="btn-primary btn mt-4"><a href="inserttheory.php" class="text-white">ADD</a></button></center>

 <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 });
 
 </script>

 <!-- Js for Navbar, Multi-level dropdown -->
  <script src="js/bootnavbar.js" ></script>
    <script>
        $(function () {
            $('#main_navbar').bootnavbar({
                //option
                //animation: false
            });
        })
    </script>

</body>
</html>