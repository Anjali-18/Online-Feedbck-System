<?php
$div=$_POST['division'];
session_start();
$_SESSION['division']=$div;

header('location:diselecdetail.php');

?>