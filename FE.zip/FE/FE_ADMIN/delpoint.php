<?php
				
			include 'conn.php';
				session_start();
				$div=$_SESSION['division'];
				$_SESSION['division']=$div;
				
				$grno = $_GET['grno'];

				$q = "DELETE FROM point_fe WHERE grno = '$grno'";
				echo $q;
				if(mysqli_query($conn,$q)){
					echo "deleted";
				}

				header('location:dispoint.php');
					
?>