<?php
include 'conn.php';
$div=$_POST['division'];

echo $div;
session_start();
	$_SESSION['div']=$div;

	header('location:displayprac.php'); 
// $sem="1";
// 	 	switch($sem)
// 		{
// 			case '1': header('location:displayprac.php'); 
// 			//			break;
// 		}
?>