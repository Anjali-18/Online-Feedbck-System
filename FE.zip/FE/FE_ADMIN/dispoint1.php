<!DOCTYPE html>
<html>
<head>
  <title>Student Information</title>

  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<!-- Bootnavbar.css -->
<link href="css/bootnavbar.css" rel="stylesheet">

<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript">
 
</script>

<style type="text/css">
  .colr{
    color: yellow;
  }
  .co{
    color: blue;
  }
</style>

</head>

<body>
 <header>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main1.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="choose.php">Student information</a>
          <a class="dropdown-item" href="dispoint1.php">Student Marks</a>
        </div>
      </li>
       <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Subject
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="theory_division.php">Regular subject</a>
          <a class="dropdown-item" href="elec_division.php">Elective subject</a>
          <a class="dropdown-item" href="prac_division.php">Practical subject</a>
        </div>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="elecdetail1.php">Elective details</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="eligible1.php">Eligible</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Feedback
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="tft_division.php">Theory Feedback</a>
          <a class="dropdown-item" href="pft_division.php">Practical Feedback</a>
          <a class="dropdown-item" href="libf.php">Library Feedback</a>
           <a class="dropdown-item" href="ofb.php">Other Feedback</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="faclogin.html" style="color: aqua;">Log out</a>
      </li>
     
    </ul>
  </div>
 </nav> <!-- navbar end -->


</header>

  <div class="container mt-5">
    <form method="POST" action="location_point.php">
          <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-3">
                <select class="form-control" name="division">
                <option>Select Division</option>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
                <option value="E">E</option>
                <option value="F">F</option>
                <option value="G">G</option>
                <option value="H">H</option>
                <option value="I">I</option>
                </select>
            </div>
          <button class="btn btn-success"  name="submit">submit</button>
        </div><br><br>
       </form>
  </div>
      
</body>
</html>
