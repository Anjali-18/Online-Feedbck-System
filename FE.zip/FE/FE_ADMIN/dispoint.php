<?php 
include ('conn.php');
error_reporting(0);


//echo $div ;
session_start();
   $div=$_SESSION['division'];

?>
<!DOCTYPE html>
<html>
<head>
  <title>Semester Pointers</title>

  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<!-- Bootnavbar.css -->
<link href="css/bootnavbar.css" rel="stylesheet">

<style type="text/css">
  .colr{
    color: yellow;
  }
  .co{
    color: blue;
  }
</style>

</head>
<body>
<header>
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main1.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="choose.php">Student information</a>
          <a class="dropdown-item" href="dispoint1.php">Student Marks</a>
        </div>
      </li>
       <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Subject
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="theory_division.php">Regular subject</a>
          <a class="dropdown-item" href="elec_division.php">Elective subject</a>
          <a class="dropdown-item" href="prac_division.php">Practical subject</a>
        </div>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="elecdetail1.php">Elective details</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="eligible1.php">Eligible</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Feedback
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="tft_division.php">Theory Feedback</a>
          <a class="dropdown-item" href="pft_division.php">Practical Feedback</a>
          <a class="dropdown-item" href="libf.php">Library Feedback</a>
           <a class="dropdown-item" href="ofb.php">Other Feedback</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="faclogin.html">Log out</a>
      </li>
     
    </ul>
  </div>
 </nav>
 <!-- navbar end -->


</header>
  <div>
    <h3 class="mt-5 text-center bg-dark text colr">STUDENT POINTERS</h3>
    <br>
    <!-- <button id="displayinfo" class="btn btn-danger">Display</button>

 -->
    <table class="table table-striped table-bordered text-center">
      <thead>
        <th class="co">GR NO.</th>
        <th class="co">Roll No</th>
        <th class="co">Name</th>
        <th class="co">Department</th>
        <th class="co">Division</th>
        <th class="co">Sem1</th>
        <th class="co">Sem2</th>
        <th class="co">Sem3</th>
        <th class="co">Sem4</th>
        <th class="co">Sem5</th>
        <th class="co">Sem6</th>
        <th class="co">Sem7</th>
        <th class="co">Sem8</th>
        <th class="co">Delete</th>
      </thead>
      <tbody id="response">
        
      </tbody>
    </table>
    <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-2">
            <button class="btn btn-success" onclick="window.location.href ='infpoint.php';">Export To Excel</button>
            </div>
            <div class="col-md-2">
            <form method="POST">
                <button class="btn btn-success" name="truncatetable">Delete All Records</button>
                    <?php
                        include('conn.php');

                          if(isset($_POST['truncatetable']))
                            {
                                 $sql1="TRUNCATE table point_fe";
                                 if(mysqli_query($conn,$sql1))
                                 {
                                        echo "<script>
                                         alert(window.location.href ='main1.html')
                                         </script>";
                                
                                 }else
                                 {
                                    echo "not truncate"; 
                                 }
                            }

                    ?>
            </form>
            </div>
        </div>
  </div>

  <script type="text/javascript">
    $(document).ready(function(){
      var from=$('#myform');
      $('#submit').click(function(){
        $.ajax(
        {
          url:from.attr("action"),
          type:'post',
          data:$("#myform input").serialize(),

          success:function(data){
            console.log(data);
          }

        });
      });
    

      Display();
    /*$('#displayinfo').click(function(){*/
      function Display(){
      $.ajax({
        url:'showpt.php',
        type:'post',

        success:function(responsedata){
          $('#response').html(responsedata);
        }
      });
    }
    /*});*/
  });

  </script>
    <!-- Js for Navbar, Multi-level dropdown -->
  <script src="js/bootnavbar.js" ></script>
    <script>
        $(function () {
            $('#main_navbar').bootnavbar({
                //option
                //animation: false
            });
        })
    </script>

</body>
</html>