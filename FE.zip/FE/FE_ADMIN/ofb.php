<!DOCTYPE html>
<html>
<head>
    <title> Other facilities Feedback</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 

    <link rel="stylesheet" type="text/css" href="swiper.min.css">

    <!-- Bootnavbar.css -->

     <link href="css/bootnavbar.css" rel="stylesheet">

</head>
<body class="bg">

   
    <header>
<!-- navbar start -->
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main1.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="choose.php">Student information</a>
          <a class="dropdown-item" href="dispoint1.php">Student Marks</a>
        </div>
      </li>
       <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Subject
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="theory_division.php">Regular subject</a>
          <a class="dropdown-item" href="elec_division.php">Elective subject</a>
          <a class="dropdown-item" href="prac_division.php">Practical subject</a>
        </div>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="elecdetail1.php">Elective details</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="eligible1.php">Eligible</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Feedback
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="tft_division.php">Theory Feedback</a>
          <a class="dropdown-item" href="pft_division.php">Practical Feedback</a>
          <a class="dropdown-item" href="libf.php">Library Feedback</a>
           <a class="dropdown-item" href="ofb.php">Other Feedback</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.html" style="color: aqua;">Log out</a>
      </li>
     
    </ul>
  </div>
 </nav>
 <!-- navbar end -->
</header>


 <div class="container">
 <div class="col-lg-12">
 <br><br>
 <h1 class="text-warning text-center" >Auto - Other facilities Feedback</h1>
 <br>

<?php 
error_reporting(0);
$conn=mysqli_connect("localhost","root","","college");
if(!$conn){
    die("connection failed:".mysqli_connect_error());
}


$p="SELECT  AVG(oq1) as q1,AVG(oq2) as q2,AVG(oq3) as q3,AVG(oq4) as q4,AVG(oq4) as q4,AVG(oq5) as q5,AVG(oq6) as q6,AVG(oq7) as q7,AVG(oq8) as q8,AVG(oq9) as q9,AVG(oq10) as q10,AVG(oq11) as q11,AVG(oq12) as q12 FROM feedback_other_fe ";

    $query1 = mysqli_query($conn,$p);
    if(mysqli_num_rows($query1)>0){
    while($result=mysqli_fetch_array($query1)){
?>
     
 
     
     <table  id="tabledata" class=" table table-striped table-hover table-bordered">
        
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Conveyence</td>
            <td><?php echo round($result['q1'],2);   ?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Girl/Boys Room</td>
            <td><?php echo round($result['q2'],2);   ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Lift Facilities</td>
            <td><?php echo round($result['q3'],2);   ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Classrooms</td>
            <td><?php echo round($result['q4'],2);   ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td>Gymkhana</td>
            <td><?php echo round($result['q5'],2);   ?></td>
        </tr>
        <tr>
            <td>6</td>
            <td>Student Activities</td>
            <td><?php echo round($result['q6'],2);   ?></td>
        </tr>
        <tr>
            <td>7</td>
            <td>Canteen</td>
            <td><?php echo round($result['q7'],2);   ?></td>
        </tr>
        <tr>
            <td>8</td>
            <td>Drinking Water</td>
            <td><?php echo round($result['q8'],2);   ?></td>
        </tr>
        <tr>
            <td>9</td>
            <td>Account section</td>
            <td><?php echo round($result['q9'],2);   ?></td>
        </tr>
        <tr>
            <td>10</td>
            <td>Student Section</td>
            <td><?php echo round($result['q10'],2) ;  ?></td>
        </tr>
        <tr>
            <td>11</td>
            <td>Internet Facilities</td>
            <td><?php echo round($result['q11'],2) ;  ?></td>
        </tr>
        <tr>
            <td>12</td>
            <td>Exam Section</td>
            <td><?php echo round($result['q12'],2) ;  ?></td>
        </tr>
        <tr>
            <td colspan="2"><b>Total</b></td>
            <td><?php $total= ($result['q1']+$result['q2']+$result['q3']+$result['q4']+$result['q5']+$result['q6']+$result['q7']+$result['q8']+$result['q9']+$result['q10']+$result['q11']+$result['q12'])/12; echo round($total,2);?></td>
        </tr>
         </table> 
 <br><br> 
      
<?php
    }
}



?>
 
 </div>
 </div>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

      <!-- Js for Navbar, Multi-level dropdown -->
      <script src="js/bootnavbar.js" ></script>
        <script>
            $(function () {
                $('#main_navbar').bootnavbar({
                    //option
                    //animation: false
                });
            })
        </script>
</body>
</html>



