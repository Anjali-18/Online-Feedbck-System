<?php

$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";
$conn=new mysqli($servername,$username,$password,$dbname);

session_start();
 	$dept=$_SESSION['Department'];
//  $div=$_POST['div'];
// echo $div;

$sql="SELECT id,grno,name,rno,sts,phone,Adyr,DOB,division,dept,blogp,caste,subcaste FROM studinfo_fe where dept='$dept'";
//echo $sql;
$query=mysqli_query($conn,$sql);
if(mysqli_num_rows($query)>0){
	while($result=mysqli_fetch_array($query)){
		?>
		<form action="delstu_dept.php" method="post">
			<tr>
			<td><?php echo $result['id'] ?></td>
			<td><?php echo $result['grno'] ?></td>
			<td><?php echo $result['name'] ?></td>
			<td><?php echo $result['rno'] ?></td>
			<td><?php echo $result['sts'] ?></td>
			<td><?php echo $result['phone'] ?></td>
			<td><?php echo $result['Adyr'] ?></td>
			<td><?php echo $result['DOB'] ?></td>
			<td><?php echo $result['division'] ?></td> 
			<td><?php echo $result['dept'] ?></td>
			<td><?php echo $result['blogp'] ?></td>
			<td><?php echo $result['caste'] ?></td>
			<td><?php echo $result['subcaste'] ?></td>
			<td> <button class="btn-danger btn" name="delete"><a href="delstu_dept.php?id=<?php echo $result['id']; ?>" class="text-white"> Delete </a>  </button>
		</tr>

		</form>

<?php
	}

	// echo'<script>alert("successfully submitted");
	// 	 			window.location = "info.php";
	//             	</script>';
}
?>