<?php

//select.php

include('database_connection.php');

session_start();
$div=$_SESSION['division'];


$query = "SELECT `id`, `grno`,`rno`, `name`, `division`, `eligible`, `feedback_given` FROM studinfo_fe WHERE division='$div'";

$statement = $connect->prepare($query);

if($statement->execute())
{
 while($row = $statement->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }

 echo json_encode($data);
}

?>
