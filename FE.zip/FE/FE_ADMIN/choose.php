<!DOCTYPE html>
<html>
<head>
	<title>OPTION</title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<!-- Bootnavbar.css -->
<link href="css/bootnavbar.css" rel="stylesheet">

<style type="text/css">
.button {
    background-color: #008000;
  box-shadow: 0 5px 0 darkred;
  color: white;
  padding: 10em 15em;
  position: relative;
  text-decoration: none;
  text-transform: uppercase;
  justify-content: center;
  align-items: center;
 }

.button:hover {
  background-color:#00FF00;
  cursor: pointer;
}

.button:active {
  box-shadow: none;
  top: 5px;
}

/* Non-Demo Styles */
/*body {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}*/
</style>

</head>
<body>

 <!-- navbar start -->

	 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main1.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="choose.php">Student information</a>
          <a class="dropdown-item" href="dispoint1.php">Student Marks</a>
        </div>
      </li>
       <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Subject
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="theory_division.php">Regular subject</a>
          <a class="dropdown-item" href="elec_division.php">Elective subject</a>
          <a class="dropdown-item" href="prac_division.php">Practical subject</a>
        </div>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="elecdetail1.php">Elective details</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="eligible1.php">Eligible</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Feedback
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="tft_division.php">Theory Feedback</a>
          <a class="dropdown-item" href="pft_division.php">Practical Feedback</a>
          <a class="dropdown-item" href="libf.php">Library Feedback</a>
           <a class="dropdown-item" href="ofb.php">Other Feedback</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="faclogin.html" style="color: aqua;">Log out</a>
      </li>
     
    </ul>
  </div>
 </nav>
 <!-- navbar end -->

<div class="container mt-15" style="padding-top: 300px; padding-left: : 50%;">
	<center>
		<form>
	<div class="row mt-15">
		<div class="col-md-6">
		<a href="indis_dept.php" class="button">DEPARTMENT</a>
	</div>
	<div class="col-md-5">
		<a href="indis_division.php" class="button">DIVISION</a>
	</div>
	</div>
		<!-- <button class="btn btn-success" onclick="window.location.href ='indis_dept.php';">DEPARTMENT</button> -->
		<!-- <button class="btn btn-success" onclick="window.location.href ='indis_division.php';">DIVISION</button> -->
	</div>

</form>
	</center>
</div>
</body>
</html>