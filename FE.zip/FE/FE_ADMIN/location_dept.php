<?php
include('conn.php');
$dept=$_POST['Department'];

session_start();
$_SESSION['Department']=$dept;

header('location:indisdept.php');

?>