<?php

include 'conn.php';
session_start();
 	$div=$_SESSION['div'];
	$_SESSION['div']=$div; 

$id = $_GET['id'];


$query = "SELECT `sem_no` FROM theory_fe WHERE `id` = '$id'";

$res=mysqli_query($conn,$query);
while($row=$res->fetch_assoc()){
	$sem_no = $row ['sem_no'];
	echo $sem_no;
}



$q = "DELETE FROM theory_fe WHERE id = '$id'";
echo $q;

 if(mysqli_query($conn,$q))
 {

	 	switch($sem_no)
		{
			case '1': header('location:theory_display.php'); 
						break;
			case '2': header('location:theory_display.php'); 
						break;
		}
	 }else
 	{
 		echo "error";
 	}


?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<input type="hidden"  name="div" class="form-control" value="<?php echo $div;?>"> 
</body>
</html>