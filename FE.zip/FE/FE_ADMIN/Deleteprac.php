<?php

include 'conn.php';

 session_start();
 	$div=$_SESSION['div'];
	$_SESSION['div']=$div; 

$sr_no = $_GET['sr_no'];

$query = "SELECT `sem` FROM prac_fe WHERE `sr_no` = '$sr_no'";

$res=mysqli_query($conn,$query);
while($row=$res->fetch_assoc()){
	$sem = $row ['sem'];
	echo $sem;
}


$q = "DELETE FROM prac_fe WHERE sr_no = '$sr_no'";
echo $q;
 if(mysqli_query($conn,$q))
 {

	 	switch($sem)
		{
			case '1': header('location:displayprac.php'); 
						break;
			case '2': header('location:displayprac.php'); 
						break;
		}
	 }else
 	{
 		echo "error";
 	}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<input type="hidden"  name="div" class="form-control" value="<?php echo $div;?>"> 
</body>
</html>