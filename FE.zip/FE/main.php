<?php
session_start();
$grno=$_SESSION['grno'];

?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 

    <link rel="stylesheet" type="text/css" href="swiper.min.css">
   <!--   <style>
    .bg{
      background-color: aqua;
   }</style> -->
   <style>
    .sp{
      background: grey;
      font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
      font-size: 14px;
      color:#000;
      margin: 0;
      padding: 0;
    }
    .swiper-container {
      width: 100%;
      padding-top: 50px;
      padding-bottom: 50px;
    }
    .swiper-slide {
      background-position: center;
      background-size: cover;
      width: 310px;
      height: 380px;
      background: white;

    }

    .ED{
        background: black;
    }

    .swiper-slide .imgBx img
    {
        width: 100%;
    }
    .swiper-slide .details
    {
        box-sizing: border-box;
        padding: 10px;
    }
    .swiper-slide .details h6
    {
        margin: 0;
        padding: 0;
        font-size: 20px;
        text-align: center;
        line-height: 20px;
    }
    .swiper-slide .details h6 span
    {
        font-size: 16px;
        color: red;
    }
    .card{
      padding: 5px 5px 5px 5px;
    }
  </style>
</head>
<body class="bg">
   
<header>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="studinfo.php">Information</a>
          <a class="dropdown-item" href="point1.php">Marks</a>
        </div>
      </li>
   
      <li class="nav-item">
        <a class="nav-link" href="detail1.php">Feedback</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.html" style="color: aqua;">Log out <?php echo $grno;?></a>
      </li>
     
    </ul>
  </div>
 </nav>
 <!-- navbar end -->
</header>
<section>
  <div class="container-fluid">
    <h2 class="text-center text-capitalize pt-2">Saraswati College of engineering </h2>
    <hr class="w-25 mx-auto pt-2">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
      <img src="img/C1.jpg" class="img-fluid">
      </div>
        <div class="col-lg-6 col-md-6 col-12">
          <h2>ABOUT</h2>
          <hr>
          <p><font style="color: green"><h5>VISION</h5></font>
“To become center of Excellence in Engineering education and research”<br><font style="color: green"><h5>MISSION</h5></font>
“To educate students to become quality technocrats for taking up challenges in all facets of life”</p>
<button class="btn bg-primary text-white" onclick="window.location.href ='https://engineering.saraswatikharghar.edu.in/';">Wanna know me</button>
        </div>
    </div>
  </div>
</section>
<section>
  <div class="container-fluid">
    <h2 class="text-center text-capitalize pt-3">DEPARTMENTS</h2>
    <hr class="w-25 mx-auto pt-3">
    <div class="row text-center mb-4">
      <div class="col-lg-4 col-md-4 col-12">
                <div class="card" style="width:300px; height: 325px;">
          <img class="card-img-top" src="img/comp1.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">COMPUTER</h4>
            <!-- <p class="card-text">Some example text.</p> -->
            <a href="https://engineering.saraswatikharghar.edu.in/department-of-computer-engineering/" class="btn btn-primary">See Profile</a>
          </div>
        </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12">
        <div class="card" style="width:300px; height: 325px;">
          <img class="card-img-top" src="img/it1.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">IT</h4>
            <!-- <p class="card-text">Some example text.</p> -->
            <a href="https://engineering.saraswatikharghar.edu.in/information-technology/" class="btn btn-primary">See Profile</a>
          </div>
        </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12">
        <div class="card" style="width:300px;height: 325px;">
          <img class="card-img-top" src="img/civil.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">CIVIL</h4>
            <!-- <p class="card-text">Some example text.</p> -->
            <a href="https://engineering.saraswatikharghar.edu.in/department-of-civil-engineering/" class="btn btn-primary">See Profile</a>
          </div>
        </div>
        </div>
            </div>

            <div class="row text-center mb-4">
            <div class="col-lg-4 col-md-4 col-12">
                <div class="card" style="width:300px; height: 325px;">
                  <img class="card-img-top" src="img/mech.jpg" alt="Card image">
                  <div class="card-body">
                    <h4 class="card-title">MECHANICAL</h4>
                    <!-- <p class="card-text">Some example text.</p> -->
                    <a href="https://engineering.saraswatikharghar.edu.in/department-of-mechanical-engineering/" class="btn btn-primary">See Profile</a>
                  </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <div class="card" style="width:300px; height: 325px;">
                  <img class="card-img-top" src="img/auto1.jpg" alt="Card image">
                  <div class="card-body">
                    <h4 class="card-title">AUTO MOBILE</h4>
                    <!-- <p class="card-text">Some example text.</p> -->
                    <a href="https://engineering.saraswatikharghar.edu.in/department-of-automobile-engineering/" class="btn btn-primary">See Profile</a>
                  </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <div class="card" style="width:300px; height: 325px;">
                  <img class="card-img-top" src="img/extc.jpg" alt="Card image">
                  <div class="card-body">
                    <h4 class="card-title">EXTC</h4>
                    <!-- <p class="card-text">Some example text.</p> -->
                    <a href="https://engineering.saraswatikharghar.edu.in/department-of-electronic-telecommunication/" class="btn btn-primary">See Profile</a>
                  </div>
                </div>
                </div>
            </div>
  </div>
</section>



<section class="sp">
    <div class="swiper-container col-12">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="imgBx">
                <img src="img/p3.jpg" " style="width: 309px; height: 315px;">
            </div>
                <div class="details">
                    <h6>Dr.Manjusha Deshmukh<br><span>PRINCIPAL</span></h6>
                </div>
              
          </div>

          <div class="swiper-slide">
            <div class="imgBx">
                <img src="img/SB.jpg" " style="width: 309px; height: 315px;">
            </div>
                <div class="details">
                    <h6>Mrs. Sheetal V. Bukkawar<br><span>Dean Administration</span></h6>
                </div>
              
          </div>

           <div class="swiper-slide">
            <div class="imgBx">
                <img src="img/VJ4.jpg" " style="width: 309px; height: 315px;">
            </div>
                <div class="details">
                    <h6>Mrs.Vaishali P.Jadhav<br><span>Dean,Student Career Development</span></h6>
                </div>
              
          </div>

           

           <div class="swiper-slide">
            <div class="imgBx">
                <img src="img/SP.jpg " style="width: 309px; height: 315px;">
            </div>
                <div class="details">
                    <h6>Mrs.Suhasini Parvatikar<br><span>H.O.D of Computer Department</span></h6>
                </div>
              
          </div>

           <div class="swiper-slide">
            <div class="imgBx">
                <img src="img/DKit1.jpg" " style="width: 309px; height: 315px;">
            </div>
                <div class="details">
                    <h6>Mrs. Diksha Gautam Kumar<br><span>H.O.D of IT Department</span></h6>
                </div>
              
          </div>

           <div class="swiper-slide">
            <div class="imgBx">
                <img src="img/NMextc.jpg"  " style="width: 309px; height: 315px;">
            </div>
                <div class="details">
                    <h6>Mrs. Neha Mahajan<br><span>H.O.D EXTC</span></h6>
                </div>
              
          </div>

           <div class="swiper-slide">
            <div class="imgBx">
                <img src="img/MSmech.jpg" " style="width: 309px; height: 315px;">
            </div>
                <div class="details">
                    <h6>Mr. Madhukar Sorte<br><span>H.O.D Mechanical Department</span></h6>
                </div>
              
          </div>

           <div class="swiper-slide">
            <div class="imgBx">
                <img src="img/QZauto.jpg" " style="width: 309px; height: 315px;">
            </div>
                <div class="details">
                    <h6>Mr. Quazi Zaheeruddin<br><span>H.O.D Automobile Department</span></h6>
                </div>
              
          </div>

          
        </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
   <script type="text/javascript" src="swiper.min.js"></script>
   <script>
    var swiper = new Swiper('.swiper-container', {
      effect: 'coverflow',
      grabCursor: true,
      centeredSlides: true,
      slidesPerView: 'auto',
      coverflowEffect: {
        rotate: 60,
        stretch: 0,
        depth: 500,
        modifier: 1,
        slideShadows : true,
      },
      pagination: {
        el: '.swiper-pagination',
      },
    });
  </script>
</section>

<section class="bg-primary">
    <article class="py-3 text-center">
        <div>
            <h3 class="display-5 text-white">(022) 27743712</h3>
            <p>IF you want to know more contact here.</p>
            <button class="btn btn-warning" onclick="window.location.href='https://engineering.saraswatikharghar.edu.in/contact-us/';">Contact Now</button>
        </div>

    </article>

</section>
<section class="ED">
    <article class="py-3">
        <div>
        <font><h4 class="display-5 text-white">SARASWATI COLLEGE OF ENGINEERING,KHARGHAR</h4></font>
        <font color="yellow"><h4><p class="mt-2 mb-1">Address:-</p></h4></font>
        <p class="display-5 text-white">Plot No.-46, Sector-5,Behind MSEB sub station, Kharghar, Navi Mumbai-410210.</p>
        <p><font style="color: white;"><h5><i class="fa fa-envelope" style="color: green;"></i>  registrarsaraswati@gmail.com</h5><h5><i class="fa fa-facebook" style="color: green;"></i>   https://m.facebook.com/scoe.official.page</h5></font></p>
        </div>
    </article>

</section>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  </body> 
</html>
 