<?php
error_reporting(0);
$conn=mysqli_connect("localhost","root","","college");
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}


session_start();
$sem=$_SESSION['sem'];
$grno=$_SESSION['grno'];
$Adyr=$_SESSION['Adyr'];
$division=$_SESSION['division'];
//echo $division;
$dept=$_SESSION['department'];

// echo "Sem no:",$sem;
// echo "\n Gr no is: ",$grno;


// //Libraryyyy
/*CREATE TABLE `college`.`feedback_library_auto` ( `grno` VARCHAR(20) NOT NULL , `sem` INT(3) NOT NULL , `q1` FLOAT(5) NOT NULL , `q2` FLOAT(5) NOT NULL , `q3` FLOAT(5) NOT NULL , `q4` FLOAT(5) NOT NULL , `avg` FLOAT(5) NOT NULL , PRIMARY KEY (`grno`)) ENGINE = InnoDB;

CREATE TABLE `college`.`feedback_library_civil` ( `grno` VARCHAR(20) NOT NULL , `sem` INT(3) NOT NULL ,`department` VARCHAR(30) NOT NULL,`division` VARCHAR(3) NOT NULL, `q1` FLOAT(5) NOT NULL , `q2` FLOAT(5) NOT NULL , `q3` FLOAT(5) NOT NULL , `q4` FLOAT(5) NOT NULL , `avg` FLOAT(5) NOT NULL , PRIMARY KEY (`grno`)) ENGINE = InnoDB;

*/


$libq1=$_POST['libq1'];
$libq2=$_POST['libq2'];
$libq3=$_POST['libq3'];
$libq4=$_POST['libq4'];

$library_avg=(($libq1+$libq2+$libq3+$libq4)/4);
//echo "Library avg is: ",$library_avg;

$lib="INSERT INTO feedback_library_fe(`grno`, `sem`,`Department`,`division`, `q1`, `q2`, `q3`, `q4`, `avg`) VALUES ('$grno','$sem','$dept','$division','$libq1','$libq2','$libq3','$libq4','$library_avg')";

if(mysqli_query($conn,$lib))
{
	echo '<script>confirm("Library feedback submitted successfully, please enter other facilties feedback");
	window.location = "feedback.php";
	</script>';
	
}else
{
	echo '<script>confirm("Submission Failed");
	window.location = "feedback.php";
	</script>';
	
}

?>