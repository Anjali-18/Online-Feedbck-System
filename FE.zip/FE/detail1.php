<?php
session_start();
$grno=$_SESSION['grno'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Feedback</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	 <header>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="main.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="studinfo.php">Information</a>
          <a class="dropdown-item" href="point1.php">Marks</a>
        </div>
      </li>
   
      <li class="nav-item">
        <a class="nav-link" href="detail1.php">Feedback</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.html" style="color: aqua">Log out <?php echo $grno;?></a>
      </li>
     
    </ul>
  </div>
 </nav>
 <!-- navbar end -->
</header>
	<center><h3 style=" color: blue;" class="mt-3">Feedback Login</h3></center>
<form action="detail.php" method="POST">
	<div class="Container">
		<div class="row mt-5">
		<div class="col-md-4"></div>
		<div class="col-md-4">
			GR NO.:
			<input type="text" name="grno" class="form-control">
		</div>
		</div>

		<div class="row mt-3">
		<div class="col-md-4"></div>
		<div class="col-md-4">
			Academic Year:
			<select class="form-control" name="Adyr">
		  		<option></option>
		  		<option>FE</option>
		  	</select>
		</div>
		</div>

		<div class="row mt-3">
		<div class="col-md-4"></div>
		<div class="col-md-4">
			DIVISION:
			 <select class="form-control" name="division">
                <option>Select Division</option>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
                <option value="E">E</option>
                <option value="F">F</option>
                <option value="G">G</option>
                <option value="H">H</option>
                <option value="I">I</option>
               </select>
		</div>
		</div>

		<div class="row mt-3">
		<div class="col-md-4"></div>
		<div class="col-md-4">
			SEMESTER:
			<select name="sem"  id="selection" class="form-control" required>
		        <option value="#">Select Semester</option>
				<option value="1">Sem 1</option>
				<option value="2">Sem 2</option>
			</select>
		</div>
		</div>

		<div class="row mt-3">
		<div class="col-md-4"></div>
		<div class="col-md-4">
			PASSWORD:
			<input type="password" name="password" class="form-control">
		</div>
		</div>

		<div class="row mt-5">
			<div class="col-md-4"></div>
			<div class="col-md-4">
			<center><button type="submit" class="btn btn-success form-control">SUBMIT</button></center>
			</div>
		</div>

	</div>

</form>
</body>
</html>