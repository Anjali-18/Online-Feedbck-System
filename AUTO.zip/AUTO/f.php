<?php  
function fetch_data()  
{  
error_reporting(0);
$conn=mysqli_connect("localhost","root","","college");
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}

$f="Select distinct fac1 from feedback_auto_be where fac1!='NULL'";
    $s=mysqli_query($conn,$f);
    $datas= array();
    if(mysqli_num_rows($s)>0){
    while($row= mysqli_fetch_assoc($s)){
        $datas[]= $row;
    }
}
print_r($datas);
 for ($i=0; $i <sizeof($datas) ; $i++) { 
 	foreach($datas[$i] as $data){
$output = '';  
echo "$data";
$sql = "SELECT  AVG(s1q1) as s1q1,AVG(s1q2) as s1q2,AVG(s1q3) as s1q3,AVG(s1q4) as s1q4,AVG(s1q5) as s1q5,AVG(avg1) as avg1 FROM feedback_auto_be WHERE fac1 = '".$data."' GROUP BY fac1";  
$result = mysqli_query($conn, $sql);  
while($row = mysqli_fetch_array($result))  
{       
$output .= '        
        <tr>
            <td>1</td>
            <td>Understanding content delivery of lecture</td>
            <td>'. $result['s1q1'].'</td>
        </tr>
        <tr>
            <td>2</td>
            <td>Communication skills / presentation ability of teacher</td>
            <td>'. $result['s1q2'].'</td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are  the lectures lively, interactive & interesting?</td>
            <td>'. $result['s1q3'].' </td>
        </tr>
        <tr>
            <td>4</td>
            <td>Efforts put in by teacher to give additional information</td>
            <td>'. $result['s1q4'].'</td>
        </tr>
        <tr>
            <td>5</td>
            <td>Appreciation and motivation by teacher to solve the difficulties</td>
            <td>'.$result['s1q5'].'</td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td>. $total= ('.$result['s1q1'].'+'.$result['s1q2'].'+'.$result['s1q3'].'+'.$result['s1q4'].'+'.$result['s1q5'].')/5; echo $total;.</td>
        </tr>
         
 <br><br>   
';

}
}
} 
  
return $output;  
}  
if(isset($_POST["generate_pdf"]))  
{  
require_once('TCPDF-master/tcpdf.php');  
$obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
$obj_pdf->SetCreator(PDF_CREATOR);  
$obj_pdf->SetTitle("Generate HTML Table Data To PDF From MySQL Database Using TCPDF In PHP");  
$obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
$obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
$obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
$obj_pdf->SetDefaultMonospacedFont('helvetica');  
$obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
$obj_pdf->SetMargins(PDF_MARGIN_LEFT, '10', PDF_MARGIN_RIGHT);  
$obj_pdf->setPrintHeader(false);  
$obj_pdf->setPrintFooter(false);  
$obj_pdf->SetAutoPageBreak(TRUE, 10);  
$obj_pdf->SetFont('helvetica', '', 11);  
$obj_pdf->AddPage();  
$content = '';  
$content .= '  
<h4 align="center">Generate HTML Table Data To PDF From MySQL Database Using TCPDF In PHP</h4><br /> 
<table border="1" cellspacing="0" cellpadding="3">  
<tr>  
<th>Srno</th>
<th>Questions</th>
<th>Feedback</th>  
</tr>  

';  
$content .= fetch_data();  
$content .= '</table>';  
$obj_pdf->writeHTML($content);  
$obj_pdf->Output('theoryfeedback.pdf', 'I');  
}  
?>  
<!DOCTYPE html>
<html>
<head>
	<title>calculation average</title>

 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

</head>
<body>
 <div class="container">
 <div class="col-lg-12">
 <br><br>
 <h1 class="text-warning text-center" > Display Table Data </h1>
 <br>

<div class="table-responsive">  
<div class="col-md-12" align="right">
<form method="post">  
<input type="submit" name="generate_pdf" class="btn btn-success" value="Generate PDF" />  
</form>  
</div>
<br/>
<br/>
<table  id="tabledata" class=" table table-striped table-hover table-bordered">
        <!-- <tr> -->
            <!-- <th colspan="3"><?php ///for ($i=0; $i <sizeof($datas) ; $i++) { 
 	//foreach($datas[$i] as $data){ echo $data;}}?></th> -->
        <!-- </tr> -->
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >


<?php  
echo fetch_data();  
?>  
</table>  
</div>  
</div>  
</body>  
</html>