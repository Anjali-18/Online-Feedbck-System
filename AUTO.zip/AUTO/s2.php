
<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";

	$name=$_POST['name']; 
	echo $name;
	$grno=$_POST['grno'];
	$phone=$_POST['phone'];
	$Adyr=$_POST['Adyr'];
	$DOB=$_POST['DOB'];
	$division=$_POST['division'];     
	$dept=$_POST['dept'];
	$blogp=$_POST['blogp'];
	$caste=$_POST['caste'];
	$subcaste=$_POST['subcaste'];
	$SE='SE';
	$TE='TE';
	$BE='BE';
	
	session_start();
   	$_SESSION['name'] = "$name";
   	
   	$conn=new mysqli($servername,$username,$password,$dbname);
   	echo "connected";
	if($conn->connect_error)
	{
		die("Connectivity Error:".$conn->connect_error);
	}
	else
	{
		if($SE==$Adyr){
			$sql="insert into studinfo_auto_se(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
				echo $sql;
				if(mysqli_query($conn,$sql))
				{
					echo'<script>alert("successfully submitted");
			 		 window.location = "point.html";
		            </script>';
			 	}
				 else
			 	{
			 		echo '<script>alert("Failed submit");
		           
		            </script>';
			 	}
			 }else{
			 	if($TE==$Adyr){
			 		$sql="insert into studinfo_auto_te(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
						echo $sql;
						if(mysqli_query($conn,$sql))
						{
							echo'<script>alert("successfully submitted");
					 		 window.location = "point.html";
				            </script>';
					 	}
						 else
					 	{
					 		echo '<script>alert("Failed submit");
				           
				            </script>';
					 	}
					 }else{
					 	if ($BE==$Adyr) {
					 		$sql="insert into studinfo_auto_be(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
								echo $sql;
								if(mysqli_query($conn,$sql))
								{
									echo'<script>alert("successfully submitted");
							 		 window.location = "point.html";
						            </script>';
							 	}
								 else
							 	{
							 		echo '<script>alert("Failed submit");
						           
						            </script>';
							 	}
					 		}
						}	
			 		}
	 	
	}

	$conn->close();
?>
