<?php include('Regi.php')?>
<!DOCTYPE html>
<html>
<head>
	<title>STUDENT REGISTRATION</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="css/bootstrap.theme.min.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet" type="text/css">

	<!-- <script rel="stylesheet" href="css/bootstrap.min.css" type="text/css"></script> -->

	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    

<style>
	body, html {
  		height: 100%;
  		margin: 0;
		}
.bg {
  /* The image used */
  background-image: url(img/C2.jpg);

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  
  background-repeat: no-repeat;
  background-size: cover;
}
	.icon{
		color: green;
	}
	.c{
		color: blue;
	}
	.c1{
		color: red;
	}
</style>


</head>
<body>

<form class="form-horizontal bg" id="validateForm" action="detail.php" method="POST" autocomplete="off">
	<section style="padding-top: 30px; padding-bottom: 20px;">
		<center><h2><label class="c">Feedback Login</label></h2></center>
	</section>
<div class="row">
	<div class="Container">
		<div <?php if (isset($error1)): ?> class="form_error" <?php endif ?> >
		  <div class="form-group">
			<label class="control-label c">GRNO:</label>
			 
			<input  name="full_name" placeholder="Full Name" class="form-control"  type="text" value="<?php error_reporting(0); echo $full_name;?>">
		
		  </div>
		<?php if (isset($error1)): ?>
	  	<span class="c1"><?php echo $error1; ?></span>
		<?php endif?>
		</div>
		  
		<div class="row mt-3">
		<div class="col-md-4"></div>
		<div class="col-md-4">
			Academic Year:
			<select class="form-control" name="Adyr">
		  		<option></option>
		  		<option>FE</option>
		  		<option>SE</option>
		  		<option>TE</option>
		  		<option>BE</option>
		  	</select>
		</div>
		</div>

		<div class="row mt-3">
		<div class="col-md-4"></div>
		<div class="col-md-4">
			SEMESTER:
			<select name="sem"  id="selection" class="form-control" required>
		        <option value="#">Select Semester</option>
				<option value="1">sem 1</option>
				<option value="2">Sem 2</option>
				<option value="3">Sem 3</option>
				<option value="4">sem 4</option>
				<option value="5">sem 5</option>
				<option value="6">sem 6</option>
				<option value="7">sem 7</option>
				<option value="8">sem 8</option>
			</select>
		</div>
		</div>

		<div class="row mt-3">
		<div class="col-md-4"></div>
		<div class="col-md-4">
			PASSWORD:
			<input type="password" name="password" class="form-control">
		</div>
		</div>

		<div class="row mt-5">
			<div class="col-md-4"></div>
			<div class="col-md-4">
			<center><button type="submit" class="btn btn-success form-control">SUBMIT</button></center>
			</div>
		</div>
	</div>
</body>
</html>