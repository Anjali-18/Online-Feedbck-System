<?php
    $servername="localhost";
	$username="root";
	$password="";
	$dbname="college";

session_start(); 
   $grno=$_SESSION['grno'];
   $Adyr=$_SESSION['Adyr'];
echo $Adyr;
    $SE='SE';
    $TE='TE';
    $BE='BE';

	$conn=new mysqli($servername,$username,$password,$dbname);
	if($conn->connect_error)
	{
		die("Connectivity Error:".$conn->connect_error);
	}
    if($Adyr==$SE){
        $sql2= "select * from studinfo_auto_se where grno='$grno'";
        $result2=mysqli_query($conn,$sql2);
        while ($row = $result2->fetch_assoc()) {
             $phone= $row['phone'];
             $DOB= $row['DOB'];
             $division= $row['division'];
             $blogp= $row['blogp'];
             $caste= $row['caste'];
             $subcaste= $row['subcaste'];
          
        }
    }else{
        if($Adyr==$TE){
            $sql2= "select * from studinfo_auto_te where grno='$grno'";
            $result2=mysqli_query($conn,$sql2);
            while ($row = $result2->fetch_assoc()) {
                 $phone= $row['phone'];
                 $DOB= $row['DOB'];
                 $division= $row['division'];
                 $blogp= $row['blogp'];
                 $caste= $row['caste'];
                 $subcaste= $row['subcaste'];
              
            }
        }else{
            if($Adyr==$BE){
                $sql2= "select * from studinfo_auto_be where grno='$grno'";
                $result2=mysqli_query($conn,$sql2);
                while ($row = $result2->fetch_assoc()) {
                     $phone= $row['phone'];
                     $DOB= $row['DOB'];
                     $division= $row['division'];
                     $blogp= $row['blogp'];
                     $caste= $row['caste'];
                     $subcaste= $row['subcaste'];
                  
                }
            }
        }
    }
	
		$sql1="select grno,full_name,department,year from reg_auto where grno='$grno'";
		$result=mysqli_query($conn,$sql1);
	while ($row=mysqli_fetch_array($result)) {
		?>

<!DOCTYPE html>
<html>
<head>
    <title>valid</title>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 




<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>


<style>
	.colr{
		color: blue;
	}
</style>




</head>
<body>
<header>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="studinfo.php">Information</a>
          <a class="dropdown-item" href="point.html">Marks</a>
        </div>
      </li>
   
      <li class="nav-item">
        <a class="nav-link" href="feedback4.php">Feedback</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.html">Log out</a>
      </li>
     
    </ul>
  </div>
 </nav>
 <!-- navbar end -->
</header>

<form class="container" action="s2.php" method="POST" autocomplete="off">
    <section>
        <center><h4><label style="color: blue;padding-top: 20px;">STUDENT INFORMATION</label></h4></center>
    </section>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-4">
            <label class="colr">Full name</label>
            <input type="text" name="name" id="fname" class="form-control" required value="<?php echo $row['full_name']; ?>">
            <h6 id="namecheck"></h6>
        </div>
        
        <div class="col-md-4">
            <label class="colr">GR number</label>
            <input type="text" name="grno" id="grnu" class="form-control" value="<?php echo $row['grno']; ?>" required>
            <h6 id="grnocheck"></h6>
        </div>
    </div><br>

    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-4">
            <label class="colr">Phone number</label>
            <input type="text" name="phone" id="phn" class="form-control" value="<?php error_reporting(0);  echo "$phone"; ?>" required>
            <h6 id="phoncheck"></h6>
        </div>
        <div class="col-md-4">
            <label class="colr">Admission year</label>
            <input type="text" name="Adyr" id="Ayr" class="form-control" value="<?php echo $row['year']; ?>" required>
            <h6 id="Adyrcheck"></h6>
        </div>
    </div><br>

    <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-4">
                <label class="colr">Date of Birth:</label>
                <input class="form-control" name="DOB" id="dateB" placeholder="Enter your date of Birth" type="date" value="<?php error_reporting(0);  echo "$DOB"; ?>" required>
                <h6 id="DOBcheck"></h6>
            </div>
            <div class="col-md-4">
                <label class="colr">division</label>
                <input class="form-control" type="text" placeholder="Enter your division" name="division" id="ag" value="<?php error_reporting(0);  echo "$division"; ?>" required>
                <h6 id="agecheck"></h6>
            </div> 
        </div><br>

        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-4">
                    <label class="colr">Branch:</label>
                    <input class="form-control" name="dept" id="Brch" placeholder="Enter your Branch" type="text" value="<?php echo $row['department']; ?>" required>
                    <h6 id="Branchcheck"></h6>
            </div>
            <div class="col-md-4">
                <label class="colr">Blood group:</label>
                <select name="blogp" class="form-control" required>
                    <option></option>
                    <option>O+</option>
                    <option>O-</option>
                    <option>AB+</option>
                    <option>AB-</option>
                    <option>A+</option>
                    <option>A-</option>
                    <option>B+</option>
                    <option>B-</option>
                </select>
            </div>
        </div><br>

        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-4">
                <label class="colr">Caste</label>
                <select class="form-control" name="caste" type="text" required>
                        <option></option>
                        <option>Open</option>
                        <option>OBC</option>
                        <option>SC</option>
                        <option>ST</option>
                        <option>SBC</option>
                        <option>SEBC</option>
                        <option>NT</option>
                        <option>EWS</option>
                        <option>VJ</option>
                    </select>
            </div>
            <div class="col-md-4">
                <label class="colr">Sub Caste:</label>
                <input type="text" name="subcaste" id="scaste" class="form-control" value="<?php error_reporting(0);  echo "$subcaste"; ?>"  required>
                <h6 id="subcastecheck"></h6>
            </div>
        </div><br>


    <section>
        <div>
            <center><button type="Submit" name="submit" class="btn btn-success">Submit</button> <button  type="Submit" class="btn btn-primary" onclick="window.location.href ='point.html';">Next</button></center>
        </div>
    </section>
    
</form>


<script type="text/javascript">
    $(document).ready(function(){

        $('#namecheck').hide();
        $('#grnocheck').hide();
        $('#phoncheck').hide();
        $('#Adyrcheck').hide();
        $('#DOBcheck').hide();
        $('#agecheck').hide();
        $('#Branchcheck').hide();
        $('#subcastecheck').hide();

        var name_err=true;
        var grno_err=true;
        var phon_err=true;
        var Adyr_err=true;
        var DOB_err=true;
        var age_err=true;
        var branch_err=true;
        var subcaste_err=true;


        $('#fname').keyup(function(){
            name_check();
        });

       function name_check(){
            var name_val= $('#fname').val();

             if(!isNaN(name_val)){
                $('#namecheck').show();
                $('#namecheck').html("*Please enter only character ");
                $('#namecheck').focus();
                $('#namecheck').css("color","red");
                name_err=false;
                return false;
                }
                else{
                    $('#namecheck').hide();
                }



            if(name_val.length<5){
                $('#namecheck').show();
                $('#namecheck').html("*Please enter minimum 4 character ");
                $('#namecheck').focus();
                $('#namecheck').css("color","red");
                name_err=false;
                return false;
                }
                else{
                    $('#namecheck').hide();
                }

            }

             $('#grnu').keyup(function(){
                        grno_check();
                    });

                 function grno_check(){
                var grno_val= $('#grnu').val();
                if((grno_val.length<8)||(grno_val.length>8)){
                $('#grnocheck').show();
                $('#grnocheck').html("*Please enter valid GR number");
                $('#grnocheck').focus();
                $('#grnocheck').css("color","red");
                grno_err=false;
                return false;
                }
                else{
                    $('#grnocheck').hide();
                
                }
            }

              $('#phn').keyup(function(){
                        phone_check();
                    });

                 function phone_check(){
                var phone_val= $('#phn').val();

                if(isNaN(phone_val)){
                $('#phoncheck').show();
                $('#phoncheck').html("*Please enter valid phone number");
                $('#phoncheck').focus();
                $('#phoncheck').css("color","red");
                phon_err=false;
                return false;
                }
                else{
                    $('#phoncheck').hide();
                
                }

                if(phone_val.length!=10){
                $('#phoncheck').show();
                $('#phoncheck').html("*Please enter valid phone number");
                $('#phoncheck').focus();
                $('#phoncheck').css("color","red");
                phon_err=false;
                return false;
                }
                else{
                    $('#phoncheck').hide();
                
                }
            }


            $('#Ayr').keyup(function(){
                        Adyr_check();
                    });

                 function Adyr_check(){
                var Adyr_val= $('#Ayr').val();
                 if(!isNaN(Adyr_val)){
                $('#Adyrcheck').show();
                $('#Adyrcheck').html("*Please enter valid Admission year");
                $('#Adyrcheck').focus();
                $('#Adyrcheck').css("color","red");
                Adyr_err=false;
                return false;
                }
                else{
                    $('#Adyrcheck').hide();
                
                }

                if((Adyr_val.length<4)||(Adyr_val.length>4)){
                $('#Adyrcheck').show();
                $('#Adyrcheck').html("*Please enter valid Admission year");
                $('#Adyrcheck').focus();
                $('#Adyrcheck').css("color","red");
                Adyr_err=false;
                return false;
                }
                else{
                    $('#Adyrcheck').hide();
                
                }

            }

          
            $('#ag').keyup(function(){
                        age_check();
                    });

                 function age_check(){
                var age_val= $('#ag').val();
                 if(!isNaN(age_val) || age_val < 2){
                $('#agecheck').show();
                $('#agecheck').html("*Please enter valid division");
                $('#agecheck').focus();
                $('#agecheck').css("color","red");
                age_err=false;
                return false;
                }
                else{
                    $('#agecheck').hide();
                
                }
            }


       $('#Brch').keyup(function(){
            branch_check();
        });

       function branch_check(){
            var branch_val= $('#Brch').val();
             if(!isNaN(branch_val)){
                $('#Branchcheck').show();
                $('#Branchcheck').html("*Please enter only character");
                $('#Branchcheck').focus();
                $('#Branchcheck').css("color","red");
                name_err=false;
                return false;
                }
                else{
                    $('#Branchcheck').hide();
                }

            if(branch_val.length<2){
                $('#Branchcheck').show();
                $('#Branchcheck').html("*Please enter valid Branch ");
                $('#Branchcheck').focus();
                $('#Branchcheck').css("color","red");
                branch_err=false;
                return false;
                }
                else{
                    $('#Branchcheck').hide();
                }

            }


             $('#scaste').keyup(function(){
            subcaste_check();
        });

       function subcaste_check(){
            var subcaste_val= $('#scaste').val();
             if(!isNaN(subcaste_val)){
                $('#subcastecheck').show();
                $('#subcastecheck').html("*Please enter only character");
                $('#subcastecheck').focus();
                $('#subcastecheck').css("color","red");
                subcaste_err=false;
                return false;
                }
                else{
                    $('#subcastecheck').hide();
                }

            if(subcaste_val.length<2){
                $('#subcastecheck').show();
                $('#subcastecheck').html("*Please enter valid subcaste ");
                $('#subcastecheck').focus();
                $('#subcastecheck').css("color","red");
                subcaste_err=false;
                return false;
                }
                else{
                    $('#subcastecheck').hide();
                }

            }


    });


</script>
</body>
</html>
		<?php 
	} 