<?php

include 'conn.php';

$sr_no = $_GET['sr_no'];

$query = "SELECT `sem` FROM prac_auto WHERE `sr_no` = '$sr_no'";

$res=mysqli_query($conn,$query);
while($row=$res->fetch_assoc()){
	$sem = $row ['sem'];
	echo $sem;
}


$q = "DELETE FROM prac_auto WHERE sr_no = '$sr_no'";
echo $q;
 if(mysqli_query($conn,$q))
 {

	 	switch($sem)
		{
			case '3': header('location:displayprac_se.php'); 
						break;
			case '4': header('location:displayprac_se.php'); 
						break;
			case '5': header('location:displayprac_te.php'); 
						break;
			case '6': header('location:displayprac_te.php'); 
						break;
			case '7': header('location:displayprac_be.php'); 
						break;
			case '8': header('location:displayprac_be.php'); 
						break;
		}
	 }else
 	{
 		echo "error";
 	}

?>