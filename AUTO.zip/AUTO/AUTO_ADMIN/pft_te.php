<!DOCTYPE html>
<html>
<head>
    <title>BE Auto - Practical Feedback</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 

    <link rel="stylesheet" type="text/css" href="swiper.min.css">

    <!-- Bootnavbar.css -->

     <link href="css/bootnavbar.css" rel="stylesheet">

</head>
<body class="bg">

    <header>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark" id="main_navbar">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College of Engineering</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">

                <!-- HOME  -->
                <li class="nav-item active">
                    <a class="nav-link" href="main1.html">Home <span class="sr-only">(current)</span></a>
                </li>
                <!-- STUDENT -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        Student
                    </a>

                    <!-- STUDENT MARKS -->
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student Marks
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="dispoint_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="dispoint_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="dispoint_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                            <!-- STUDENT INFORMATION -->

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student information
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="indis_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="indis_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="indis_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                    </ul>
                    <!-- SUBJECT -->
    <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Subject
            </a>
         
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        
                        <!-- THEORY SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Theory Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="theory_display_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="theory_display_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="theory_display_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                        <!-- Elective SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Elective Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayelec_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="displayelec_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="displayelec_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                        <!-- PRACTICAL SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Practical Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayprac_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="displayprac_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="displayprac_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
            </ul>
      </li>

      <!--Elective Details  -->
       <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Elective Details
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">SE</a>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">TE</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_be.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">BE</a>  
                        </li>
            </ul>
      </li>

      <!-- Individual Feedback Report  -->
      <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Individual Feedback
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Theory</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="tft_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="tft_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="tft_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Practical</a> 
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="pft_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="pft_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="pft_be.php">BE</a></li>
                                    
                                    </li>
                                </ul> 
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="lfb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Library</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="ofb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Other Facilities</a>  
                        </li>
            </ul>
      </li>

      <!-- Final Feedback Report -->
      <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Final Feedback
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Theory</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="lt_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="lt_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="lt_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Practical</a> 
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="lp_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="lp_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="lp_be.php">BE</a></li>
                                    
                                    </li>
                                </ul> 
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="lfb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Library</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="ofb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Other Facilities</a>  
                        </li>
            </ul>
      </li>
      <!-- ELIGIBILITY -->
       <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Eligibility
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">SE</a>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">TE</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_be.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">BE</a>  
                        </li>
            </ul>
      </li>
    <!-- LOG OUT -->
      <li class="nav-item">
        <a class="nav-link" href="login.html">Log out</a>
      </li>
                    
                       
 </ul>        
        </div>
    </nav>


 <!-- navbar end -->
</header>


 <div class="container">
 <div class="col-lg-12">
 <br><br>
 <h1 class="text-warning text-center" > BE Auto - Average Practical Feedback </h1>
 <br>




<?php
error_reporting(0);
$conn=mysqli_connect("localhost","root","","college");
if(!$conn){
    die("connection failed:".mysqli_connect_error());
}

$f="Select distinct fac1 from feedprac_auto_te where fac1!=''";
    $s=mysqli_query($conn,$f);
    $datas= array();
    if(mysqli_num_rows($s)>0){
    while($row= mysqli_fetch_assoc($s)){
        $datas[]= $row;
    }
}

$f1="Select distinct fac2 from feedprac_auto_te where fac2!=''";
    $s1=mysqli_query($conn,$f1);
    $datas1= array();
    if(mysqli_num_rows($s1)>0){
    while($row1= mysqli_fetch_assoc($s1)){
        $datas1[]= $row1;
    }
}

$f2="Select distinct fac3 from feedprac_auto_te where fac3!=''";
    $s2=mysqli_query($conn,$f2);
    $datas2= array();
    if(mysqli_num_rows($s2)>0){
    while($row2= mysqli_fetch_assoc($s2)){
        $datas2[]= $row2;
    }
}

$f3="Select distinct fac4 from feedprac_auto_te where fac4!=''";
    $s3=mysqli_query($conn,$f3);
    $datas3= array();
    if(mysqli_num_rows($s3)>0){
    while($row3= mysqli_fetch_assoc($s3)){
        $datas3[]= $row3;
    }
}

$f4="Select distinct fac5 from feedprac_auto_te where fac5!=''";
    $s4=mysqli_query($conn,$f4);
    $datas4= array();
    if(mysqli_num_rows($s4)>0){
    while($row4= mysqli_fetch_assoc($s4)){
        $datas4[]= $row4;
    }
}

$f5="Select distinct fac6 from feedprac_auto_te where fac6!=''";
    $s5=mysqli_query($conn,$f5);
    $datas5= array();
    if(mysqli_num_rows($s5)>0){
    while($row5= mysqli_fetch_assoc($s5)){
        $datas5[]= $row5;
    }
}

// $f6="Select distinct fac7 from feedprac_auto_te where fac7!='NULL'";
//     $s6=mysqli_query($conn,$f6);
//     $datas6= array();
//     if(mysqli_num_rows($s6)>0){
//     while($row6= mysqli_fetch_assoc($s6)){
//         $datas6[]= $row6;
//     }
// }

// $f7="Select distinct fac8 from feedprac_auto_te where fac8!='NULL'";
//     $s7=mysqli_query($conn,$f7);
//     $datas7= array();
//     if(mysqli_num_rows($s7)>0){
//     while($row7= mysqli_fetch_assoc($s7)){
//         $datas7[]= $row7;
//     }
// }

// $f8="Select distinct fac9 from feedprac_auto_te where fac9!='NULL'";
//     $s8=mysqli_query($conn,$f8);
//     $datas8= array();
//     if(mysqli_num_rows($s8)>0){
//     while($row8= mysqli_fetch_assoc($s8)){
//         $datas8[]= $row8;
//     }
// }

// $f9="Select distinct fac10 from feedprac_auto_te where fac10!='NULL'";
//     $s9=mysqli_query($conn,$f9);
//     $datas9= array();
//     if(mysqli_num_rows($s9)>0){
//     while($row9= mysqli_fetch_assoc($s9)){
//         $datas9[]= $row9;
//     }
// }
    print_r($datas);
    print_r($datas1);
    print_r($datas2);
    print_r($datas3);
    print_r($datas4);
    print_r($datas5);
?>

 
 
 <!-- <tr class="bg-dark text-white text-center">
 
 <th> s1q1 </th>
 <th> s1q2</th>
 <th> s1q3 </th>
 <th> s1q4</th>
 <th> s1q5</th>
 <th> avg1</th> -->

<!-- <tr>
<th>Srno</th>
<th>Questions</th>
<th>Feedback</th>
</tr > -->
                   <!--  <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>         
 -->

<!-- ********************************************************************************************* -->
<!-- fac1 -->
 <?php

 include 'eleconn.php'; 
 for ($i=0; $i <sizeof($datas) ; $i++) { 
    foreach($datas[$i] as $data)
    //$q = "select s1q1,s1q2,s1q3,s1q4,s1q5,avg1,distinct sub1,fac1 from feedprac_auto_te where fac1= $data";
    //echo $q;
    //$query = mysqli_query($conn,$q);
         if ($data != " " || $data != 'NULL' ) {
    $p="SELECT sub1,AVG(p1q1) as p1q1,AVG(p1q2) as p1q2,AVG(p1q3) as p1q3,AVG(p1q4) as p1q4 FROM feedprac_auto_te WHERE fac1 = '".$data."' GROUP BY fac1";

    $query1 = mysqli_query($conn,$p);
    if(mysqli_num_rows($query1)>0){
    while($result=mysqli_fetch_array($query1)){
        ?>
        <table  id="tabledata" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result['sub1'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Involvement of faculty</td>
            <td><?php echo $result['p1q1'];  ?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Avaialability of resources in lab</td>
            <td><?php echo $result['p1q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are the objectives and scopes being explained by the faculty?</td>
            <td><?php echo $result['p1q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Timely evaluation of experiment records</td>
            <td><?php echo $result['p1q4'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total= ($result['p1q1']+$result['p1q2']+$result['p1q3']+$result['p1q4'])/4; echo $total;?></td>
        </tr>
         </table> 
 <br><br> 
      
<?php
    }
}
}
}
?>
<!-- <?php //unset($datas); $datas = array();?>   -->

<!-- **********************fac2************************* -->
<?php
include 'eleconn.php';
 for ($j=0; $j <sizeof($datas1) ; $j++) { 
    foreach($datas1[$j] as $data1)
     if ($data1 != " " || $data1 != 'NULL' ) {
    $p1="SELECT  sub2,AVG(p2q1) as p2q1,AVG(p2q2) as p2q2,AVG(p2q3) as p2q3,AVG(p2q4) as p2q4 FROM feedprac_auto_te WHERE fac2 = '".$data1."' GROUP BY fac2 ";
    echo "$p1";
    $query1 = mysqli_query($conn,$p1);
    if(mysqli_num_rows($query1)>0){
    while($result1=mysqli_fetch_array($query1)){
        ?>
        <table  id="tabledata1" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data1;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result1['sub2'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Involvement of faculty</td>
            <td><?php echo $result1['p2q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Avaialability of resources in lab</td>
            <td><?php echo $result1['p2q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are the objectives and scopes being explained by the faculty?</td>
            <td><?php echo $result1['p2q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Timely evaluation of experiment records</td>
            <td><?php echo $result1['p2q4'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total1= ($result1['p2q1']+$result1['p2q2']+$result1['p2q3']+$result1['p2q4'])/4; echo $total1;?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
}
}
}
?>

<!-- **********************fac3*********************** -->
<?php
include 'eleconn.php';
 for ($j=0; $j <sizeof($datas2) ; $j++) { 
    foreach($datas2[$j] as $data2)
     if ($data2 != " " || $data2 != 'NULL' ) {
    $p2="SELECT  sub3,AVG(p3q1) as p3q1,AVG(p3q2) as p3q2,AVG(p3q3) as p3q3,AVG(p3q4) as p3q4 FROM feedprac_auto_te WHERE fac3 = '".$data2."' GROUP BY fac3 ";
    echo "$p2";
    $query2 = mysqli_query($conn,$p2);
    if(mysqli_num_rows($query2)>0){
    while($result2=mysqli_fetch_array($query2)){
        ?>
        <table  id="tabledata2" class=" table table-striped table-hover table-bordered">
        <tr>
           <th colspan="2"><?php echo" Faculty Name: ", $data2;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result2['sub3'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Involvement of faculty</td>
            <td><?php echo $result2['p3q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Avaialability of resources in lab</td>
            <td><?php echo $result2['p3q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are the objectives and scopes being explained by the faculty?</td>
            <td><?php echo $result2['p3q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Timely evaluation of experiment records</td>
            <td><?php echo $result2['p3q4'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total2= ($result2['p3q1']+$result2['p3q2']+$result2['p3q3']+$result2['p3q4'])/4; echo $total2;?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
}
}
}
?>

<!-- *************************************fac4******************************* -->
<?php
include 'eleconn.php';
 for ($j=0; $j <sizeof($datas3) ; $j++) { 
    foreach($datas3[$j] as $data3)
        if ($data3 != " " || $data3 != 'NULL' ) {
            $p3="SELECT  sub4,AVG(p4q1) as p4q1,AVG(p4q2) as p4q2,AVG(p4q3) as p4q3,AVG(p4q4) as p4q4 FROM feedprac_auto_te WHERE fac4 = '".$data3."' GROUP BY fac4 ";
    echo "$p3";
    $query3 = mysqli_query($conn,$p3);
    if(mysqli_num_rows($query3)>0){
    while($result3=mysqli_fetch_array($query3)){
        ?>
        <table  id="tabledata3" class=" table table-striped table-hover table-bordered">
        <tr>
           <th colspan="2"><?php echo" Faculty Name: ", $data3;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result3['sub4'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Involvement of faculty</td>
            <td><?php echo $result3['p4q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Avaialability of resources in lab</td>
            <td><?php echo $result3['p4q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
             <td>Are the objectives and scopes being explained by the faculty?</td>
            <td><?php echo $result3['p4q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Timely evaluation of experiment records</td>
            <td><?php echo $result3['p4q4'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total3= ($result3['p4q1']+$result3['p4q2']+$result3['p4q3']+$result3['p4q4'])/4; echo $total3;?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
        }
    
}
}
?>

<!-- *************************************fac5 ****************************** -->
<?php
include 'eleconn.php';
 for ($j=0; $j <sizeof($datas4) ; $j++) { 
    foreach($datas4[$j] as $data4)
        if ($data4 != " " || $data4 != 'NULL' ) {
            $p4="SELECT  sub5,AVG(p5q1) as p5q1,AVG(p5q2) as p5q2,AVG(p5q3) as p5q3,AVG(p5q4) as p5q4 FROM feedprac_auto_te WHERE fac5 = '".$data4."' GROUP BY fac5 ";
    echo "$p4";
    $query4 = mysqli_query($conn,$p4);
    if(mysqli_num_rows($query4)>0){
    while($result4=mysqli_fetch_array($query4)){
        ?>
        <table  id="tabledata3" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data4;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result4['sub5'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Involvement of faculty</td>
            <td><?php echo $result4['p5q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Avaialability of resources in lab</td>
            <td><?php echo $result4['p5q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
             <td>Are the objectives and scopes being explained by the faculty?</td>
            <td><?php echo $result4['p5q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Timely evaluation of experiment records</td>
            <td><?php echo $result4['p5q4'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total4= ($result4['p5q1']+$result4['p5q2']+$result4['p5q3']+$result4['p5q4'])/4; echo $total4;?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
        }
    
}
}
?>

<!-- ***********************fac6************************** -->
<?php
include 'eleconn.php';
echo "hi";
 for ($j=0; $j <sizeof($datas5) ; $j++) { 
    foreach($datas5[$j] as $data5)
        if ($data5 != '' || $data5 != 'NULL' ) {
            $p5="SELECT sub6, AVG(p6q1) as p6q1,AVG(p6q2) as p6q2,AVG(p6q3) as p6q3,AVG(p6q4) as p6q4 FROM feedprac_auto_te WHERE fac6 = '".$data5."' GROUP BY fac6 ";
    echo "$p5";
    $query5 = mysqli_query($conn,$p5);
    if(mysqli_num_rows($query5)>0){
    while($result5=mysqli_fetch_array($query5)){
        ?>
        <table  id="tabledata5" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data5;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result5['sub6'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Involvement of faculty</td>
            <td><?php echo $result5['p6q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
             <td>Avaialability of resources in lab</td>
            <td><?php echo $result5['p6q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
             <td>Are the objectives and scopes being explained by the faculty?</td>
            <td><?php echo $result5['p6q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Timely evaluation of experiment records</td>
            <td><?php echo $result5['p6q4'];  ?></td>
        </tr>
        
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total5= ($result5['p6q1']+$result5['p6q2']+$result5['p6q3']+$result5['p6q4'])/4; echo $total5;?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
        }
    
}
}
?>




 </div>
 </div>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

      <!-- Js for Navbar, Multi-level dropdown -->
      <script src="js/bootnavbar.js" ></script>
        <script>
            $(function () {
                $('#main_navbar').bootnavbar({
                    //option
                    //animation: false
                });
            })
        </script>
</body>
</html>

