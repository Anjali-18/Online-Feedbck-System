<html>  
    <head>  
        <title>Update Eligibility - SE Auto</title>
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>   -->

            <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<!-- Bootnavbar.css -->
<link href="css/bootnavbar.css" rel="stylesheet">

<style type="text/css">
    .colr{
        color: yellow;
    }
    .co{
        color: blue;
    }
</style>

    </head>  
    <body>  

<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark" id="main_navbar">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College of Engineering</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">

                <!-- HOME  -->
                <li class="nav-item active">
                    <a class="nav-link" href="main1.html">Home <span class="sr-only">(current)</span></a>
                </li>
                <!-- STUDENT -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        Student
                    </a>

                    <!-- STUDENT MARKS -->
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student Marks
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="dispoint_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="dispoint_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="dispoint_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                            <!-- STUDENT INFORMATION -->

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student information
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="indis_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="indis_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="indis_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                    </ul>
                    <!-- SUBJECT -->
    <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Subject
            </a>
         
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        
                        <!-- THEORY SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Theory Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="theory_display_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="theory_display_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="theory_display_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                        <!-- Elective SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Elective Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayelec_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="displayelec_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="displayelec_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                        <!-- PRACTICAL SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Practical Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayprac_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="displayprac_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="displayprac_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
            </ul>
      </li>

      <!--Elective Details  -->
       <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Elective Details
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">SE</a>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">TE</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_be.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">BE</a>  
                        </li>
            </ul>
      </li>

      <!-- Individual Feedback Report  -->
      <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Individual Feedback
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Theory</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="tft_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="tft_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="tft_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Practical</a> 
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="pft_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="pft_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="pft_be.php">BE</a></li>
                                    
                                    </li>
                                </ul> 
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="lfb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Library</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="ofb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Other Facilities</a>  
                        </li>
            </ul>
      </li>

      <!-- Final Feedback Report -->
      <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Final Feedback
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Theory</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="lt_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="lt_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="lt_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Practical</a> 
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="lp_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="lp_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="lp_be.php">BE</a></li>
                                    
                                    </li>
                                </ul> 
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="lfb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Library</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="ofb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Other Facilities</a>  
                        </li>
            </ul>
      </li>
      <!-- ELIGIBILITY -->
       <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Eligibility
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">SE</a>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">TE</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_be.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">BE</a>  
                        </li>
            </ul>
      </li>
    <!-- LOG OUT -->
      <li class="nav-item">
        <a class="nav-link" href="login.html">Log out</a>
      </li>
                    
                       
 </ul>        
        </div>
    </nav>

 <!-- navbar end -->
<div class="container">  
            <br />
   <div class="table-responsive">  
    <h3 align="center">Update Eligibility - SE Auto</h3><br />
    <form method="post" id="update_form">
                    <div align="left">
                    <input type="submit" name="multiple_update" id="multiple_update" class="btn btn-info" value="Update" />
                    </div>
                    <br />
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th width="2%"></th>
                                <th width="13%">Grno</th>
                                <th width="10%">Roll No.</th>
                                <th width="30%">Name</th>
                                <th width="15%">Division</th>
                                <th width="20%">Eligible</th>
                                <th width="20%">Feedback status</th>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </form>
                  <!-- reset button starts -->
                <div class="col-md-2">
                <form method="POST">
                <button class="btn btn-success" name="reset">Reset Feedback</button>
                        <?php
                            include('conn.php');

                                if(isset($_POST['reset']))
                                {
                                    $sql1="TRUNCATE TABLE feedback_auto_se";
                                    $sql2="TRUNCATE TABLE feedback_library_auto";
                                    $sql3="TRUNCATE TABLE feedback_other_auto";
                                    $sql4="TRUNCATE TABLE feedprac_auto_se";
                                    if(mysqli_query($conn,$sql1)&&mysqli_query($conn,$sql2)&&
                                       mysqli_query($conn,$sql3)&&mysqli_query($conn,$sql4))
                                    {
                                        echo'<script>alert("Feedback reset successfully ");
                                     window.location = "main1.html";
                                    </script>';
                                    }else
                                    {
                                        echo '<script>alert("Already Reset");
                                    window.location = "eligible_se.php";
                                    </script>';
                                    }
                                 }

                            ?>
            </form>
            </div>
             <div class="col-md-4">
                <form  method="POST">
                    <label style="color: red;">Delete Feedback given by Student</label>
                    <input type="text" name="grno" class="form-control mt-2">
                    <button class="btn btn-success mt-4" name="del">Delete
                        <?php 
                        error_reporting(0);
                            include ('conn.php');
                            if(isset($_POST['del'])){
                                 $grno=$_POST['grno'];

                                $q="DELETE FROM `studinfo_auto_se` WHERE  grno='$grno' ";
                                //echo "$q";
                                $result=mysqli_query($conn,$q);
                                if($result){
                                    echo"deleted";
                                }
                                //header('location:eligible_be_a.php');
                                }

                        ?>
                    </button>
                </form>
            </div>

        <!-- reset button ends! -->
   </div>  
  </div>
    </body>  
</html>  
<script>  
$(document).ready(function(){  
    
    function fetch_data()
    {
        $.ajax({
            url:"eligible_select_se.php",
            method:"POST",
            dataType:"json",
            success:function(data)
            {
                var html = '';
                for(var count = 0; count < data.length; count++)
                {
                    html += '<tr>';
                    html += '<td><input type="checkbox" id="'+data[count].id+'" data-grno="'+data[count].grno+'" data-rno="'+data[count].rno+'" data-name="'+data[count].name+'" data-division="'+data[count].division+'" data-eligible="'+data[count].eligible+'" data-feedback_given="'+data[count].feedback_given+'" class="check_box"  /></td>';
                    html += '<td>'+data[count].grno+'</td>';
                    html += '<td>'+data[count].rno+'</td>';
                    html += '<td>'+data[count].name+'</td>';
                    html += '<td>'+data[count].division+'</td>';
                    html += '<td>'+data[count].eligible+'</td>';
                    html += '<td>'+data[count].feedback_given+'</td></tr>';
                }
                $('tbody').html(html);
            }
        });
    }

    fetch_data();

    $(document).on('click', '.check_box', function(){
        var html = '';
        if(this.checked)
        {
            html = '<td><input type="checkbox" id="'+$(this).attr('id')+'" data-grno="'+$(this).data('grno')+'" data-rno="'+$(this).data('rno')+'" data-name="'+$(this).data('name')+'" data-division="'+$(this).data('division')+'" data-eligible="'+$(this).data('eligible')+'" data-feedback_given="'+$(this).data('feedback_given')+'" class="check_box" checked /></td>';
            html += '<td><input type="text" name="grno[]" class="form-control" value="'+$(this).data("grno")+'" readonly/></td>';
            html += '<td><input type="text" name="rno[]" class="form-control" value="'+$(this).data("rno")+'" readonly/></td>';
            html += '<td><input type="text" name="name[]" class="form-control" value="'+$(this).data("name")+'" readonly/></td>';
           
            html += '<td><input type="text" name="division[]" class="form-control" value="'+$(this).data("division")+'" readonly/></td>';
             html += '<td><select name="eligible[]" id="eligible_'+$(this).attr('id')+'" class="form-control"><option value="Yes">Yes</option><option value="No">No</option></select></td>';
             //html += '<td><input type="text" name="feedback_given[]" class="form-control" value="'+$(this).data("feedback_given")+'" /><input type="hidden" name="hidden_id[]" value="'+$(this).attr('id')+'" /></td>';
             html += '<td><select name="feedback_given[]" id="feedback_given_'+$(this).attr('id')+'" class="form-control"><option value="Yes">Yes</option><option value="No">No</option></select><input type="hidden" name="hidden_id[]" value="'+$(this).attr('id')+'" /></td>';
        }
        else
        {
            html = '<td><input type="checkbox" id="'+$(this).attr('id')+'" data-grno="'+$(this).data('grno')+'" data-rno="'+$(this).data('rno')+'" data-name="'+$(this).data('name')+'" data-division="'+$(this).data('division')+'" data-eligible="'+$(this).data('eligible')+'" data-feedback_given="'+$(this).data('feedback_given')+'" class="check_box" /></td>';
            html += '<td>'+$(this).data('grno')+'</td>';
            html += '<td>'+$(this).data('rno')+'</td>';
            html += '<td>'+$(this).data('name')+'</td>';
            html += '<td>'+$(this).data('division')+'</td>';
            html += '<td>'+$(this).data('eligible')+'</td>';
            html += '<td>'+$(this).data('feedback_given')+'</td>';            
        }
        $(this).closest('tr').html(html);
        $('#eligible_'+$(this).attr('id')+'').val($(this).data('eligible'));
        $('#feedback_given_'+$(this).attr('id')+'').val($(this).data('feedback_given'));
    });

    $('#update_form').on('submit', function(event){
        event.preventDefault();
        if($('.check_box:checked').length > 0)
        {
            $.ajax({
                url:"eligible_update_se.php",
                method:"POST",
                data:$(this).serialize(),
                success:function()
                {
                    alert('Data Updated');
                    fetch_data();
                }
            })
        }
    });

});  
</script>
 <!-- Js for Navbar, Multi-level dropdown -->
  <script src="js/bootnavbar.js" ></script>
    <script>
        $(function () {
            $('#main_navbar').bootnavbar({
                //option
                //animation: false
            });
        })
    </script>