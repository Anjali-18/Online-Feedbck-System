<?php
$grno = $_POST["grno"];
$pass = $_POST["password"];
// echo "$pass";
//$sec_pass=password_hash($pass, PASSWORD_DEFAULT);
$dept = $_POST["department"];
// echo "$dept";
$Adyr = $_POST["Adyr"];

$conn=mysqli_connect("localhost","root","","college");
session_start();
   $_SESSION['department']= "$dept";
   $_SESSION['grno'] = "$grno";
   $_SESSION['Adyr'] = "$Adyr";
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}
$result=mysqli_query($conn,"SELECT password as password FROM reg_auto where grno='$grno'");
$row = mysqli_fetch_array($result);
$password = $row['password'];
// echo "$password";
$sec_pass=password_verify($pass, $password);
//echo"$sec_pass";
if(password_verify($pass, $password) or  die(mysqli_error($conn))){
  // echo "hii";
}else{
  // echo"bye";
}

$sql="select grno,password,department,year from reg_auto where grno='$grno' and department='$dept' and year='$Adyr'";

//echo $sql;
$result=mysqli_query($conn,$sql);


if(mysqli_num_rows($result)>0 && password_verify($pass, $password) ){
    
	echo '<script>
    		 confirm("Login successfully");
    		 window.location="main.php";
    		</script>
    		';
}else{
	echo'<script>
    		 alert("Login Failed");
    		 window.location="login.html";
    	</script>';
}
mysqli_close($conn);
// 
// 
?>

