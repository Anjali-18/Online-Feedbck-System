<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";

	$e1=$_POST['e1'];
	$e2=$_POST['e2'];
	$e3=$_POST['e3'];
	$e4=$_POST['e4'];
	$e5=$_POST['e5'];
	$e6=$_POST['e6'];
	$bt=$_POST['bt'];
	$elec=$_POST['elec'];

	session_start();
	$grno=$_SESSION['grno'];
	$name=$_SESSION['name'];
	$sem=$_SESSION['sem'];
	$_SESSION['bt']=$bt;
	$Adyr=$_SESSION['Adyr'];
	//$rno=$_SESSION['rno'];
	//echo $Adyr;
    $SE='SE';
    $TE='TE';
    $BE='BE';
	
	$conn=new mysqli($servername, $username, $password, $dbname);
	if ($conn->connect_error){
		die("Connection failed:" .$conn->connect_error);
	}
	else
	{
		if($SE==$Adyr){

				$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_comp_se where grno='$grno'");
				$row = mysqli_fetch_array($result);
    			$rno = $row['rno'];

				$sql="insert into elecdetail_comp_se (grno,rno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno','$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
				if(mysqli_query($conn,$sql))
					{
			 			echo'<script>alert("successfully submitted");
			 			window.location="detail_se.php";
		            	</script>';
			 		}else{
			 			echo'<script>alert("Submission failed, you have already submitted");
			 			window.location="detail_se.php";
		            	</script>';
			 		}
			}else{
				if($TE==$Adyr){
					$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_comp_te where grno='$grno'");
			 		$row = mysqli_fetch_array($result);
    				$rno = $row['rno'];

					$sql="insert into elecdetail_comp_te (grno,rno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno','$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
					if(mysqli_query($conn,$sql))
					{
			 			echo'<script>alert("successfully submitted");
			 			window.location="detail_te.php";
		            	</script>';
			 		}else{
			 			echo'<script>alert("Submission failed, you have already submitted");
			 			window.location="detail_te.php";
		            	</script>';
			 		}
				}else{
					if($BE==$Adyr){
						$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_comp_be where grno='$grno'");
					 	$row = mysqli_fetch_array($result);
    					$rno = $row['rno'];

						$sql="insert into elecdetail_comp_be (grno,rno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno','$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
						//echo $sql;
						if(mysqli_query($conn,$sql))
						{
				 			echo'<script>alert("successfully submitted");
				 			window.location="detail_be.php";
			            	</script>';
				 		}else{
				 			echo'<script>alert("Submission failed, you have already submitted");
				 			window.location="detail_be.php";
			            	</script>';
				 		}
					}
				}
			}

			
	}
	
?>






































