<?php
error_reporting(0);
$conn=mysqli_connect("localhost","root","","college");
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}

/*feedprac create table query:
CREATE TABLE `college`.`feedprac_comp_be` (
 `grno` VARCHAR(20) NOT NULL DEFAULT '0',  `fac1` VARCHAR(70) NOT NULL DEFAULT 'NULL',`sub1` VARCHAR(70) NOT NULL DEFAULT 'NULL' ,
  `p1q1` FLOAT(5) NOT NULL DEFAULT '0', `p1q2` FLOAT(5) NOT NULL DEFAULT '0', `p1q3` FLOAT(5) NOT NULL DEFAULT '0', `p1q4` FLOAT(5) NOT NULL DEFAULT '0', 
  `avg1` FLOAT(5) NOT NULL DEFAULT '0', `fac2` VARCHAR(70) NOT NULL DEFAULT 'NULL',`sub2` VARCHAR(70) NOT NULL DEFAULT 'NULL', 

  `p2q1` FLOAT(5) NOT NULL DEFAULT '0', `p2q2` FLOAT(5) NOT NULL DEFAULT '0', `p2q3` FLOAT(5) NOT NULL DEFAULT '0', `p2q4` FLOAT(5) NOT NULL DEFAULT '0',
   `avg2` FLOAT(5) NOT NULL DEFAULT '0',  `fac3` VARCHAR(70) NOT NULL DEFAULT 'NULL', `sub3` VARCHAR(70) NOT NULL DEFAULT 'NULL',

   `p3q1` FLOAT(5) NOT NULL DEFAULT '0', `p3q2` FLOAT(5) NOT NULL DEFAULT '0', `p3q3` FLOAT(5) NOT NULL DEFAULT '0', `p3q4` FLOAT(5) NOT NULL DEFAULT '0', 
   `avg3` FLOAT(5) NOT NULL DEFAULT '0', `fac4` VARCHAR(70) NOT NULL DEFAULT 'NULL',`sub4` VARCHAR(70) NOT NULL DEFAULT 'NULL', 

   `p4q1` FLOAT(5) NOT NULL DEFAULT '0', `p4q2` FLOAT(5) NOT NULL DEFAULT '0' , `p4q3` FLOAT(5) NOT NULL DEFAULT '0', `p4q4` FLOAT(5) NOT NULL DEFAULT '0',
   `avg4` FLOAT(5) NOT NULL DEFAULT '0', `fac5` VARCHAR(70) NOT NULL DEFAULT 'NULL', `sub5` VARCHAR(70) NOT NULL DEFAULT 'NULL' ,

   `p5q1` FLOAT(5) NOT NULL DEFAULT '0', `p5q2` FLOAT(5) NOT NULL DEFAULT '0', `p5q3` FLOAT(5) NOT NULL DEFAULT '0', `p5q4` FLOAT(5) NOT NULL DEFAULT '0', 
   `avg5` FLOAT(5) NOT NULL DEFAULT '0', `fac6` VARCHAR(70) NOT NULL DEFAULT 'NULL', `sub6` VARCHAR(70) NOT NULL DEFAULT 'NULL',

   `p6q1` FLOAT(5) NOT NULL DEFAULT '0', `p6q2` FLOAT(5) NOT NULL DEFAULT '0', `p6q3` FLOAT(5) NOT NULL DEFAULT '0', `p6q4` FLOAT(5) NOT NULL DEFAULT '0',
   `avg6` FLOAT(5) NOT NULL DEFAULT '0',

  `total` FLOAT(5) NOT NULL DEFAULT '0', PRIMARY KEY (`grno`)) ENGINE = InnoDB;*/

session_start();
$sem=$_SESSION['sem'];
$grno=$_SESSION['grno'];
$Adyr=$_SESSION['Adyr'];

 $SE="SE";
 $TE="TE";
 $BE="BE";

if($SE==$Adyr){
    $sql2= "select `elec_no`,`batch` from elecdetail_comp_se where grno='$grno'";
            $res=mysqli_query($conn,$sql2);
            while($row=$res->fetch_assoc()){
                $elec = $row ['elec_no'];
                //echo"\n $elec";
                $batch= $row['batch'];
              //  echo "\n $batch";
            }
            
}else{
    if($TE==$Adyr){
        $sql2= "select `elec_no`,`batch` from elecdetail_comp_te where grno='$grno'";
            $res=mysqli_query($conn,$sql2);
            while($row=$res->fetch_assoc()){
                $elec = $row ['elec_no'];
                //echo"\n $elec";
                $batch= $row['batch'];
               //echo "\n $batch";
            }
        }else{
            if($BE==$Adyr){
                $sql2= "select `elec_no`,`batch` from elecdetail_comp_be where grno='$grno'";
                $res=mysqli_query($conn,$sql2);
                while($row=$res->fetch_assoc()){
                    $elec = $row ['elec_no'];
                    //echo"\n $elec";
                    $batch= $row['batch'];
                    //echo "\n $batch";
                }
            }
        }
}

          $q="SELECT COUNT(*) AS `counts` FROM `prac_comp` WHERE sem=$sem AND batch=$batch";
           // echo $q;
            $result1 = mysqli_query($conn,$q);
            $row1 = mysqli_fetch_array($result1);
            $count1 = $row1['counts'];
            //echo $count1;

// echo "Sem no:",$sem;
// echo "\n Gr no is: ",$grno;
// echo "\n Batch is\n",$batch;

//+++PRACTICAL 1+++
$fac1=$_POST['fac1'];
// echo "\n $fac1";
$sub1=$_POST['sub1'];
// echo "\n $sub1";
$p1q1=$_POST['p1q1'];
$p1q2=$_POST['p1q2'];
$p1q3=$_POST['p1q3'];
$p1q4=$_POST['p1q4'];

$avrP1=($p1q1+$p1q2+$p1q3+$p1q4)/4;
// echo "\nPractical 1",$avrP1;

//+++PRACTICAL 2+++
$fac2=$_POST['fac2'];
// echo "\n $fac2";
$sub2=$_POST['sub2'];
// echo "\n $sub2";
$p2q1=$_POST['p2q1'];
$p2q2=$_POST['p2q2'];
$p2q3=$_POST['p2q3'];
$p2q4=$_POST['p2q4'];

$avrP2=($p2q1+$p2q2+$p2q3+$p2q4)/4;
// echo "\nPractical 2:",$avrP2;


//+++PRACTICAL 3+++
$fac3=$_POST['fac3'];
// echo "\n $fac3";
$sub3=$_POST['sub3'];
// echo "\n $sub3";
$p3q1=$_POST['p3q1'];
$p3q2=$_POST['p3q2'];
$p3q3=$_POST['p3q3'];
$p3q4=$_POST['p3q4'];

$avrP3=($p3q1+$p3q2+$p3q3+$p3q4)/4;
// echo "\n Practical 3:",$avrP3;

//+++PRACTICAL 4+++
$fac4=$_POST['fac4'];
// echo "\n $fac4";
$sub4=$_POST['sub4'];
// echo "\n $sub4";
$p4q1=$_POST['p4q1'];
$p4q2=$_POST['p4q2'];
$p4q3=$_POST['p4q3'];
$p4q4=$_POST['p4q4'];

$avrP4=($p4q1+$p4q2+$p4q3+$p4q4)/4;
// echo "\n Practical 4:",$avrP4;

//+++PRACTICAL 5+++
$fac5=$_POST['fac5'];
// echo "\n $fac5";
$sub5=$_POST['sub5'];
// echo "\n $sub5";
$p5q1=$_POST['p5q1'];
$p5q2=$_POST['p5q2'];
$p5q3=$_POST['p5q3'];
$p5q4=$_POST['p5q4'];

$avrP5=($p5q1+$p5q2+$p5q3+$p5q4)/4;
// echo "\n Practical 5:",$avrP5;


//+++PRACTICAL 6+++
$fac6=$_POST['fac6'];
// echo "\n $fac6";
$sub6=$_POST['sub6'];
// echo "\n $sub6";
$p6q1=$_POST['p6q1'];
$p6q2=$_POST['p6q2'];
$p6q3=$_POST['p6q3'];
$p6q4=$_POST['p6q4'];

$avrP6=($p6q1+$p6q2+$p6q3+$p6q4)/4;
// echo "\n Practical 6:",$avrP6;

// $prac_total=($avrP1+$avrP2+$avrP3+$avrP4+$avrP5+$avrP6)/$count1;
// echo "Total avg is:",$prac_total;

if($SE==$Adyr){
	$sql="INSERT INTO feedprac_comp_se(`grno`, `fac1`, `sub1`, `p1q1`, `p1q2`, `p1q3`, `p1q4`, `avg1`,
											  `fac2`,`sub2`, `p2q1`, `p2q2`, `p2q3`, `p2q4`, `avg2`, 
											 `fac3`,`sub3`,  `p3q1`, `p3q2`, `p3q3`, `p3q4`, `avg3`, 
											 `fac4`,`sub4`,  `p4q1`, `p4q2`, `p4q3`, `p4q4`, `avg4`, 
											 `fac5`,`sub5`,  `p5q1`, `p5q2`, `p5q3`, `p5q4`, `avg5`, 
											  `fac6`,`sub6`, `p6q1`, `p6q2`, `p6q3`, `p6q4`, `avg6`) VALUES 
								('$grno', '$sub1', '$fac1', '$p1q1', '$p1q2', '$p1q3', '$p1q4', '$avrP1',
											  '$sub2','$fac2', '$p2q1', '$p2q2', '$p2q3', '$p2q4', '$avrP2', 
											 '$sub3', '$fac3', '$p3q1', '$p3q2', '$p3q3', '$p3q4', '$avrP3', 
											 '$sub4', '$fac4', '$p4q1', '$p4q2', '$p4q3', '$p4q4', '$avrP4', 
											 '$sub5','$fac5',  '$p5q1', '$p5q2', '$p5q3', '$p5q4', '$avrP5', 
											 '$sub6','$fac6',  '$p6q1', '$p6q2', '$p6q3', '$p6q4', '$avrP6')";
// echo $sql;
if(mysqli_query($conn,$sql))
				{
						echo '<script>confirm("Practical feedback submitted successfully, Please enter Library feedback.");
						window.location="feedback.php";
		            	</script>';
						//die(mysqli_error($conn));
				
				}else
				{
						//die(mysqli_error($conn));
					 echo '<script>confirm("Submission failed");
            		window.location="feedback.php";
                  	</script>';
				}
}elseif ($TE==$Adyr) {
	$sql="INSERT INTO feedprac_comp_te(`grno`, `fac1`, `sub1`, `p1q1`, `p1q2`, `p1q3`, `p1q4`, `avg1`,
											  `fac2`,`sub2`, `p2q1`, `p2q2`, `p2q3`, `p2q4`, `avg2`, 
											 `fac3`,`sub3`,  `p3q1`, `p3q2`, `p3q3`, `p3q4`, `avg3`, 
											 `fac4`,`sub4`,  `p4q1`, `p4q2`, `p4q3`, `p4q4`, `avg4`, 
											 `fac5`,`sub5`,  `p5q1`, `p5q2`, `p5q3`, `p5q4`, `avg5`, 
											  `fac6`,`sub6`, `p6q1`, `p6q2`, `p6q3`, `p6q4`, `avg6`) VALUES 
								('$grno', '$sub1', '$fac1', '$p1q1', '$p1q2', '$p1q3', '$p1q4', '$avrP1',
											  '$sub2','$fac2', '$p2q1', '$p2q2', '$p2q3', '$p2q4', '$avrP2', 
											 '$sub3', '$fac3', '$p3q1', '$p3q2', '$p3q3', '$p3q4', '$avrP3', 
											 '$sub4', '$fac4', '$p4q1', '$p4q2', '$p4q3', '$p4q4', '$avrP4', 
											 '$sub5','$fac5',  '$p5q1', '$p5q2', '$p5q3', '$p5q4', '$avrP5', 
											 '$sub6','$fac6',  '$p6q1', '$p6q2', '$p6q3', '$p6q4', '$avrP6')";
//echo $sql;
if(mysqli_query($conn,$sql))
				{
						echo '<script>confirm("Practical feedback submitted successfully, Please enter Library feedback.");
						window.location="feedback.php";
		            	</script>';
						//die(mysqli_error($conn));
				
				}else
				{
						//die(mysqli_error($conn));
					echo '<script>confirm("Submission failed");
           			 window.location="feedback.php";
                  	</script>';
				}
}elseif ($BE==$Adyr) {
	$sql="INSERT INTO feedprac_comp_be(`grno`, `fac1`, `sub1`, `p1q1`, `p1q2`, `p1q3`, `p1q4`, `avg1`,
											  `fac2`,`sub2`, `p2q1`, `p2q2`, `p2q3`, `p2q4`, `avg2`, 
											 `fac3`,`sub3`,  `p3q1`, `p3q2`, `p3q3`, `p3q4`, `avg3`, 
											 `fac4`,`sub4`,  `p4q1`, `p4q2`, `p4q3`, `p4q4`, `avg4`, 
											 `fac5`,`sub5`,  `p5q1`, `p5q2`, `p5q3`, `p5q4`, `avg5`, 
											  `fac6`,`sub6`, `p6q1`, `p6q2`, `p6q3`, `p6q4`, `avg6`) VALUES 
								('$grno', '$sub1', '$fac1', '$p1q1', '$p1q2', '$p1q3', '$p1q4', '$avrP1',
											  '$sub2','$fac2', '$p2q1', '$p2q2', '$p2q3', '$p2q4', '$avrP2', 
											 '$sub3', '$fac3', '$p3q1', '$p3q2', '$p3q3', '$p3q4', '$avrP3', 
											 '$sub4', '$fac4', '$p4q1', '$p4q2', '$p4q3', '$p4q4', '$avrP4', 
											 '$sub5','$fac5',  '$p5q1', '$p5q2', '$p5q3', '$p5q4', '$avrP5', 
											 '$sub6','$fac6',  '$p6q1', '$p6q2', '$p6q3', '$p6q4', '$avrP6')";
//echo $sql;
if(mysqli_query($conn,$sql))
				{
						echo '<script>confirm("Practical feedback submitted successfully, Please enter Library feedback.");
						window.location="feedback.php";
		            	</script>';
						//die(mysqli_error($conn));
				
				}else
				{
						//die(mysqli_error($conn));
					echo '<script>confirm("Submission failed");
           			 window.location="feedback.php";
                 	 </script>';
				}
}


?>