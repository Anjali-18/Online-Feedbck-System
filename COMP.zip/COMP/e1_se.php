<?php include('eleconn.php');
session_start(); 
   $grno=$_SESSION['grno'];
   $sem=$_SESSION['sem'];

   //$Adyr=$_SESSION['Adyr'];
   //echo $Adyr;
  // $division=$_SESSION['division'];
   //echo "$division";
  if($sem=='3')
   {
      $sem='3';
   }else
   {
        $sem='4';
   }
  // echo $sem;

 $f="SELECT distinct sem_no FROM elec_comp  ";
    $r=mysqli_query($conn,$f);
      $datas= array();
      if(mysqli_num_rows($r)>0){
        while($row= mysqli_fetch_assoc($r)){
           $datas[]= $row;
        }
     }

?>
<!DOCTYPE html>
<html>
<head>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <style>
    .colr{
      color: blue;
    }
  </style>


<script>

  $(document).ready(function(){
    $('#elective').on('change', function() {
      if ( this.value >=<?php $numbers = array_column($datas, 'sem_no'); echo min($numbers)?>)
      {
        $("#Select").show();
        $("#noelect").hide();

      }else 
      {
        $("#noelect").show();
        $("#Select").hide();
      }
    });
});

  $(document).ready(function(){
    $('#selection').on('change', function() {
    if ( this.value == '1')
      {
        $("#elec1").show();
        $("#fac1").show();
        $("#elec2").hide();
        $("#fac2").hide();
        $("#elec3").hide();
        $("#fac3").hide();

      }
      else if(this.value == '2')
      {
        $("#elec1").show();
        $("#fac1").show();
        $("#elec2").show();
        $("#fac2").show(); 
        $("#elec3").hide();
        $("#fac3").hide();  
      }
      else if(this.value== '3')
      { 

         $("#elec1").show();
         $("#elec2").show();
         $("#fac1").show();
         $("#fac2").show();
         $("#elec3").show();
         $("#fac3").show();

      }else{

        $("#elec1").hide();
         $("#elec2").hide();
         $("#fac1").hide();
         $("#fac2").hide();
         $("#elec3").hide();
         $("#fac3").hide();
      }
     
    });
});
</script>
</head>
<body>
<header>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="main.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="studinfo.php">Information</a>
          <a class="dropdown-item" href="point1.php">Marks</a>
        </div>
      </li>
   
      <li class="nav-item">
        <a class="nav-link" href="detail.php">Feedback</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.html" style="color: aqua">Log out <?php echo $grno;?></a>
      </li>
     
    </ul>
  </div>
 </nav>
 <!-- navbar end -->
</header>

  <section class="container mt-5">
    <div class="row">
      <div class="col-md-3">
   <label>Select Semester</label>
   <select name="sem" id="elective" class="form-control" required>
      <option value="0">Select an option</option>
      <option value="<?php echo $sem ?>"><?php echo "sem",$sem; ?></option>
     <!--  <option value="4">Sem 4</option> -->
   </select>
 </div>
</div>
  
</section>
<section style='display: none' id="Select">
  <form class="container" action="elective_detail.php" method="POST" autocomplete="off">
    <?php include('eleconn.php');

    $query="SELECT * FROM elec_comp where sem_no=$sem";
        //echo $query;
        $sql=mysqli_query($conn, $query)or die( mysqli_error($conn));
        $sql1=mysqli_query($conn, $query) or die( mysqli_error($conn));
        $sql2=mysqli_query($conn, $query) or die( mysqli_error($conn));
        $sql3=mysqli_query($conn, $query) or die( mysqli_error($conn)) ;
         $sql4=mysqli_query($conn, $query) or die( mysqli_error($conn)) ;
      $sql5=mysqli_query($conn, $query) or die( mysqli_error($conn)) ;

    ?>
      <center><h4 style="color: blue;" class="mt-5"><label>ELECTIVE SUBJECT</label></h4></center>
        <div class="row">
            <div class="col-md-3">
            <label>Select Number of elective</label>
              <select name="elec"  id="selection" class="form-control" required>
                    <option value="#">Select an option</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
              </select>
          </div>
        </div><br>
        <section>
          <label class="colr">Select your elective subject</label>
          <div class="row">
            <div style='display: none;' id="elec1" class="col-md-3"> 
              <label>Elective Subject</label>
              <select  name="e1" class="form-control">
                <option></option>
                 <?php while($row=mysqli_fetch_array($sql)){?>
                <option><?php echo $row['subject_name'] ?></option>
                <?php }?>
              </select>
            </div>
            <div style='display: none;' id='fac1' class="col-md-3">
              <label>Faculty</label>
              <select  name="e2" class="form-control">
                <option></option>
                  <?php while($row=mysqli_fetch_array($sql1)){?>
                <option><?php echo $row['faculty_name'] ?></option>
                <?php }?>
              </select>
            </div>
              </div>
              <div class="row">
                <div style='display: none;' id='elec2' class="col-md-3">
              <label>Elective Subject</label>
               <select  name="e3" class="form-control">
                <option></option>
                 <?php while($row=mysqli_fetch_array($sql2)){?>
                <option><?php echo $row['subject_name'] ?></option>
                 <?php }?>
              </select>
            </div>
            <div style='display: none;' id='fac2' class="col-md-3">
              <label>Faculty</label>
              <select  name="e4" class="form-control">
                <option></option>
                <?php while($row=mysqli_fetch_array($sql3)){?>
                <option><?php echo $row['faculty_name'] ?></option>
                <?php }?>
              </select>
            </div>
              </div>

              <div class="row">
                <div style='display: none;' id='elec3' class="col-md-3">
              <label>Elective Subject</label>
               <select  name="e5" class="form-control">
                <option></option>
                 <?php while($row=mysqli_fetch_array($sql4)){?>
                <option><?php echo $row['subject_name'] ?></option>
                 <?php }?>
              </select>
            </div>
            <div style='display: none;' id='fac3' class="col-md-3">
              <label>Faculty</label>
              <select  name="e6" class="form-control">
                <option></option>
                <?php while($row=mysqli_fetch_array($sql5)){?>
                <option><?php echo $row['faculty_name'] ?></option>
                <?php }?>
              </select>
            </div>
              </div>

              
          </section>
      
     

        
        </section>
        <section>
          <center><label style="color: red ; display: none" id="noelect" class="mt-4">No elective subject for this semester</label></center>
        </section>
        
        <div class="row mt-4" id="batch">
            <div class="col-md-1"></div>
                <div class="col-md-3">
                  <label>Select Your Practical Batch </label>
                  <select class="form-control" id="bth" name="bt" required>
                    <option>Select Batch</option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                  </select> 
                </div>
              </div>
                <div class="mt-5">
            <center><button class="btn btn-primary">Submit</button></center>

      </div>
    </form>      
</body>
</html>

