<?php
error_reporting(0);
$conn=mysqli_connect("localhost","root","","college");
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}


session_start();
$sem=$_SESSION['sem'];
//$bt=$_SESSION['batch'];
$grno=$_SESSION['grno'];


// echo "Sem no:",$sem;
// echo "\n Gr no is: ",$grno;

/*CREATE TABLE `college`.`feedback_other_comp` ( `grno` VARCHAR(20) NOT NULL , `sem` INT(3) NOT NULL , `oq1` FLOAT(5) NOT NULL , `oq2` FLOAT(5) NOT NULL , `oq3` FLOAT(5) NOT NULL , `oq4` FLOAT(5) NOT NULL , `oq5` FLOAT(5) NOT NULL , `oq6` FLOAT(5) NOT NULL , `oq7` FLOAT(5) NOT NULL , `oq8` FLOAT(5) NOT NULL , `oq9` FLOAT(5) NOT NULL , `oq10` FLOAT(5) NOT NULL , `oq11` FLOAT(5) NOT NULL , `oq12` FLOAT(5) NOT NULL , `avg` FLOAT(5) NOT NULL , PRIMARY KEY (`grno`)) ENGINE = InnoDB;
*/

$oq1=$_POST['oq1'];
$oq2=$_POST['oq2'];
$oq3=$_POST['oq3'];
$oq4=$_POST['oq4'];
$oq5=$_POST['oq5'];
$oq6=$_POST['oq6'];
$oq7=$_POST['oq7'];
$oq8=$_POST['oq8'];
$oq9=$_POST['oq9'];
$oq10=$_POST['oq10'];
$oq11=$_POST['oq11'];
$oq12=$_POST['oq12'];

$other_avg=($oq1+$oq2+$oq3+$oq4+$oq5+$oq6+$oq7+$oq8+$oq9+$oq10+$oq11+$oq12)/5;
//echo "Total avg is: ",$other_avg;

$sql="INSERT INTO feedback_other_comp(`grno`, `sem`, `oq1`, `oq2`, `oq3`, `oq4`, `oq5`, `oq6`, `oq7`, `oq8`, `oq9`, `oq10`, `oq11`, `oq12`, `avg`) VALUES (
'$grno','$sem','$oq1','$oq2','$oq3','$oq4','$oq5','$oq6','$oq7','$oq8','$oq9','$oq10','$oq11','$oq12','$other_avg')";

if(mysqli_query($conn,$sql))
{
	switch($sem)
	{
		case '3':
					
				$sql3="UPDATE studinfo_comp_se SET `feedback_given` = 'Yes' WHERE `studinfo_comp_se`.`grno` = '$grno'";
				if(mysqli_query($conn,$sql3))
				{
					echo '<script>confirm("All feedbacks submitted successfully");
							window.location = "detail_se.php";
							</script>';
				}
				break;

		case '4':
					
				$sql4="UPDATE studinfo_comp_se SET `feedback_given` = 'Yes' WHERE `studinfo_comp_se`.`grno` = '$grno'";
				if(mysqli_query($conn,$sql4))
				{
					echo '<script>confirm("All feedbacks submitted successfully");
							window.location = "detail_se.php";
							</script>';
				}
					
				break;
		case '5':
					
				$sql5="UPDATE studinfo_comp_te SET `feedback_given` = 'Yes' WHERE `studinfo_comp_te`.`grno` = '$grno'";
				if(mysqli_query($conn,$sql5))
				{
					echo '<script>confirm("All feedbacks submitted successfully");
							window.location = "detail_te.php";
							</script>';
				}
					
				break;
		case '6':
					
				$sql6="UPDATE studinfo_comp_te SET `feedback_given` = 'Yes' WHERE `studinfo_comp_te`.`grno` = '$grno'";
				if(mysqli_query($conn,$sql6))
				{
					echo '<script>confirm("All feedbacks submitted successfully");
							window.location = "detail_te.php";
							</script>';
				}
					
				break;
		case '7':
					
				$sql7="UPDATE studinfo_comp_be SET `feedback_given` = 'Yes' WHERE `studinfo_comp_be`.`grno` = '$grno'";
				if(mysqli_query($conn,$sql7))
				{
					echo '<script>confirm("All feedbacks submitted successfully");
							window.location = "detail_be.php";
							</script>';
				}
					
				break;
		case '8':
					
				$sql8="UPDATE studinfo_comp_be SET `feedback_given` = 'Yes' WHERE `studinfo_comp_be`.`grno` = '$grno'";
				if(mysqli_query($conn,$sql8))
				{
					echo '<script>confirm("All feedbacks submitted successfully");
							window.location = "detail_be.php";
							</script>';
				}
					
				break;
		

	}

}else
{
	echo '<script>confirm("Submission Failed");
	window.location = "feedback.php";
	</script>';
}


?>
