<?php 
include ('conn.php');

$grno=$_POST['grno'];

$q="DELETE FROM `studinfo_civila_be` WHERE  grno='$grno' ";
echo "$q";
$result=mysqli_query($conn,$q);
if($result){
	echo"deleted";
}
header('location:eligible_be_a.php');

?>