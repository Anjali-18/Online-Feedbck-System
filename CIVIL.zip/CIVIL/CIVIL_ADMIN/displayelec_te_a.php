 <!DOCTYPE html>
<html>
<head>
 <title>TE CIVIL A -Elective Subjects</title>

 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

 <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
   <script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

 <!-- Bootnavbar.css -->
<link href="css/bootnavbar.css" rel="stylesheet">

</head>
<body>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark" id="main_navbar">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College of Engineering</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ">
                <li class="nav-item active">
                    <a class="nav-link" href="main1.html">Home <span class="sr-only">(current)</span></a>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        Student
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student Marks
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">SE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="dispoint_se_a.php">SE-A</a></li>
                                                <li><a class="dropdown-item" href="dispoint_se_b.php">SE-B</a></li>
                                                <li><a class="dropdown-item" href="dispoint_se_c.php">SE-C</a></li>
                                            
                                            </ul>
                                    </li>
                                    <!-- <li><a class="dropdown-item" href="dispoint_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="dispoint_be.php">BE</a></li> -->
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">TE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="dispoint_te_a.php">TE-A</a></li>
                                                <li><a class="dropdown-item" href="dispoint_te_b.php">TE-B</a></li>
                                                <li><a class="dropdown-item" href="dispoint_te_c.php">TE-C</a></li>
                                                
                                            
                                            </ul>
                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">BE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="dispoint_be_a.php">BE-A</a></li>
                                                <li><a class="dropdown-item" href="dispoint_be_b.php">BE-B</a></li>
                                                <li><a class="dropdown-item" href="dispoint_be_c.php">BE-C</a></li>
                                            </ul>
                                    </li>
                                    
                                </ul>
                            </li>

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student information
                                </a>
                                
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">SE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="indis_se_a.php">SE-A</a></li>
                                                <li><a class="dropdown-item" href="indis_se_b.php">SE-B</a></li>
                                                <li><a class="dropdown-item" href="indis_se_c.php">SE-C</a></li>
                                            </ul>
                                    </li>
                                    
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">TE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="indis_te_a.php">TE-A</a></li>
                                                <li><a class="dropdown-item" href="indis_te_b.php">TE-B</a></li>
                                                <li><a class="dropdown-item" href="indis_te_c.php">TE-C</a></li>
                                            
                                            </ul>
                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">BE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="indis_be_a.php">BE-A</a></li>
                                                <li><a class="dropdown-item" href="indis_be_b.php">BE-B</a></li>
                                                <li><a class="dropdown-item" href="indis_be_c.php">BE-C</a></li>
                                            
                                            </ul>
                                    </li>
                                    
                                </ul>
                            </li>
                    </ul>
                    
                    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Subject
        </a>
         
           <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Theory Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="theory_display_se_a.php">SE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="theory_display_se_b.php">SE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="theory_display_se_c.php">SE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="theory_display_te_a.php">TE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="theory_display_te_b.php">TE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="theory_display_te_c.php">TE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="theory_display_be_a.php">BE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="theory_display_be_b.php">BE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="theory_display_be_c.php">BE - DIV C</a></li>
                                    </li>
                                </ul>
                            </li>

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Elective Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayelec_se_a.php">SE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayelec_se_b.php">SE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayelec_se_c.php">SE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="displayelec_te_a.php">TE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayelec_te_b.php">TE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayelec_te_c.php">TE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="displayelec_be_a.php">BE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayelec_be_b.php">BE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayelec_be_c.php">BE - DIV C</a></li>
                                    </li>
                                </ul>
                            </li>

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Practical Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayprac_se_a.php">SE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayprac_se_b.php">SE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayprac_se_c.php">SE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="displayprac_te_a.php">TE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayprac_te_b.php">TE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayprac_te_c.php">TE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="displayprac_be_a.php">BE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayprac_be_b.php">BE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayprac_be_c.php">BE - DIV C</a></li>
                                    </li>
                                </ul>
                            </li>
                    </ul>


      </li>
      <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Feedback
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Theory</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                            <li><a class="dropdown-item" href="tft_se_a.php">SE - DIV A</a></li>
                                            <li><a class="dropdown-item" href="tft_se_b.php">SE - DIV B</a></li>
                                            <li><a class="dropdown-item" href="tft_se_c.php">SE - DIV C</a></li>
                                        <div class="dropdown-divider"></div>
                                            <li><a class="dropdown-item" href="tft_te_a.php">TE - DIV A</a></li>
                                            <li><a class="dropdown-item" href="tft_te_b.php">TE - DIV B</a></li>
                                            <li><a class="dropdown-item" href="tft_te_c.php">TE - DIV C</a></li>
                                        <div class="dropdown-divider"></div>
                                            <li><a class="dropdown-item" href="tft_be_a.php">BE - DIV A</a></li>
                                            <li><a class="dropdown-item" href="tft_be_b.php">BE - DIV B</a></li>
                                            <li><a class="dropdown-item" href="tft_be_c.php">BE - DIV C</a></li>
                                            </li>
                                    </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Practical</a> 
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="pft_se_a.php">SE - DIV A</a></li>
                                        <li><a class="dropdown-item" href="pft_se_b.php">SE - DIV B</a></li>
                                        <li><a class="dropdown-item" href="pft_se_c.php">SE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                        <li><a class="dropdown-item" href="pft_te_a.php">TE - DIV A</a></li>
                                        <li><a class="dropdown-item" href="pft_te_b.php">TE - DIV B</a></li>
                                        <li><a class="dropdown-item" href="pft_te_c.php">TE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                        <li><a class="dropdown-item" href="pft_be_a.`php">BE - DIV A</a></li>
                                        <li><a class="dropdown-item" href="pft_be_b.php">BE - DIV B</a></li>
                                        <li><a class="dropdown-item" href="pft_be_c.php">BE - DIV C</a></li>
                                        </li>
                                </ul> 
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="lfb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Library</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="ofb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Other Facilities</a>  
                        </li>
            </ul>
      </li>
       <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Elective Details
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                               <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">SE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="diselecdetail_se_a.php">SE-A</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_se_b.php">SE-B</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_se_c.php">SE-C</a></li>
                                    </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">TE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="diselecdetail_te_a.php">TE-A</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_te_b.php">TE-B</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_te_c.php">TE-C</a></li>
                                    </ul>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">BE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="diselecdetail_be_a.php">BE-A</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_be_b.php">BE-B</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_be_c.php">BE-C</a></li>
                                    </ul>  
                        </li>
            </ul>
      </li>
      

      <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Eligibility
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                               <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">SE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="eligible_se_a.php">SE-A</a></li>
                                        <li><a class="dropdown-item" href="eligible_se_b.php">SE-B</a></li>
                                        <li><a class="dropdown-item" href="eligible_se_c.php">SE-C</a></li>
                                    </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">TE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="eligible_te_a.php">TE-A</a></li>
                                        <li><a class="dropdown-item" href="eligible_te_b.php">TE-B</a></li>
                                        <li><a class="dropdown-item" href="eligible_te_c.php">TE-C</a></li>
                                    </ul>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">BE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="eligible_be_a.php">BE-A</a></li>
                                        <li><a class="dropdown-item" href="eligible_be_b.php">BE-B</a></li>
                                        <li><a class="dropdown-item" href="eligible_be_c.php">BE-C</a></li>
                                    </ul>  
                        </li>
            </ul>
      </li>
      
      <li class="nav-item" style="padding-left: 450px;">
        <a class="nav-link" style="color: aqua;" href="faclogin.html">Log out</a>
      </li>
                    
                       
 </ul>        
        </div>
    </nav>

 <!-- navbar end -->

 <div class="container">
 <div class="col-lg-12">
 <br><br>
 <h1 class="text-warning text-center" >TE CIVIL A- Elective Subjects</h1>
 <br>
 <table  id="tabledata" class=" table table-striped table-hover table-bordered">
 
 <tr class="bg-dark text-white text-center">
 
 <th> Sem </th>
 <th> Subject_code </th>
 <th> Elective_Subject_Name </th>
 <th> Faculty_name </th>
 <th> Delete </th>
 <th> Update </th>
 
 </tr >

 <?php

 include 'conn.php'; 
 $q = "SELECT * FROM elec_civila WHERE `sem_no`= 5 OR `sem_no` = 6 ORDER BY sem_no ASC";
 

 $query = mysqli_query($conn,$q);

 while($res = mysqli_fetch_array($query)){
 ?>
  <tr class="text-center">
 <td> <?php echo $res['sem_no'];  ?> </td>
 <td> <?php echo $res['subject_code'];  ?> </td>
 <td> <?php echo $res['subject_name'];  ?> </td>
 <td> <?php echo $res['faculty_name'];  ?> </td>
 <td> <button class="btn-danger btn"> <a href="Deleteelec_a.php?subject_code=<?php echo $res['subject_code']; ?>" class="text-white"> Delete </a>  </button> </td>
 <td> <button class="btn-primary btn"> <a href="Updateelec_a.php?subject_code=<?php echo $res['subject_code']; ?>" class="text-white"> Update </a> </button> </td>

 </tr>

 <?php 
 }
  ?>
 
 </table>  

 </div>
 </div>
 <center><button class="btn-primary btn mt-4"><a href="insertelective_a.php" class="text-white">ADD</a></button></center>

 <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 });
 
 </script>

<!-- Js for Navbar, Multi-level dropdown -->
  <script src="js/bootnavbar.js" ></script>
    <script>
        $(function () {
            $('#main_navbar').bootnavbar({
                //option
                //animation: false
            });
        })
    </script>

    

</body>
</html>