<?php

$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";
$conn=new mysqli($servername,$username,$password,$dbname);

$sql="select *from point_civilc_te order by rno";
$query=mysqli_query($conn,$sql);
if(mysqli_num_rows($query)>0){
	while($result=mysqli_fetch_array($query)){
		?>
		<form action="delpoint_te_c.php" method="post">
			<tr>
			<td><?php echo $result['grno'] ?></td>
			<td><?php echo $result['rno'] ?></td>
			<td><?php echo $result['name'] ?></td>
			<td><?php echo $result['sem1'] ?></td>
			<td><?php echo $result['sem2'] ?></td>
			<td><?php echo $result['sem3'] ?></td>
			<td><?php echo $result['sem4'] ?></td>
			<td><?php echo $result['sem5'] ?></td>
			<td><?php echo $result['sem6'] ?></td>
			<td><?php echo $result['sem7'] ?></td>
			<td><?php echo $result['sem8'] ?></td>
			<td> <button class="btn-danger btn" name="delete"><a href="delpoint_te_c.php?grno=<?php echo $result['grno']; ?>" class="text-white"> Delete </a>  </button>
		</tr>
		</form>
<?php
	}
}
?>