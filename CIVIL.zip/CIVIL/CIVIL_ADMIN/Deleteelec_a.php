<?php

include 'conn.php';

$subject_code = $_GET['subject_code'];

$query = "SELECT `sem_no` FROM elec_civila WHERE `subject_code` = '$subject_code'";

$res=mysqli_query($conn,$query);
while($row=$res->fetch_assoc()){
	$sem_no = $row ['sem_no'];
	echo $sem_no;
}


$q = "DELETE FROM elec_civila WHERE subject_code = '$subject_code'";
echo $q;
// mysqli_query($conn,$q);

// header('location:Displayelec.php');
if(mysqli_query($conn,$q))
 {

	 	switch($sem_no)
		{
			case '3': header('location:displayelec_se_a.php'); 
						break;
			case '4': header('location:displayelec_se_a.php'); 
						break;
			case '5': header('location:displayelec_te_a.php'); 
						break;
			case '6': header('location:displayelec_te_a.php'); 
						break;
			case '7': header('location:displayelec_be_a.php'); 
						break;
			case '8': header('location:displayelec_be_a.php'); 
						break;
		}
	 }else
 	{
 		echo "error";
 	}


?>