<?php

$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";
$conn=new mysqli($servername,$username,$password,$dbname);

$sql="select * from elecdetail_civilc_be order by rno";
$query=mysqli_query($conn,$sql);
if(mysqli_num_rows($query)>0){
	while($result=mysqli_fetch_array($query)){
		?>
		<form action="delelec_be_c.php" method="post">
			<tr>
			<td><?php echo $result['grno'] ?></td>
			<td><?php echo $result['rno'] ?></td>
			<td><?php echo $result['name'] ?></td>
			<td><?php echo $result['sem'] ?></td>
			<td><?php echo $result['batch'] ?></td>
			<td><?php echo $result['elective_subject1'] ?></td>
			<td><?php echo $result['faculty_name1'] ?></td>
			<td><?php echo $result['elective_subject2'] ?></td>
			<td><?php echo $result['faculty_name2'] ?></td>
			<td><?php echo $result['elective_subject3'] ?></td>
			<td><?php echo $result['faculty_name3'] ?></td>
			<td> <button class="btn-danger btn" name="delete"><a href="delelec_be_c.php?grno=<?php echo $result['grno']; ?>" class="text-white"> Delete </a>  </button>
		</tr>
		</form>
<?php
	}
}
?>