<?php

//select.php

include('database_connection.php');

$query = "SELECT `id`, `grno`,`rno`, `name`, `division`, `eligible`, `feedback_given` FROM studinfo_civila_te ORDER BY rno";

$statement = $connect->prepare($query);

if($statement->execute())
{
 while($row = $statement->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }

 echo json_encode($data);
}

?>
