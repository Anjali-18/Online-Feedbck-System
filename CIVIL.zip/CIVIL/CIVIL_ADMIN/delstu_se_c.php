<?php
				
			include 'conn.php';

				$id = $_GET['id'];

				$q = "DELETE FROM studinfo_civilc_se WHERE id = '$id'";
				echo $q;
				if(mysqli_query($conn,$q)){
					echo "deleted";
				}

				header('location:indis_se_c.php');
					
?>