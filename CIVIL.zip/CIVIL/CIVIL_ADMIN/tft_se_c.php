<!DOCTYPE html>
<html>
<head>
    <title>SE-C CIVIL - Average Theory Feedback</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
-
    <link rel="stylesheet" type="text/css" href="swiper.min.css">

    <!-- Bootnavbar.css -->

     <link href="css/bootnavbar.css" rel="stylesheet">

</head>
<body class="bg">

    <header>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark" id="main_navbar">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College of Engineering</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ">
                <li class="nav-item active">
                    <a class="nav-link" href="main1.html">Home <span class="sr-only">(current)</span></a>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        Student
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student Marks
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">SE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="dispoint_se_a.php">SE-A</a></li>
                                                <li><a class="dropdown-item" href="dispoint_se_b.php">SE-B</a></li>
                                                <li><a class="dropdown-item" href="dispoint_se_c.php">SE-C</a></li>
                                            
                                            </ul>
                                    </li>
                                    <!-- <li><a class="dropdown-item" href="dispoint_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="dispoint_be.php">BE</a></li> -->
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">TE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="dispoint_te_a.php">TE-A</a></li>
                                                <li><a class="dropdown-item" href="dispoint_te_b.php">TE-B</a></li>
                                                <li><a class="dropdown-item" href="dispoint_te_c.php">TE-C</a></li>
                                                
                                            
                                            </ul>
                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">BE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="dispoint_be_a.php">BE-A</a></li>
                                                <li><a class="dropdown-item" href="dispoint_be_b.php">BE-B</a></li>
                                                <li><a class="dropdown-item" href="dispoint_be_c.php">BE-C</a></li>
                                            </ul>
                                    </li>
                                    
                                </ul>
                            </li>

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student information
                                </a>
                                
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">SE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="indis_se_a.php">SE-A</a></li>
                                                <li><a class="dropdown-item" href="indis_se_b.php">SE-B</a></li>
                                                <li><a class="dropdown-item" href="indis_se_c.php">SE-C</a></li>
                                            </ul>
                                    </li>
                                    
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">TE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="indis_te_a.php">TE-A</a></li>
                                                <li><a class="dropdown-item" href="indis_te_b.php">TE-B</a></li>
                                                <li><a class="dropdown-item" href="indis_te_c.php">TE-C</a></li>
                                            
                                            </ul>
                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">BE</a>
                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                                <li><a class="dropdown-item" href="indis_be_a.php">BE-A</a></li>
                                                <li><a class="dropdown-item" href="indis_be_b.php">BE-B</a></li>
                                                <li><a class="dropdown-item" href="indis_be_c.php">BE-C</a></li>
                                            
                                            </ul>
                                    </li>
                                    
                                </ul>
                            </li>
                    </ul>
                    
                    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Subject
        </a>
         
           <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Theory Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="theory_display_se_a.php">SE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="theory_display_se_b.php">SE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="theory_display_se_c.php">SE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="theory_display_te_a.php">TE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="theory_display_te_b.php">TE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="theory_display_te_c.php">TE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="theory_display_be_a.php">BE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="theory_display_be_b.php">BE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="theory_display_be_c.php">BE - DIV C</a></li>
                                    </li>
                                </ul>
                            </li>

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Elective Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayelec_se_a.php">SE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayelec_se_b.php">SE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayelec_se_c.php">SE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="displayelec_te_a.php">TE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayelec_te_b.php">TE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayelec_te_c.php">TE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="displayelec_be_a.php">BE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayelec_be_b.php">BE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayelec_be_c.php">BE - DIV C</a></li>
                                    </li>
                                </ul>
                            </li>

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Practical Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayprac_se_a.php">SE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayprac_se_b.php">SE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayprac_se_c.php">SE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="displayprac_te_a.php">TE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayprac_te_b.php">TE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayprac_te_c.php">TE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                    <li><a class="dropdown-item" href="displayprac_be_a.php">BE - DIV A</a></li>
                                    <li><a class="dropdown-item" href="displayprac_be_b.php">BE - DIV B</a></li>
                                    <li><a class="dropdown-item" href="displayprac_be_c.php">BE - DIV C</a></li>
                                    </li>
                                </ul>
                            </li>
                    </ul>


      </li>
      <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Feedback
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Theory</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                            <li><a class="dropdown-item" href="tft_se_a.php">SE - DIV A</a></li>
                                            <li><a class="dropdown-item" href="tft_se_b.php">SE - DIV B</a></li>
                                            <li><a class="dropdown-item" href="tft_se_c.php">SE - DIV C</a></li>
                                        <div class="dropdown-divider"></div>
                                            <li><a class="dropdown-item" href="tft_te_a.php">TE - DIV A</a></li>
                                            <li><a class="dropdown-item" href="tft_te_b.php">TE - DIV B</a></li>
                                            <li><a class="dropdown-item" href="tft_te_c.php">TE - DIV C</a></li>
                                        <div class="dropdown-divider"></div>
                                            <li><a class="dropdown-item" href="tft_be_a.php">BE - DIV A</a></li>
                                            <li><a class="dropdown-item" href="tft_be_b.php">BE - DIV B</a></li>
                                            <li><a class="dropdown-item" href="tft_be_c.php">BE - DIV C</a></li>
                                            </li>
                                    </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Practical</a> 
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="pft_se_a.php">SE - DIV A</a></li>
                                        <li><a class="dropdown-item" href="pft_se_b.php">SE - DIV B</a></li>
                                        <li><a class="dropdown-item" href="pft_se_c.php">SE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                        <li><a class="dropdown-item" href="pft_te_a.php">TE - DIV A</a></li>
                                        <li><a class="dropdown-item" href="pft_te_b.php">TE - DIV B</a></li>
                                        <li><a class="dropdown-item" href="pft_te_c.php">TE - DIV C</a></li>
                                    <div class="dropdown-divider"></div>
                                        <li><a class="dropdown-item" href="pft_be_a.`php">BE - DIV A</a></li>
                                        <li><a class="dropdown-item" href="pft_be_b.php">BE - DIV B</a></li>
                                        <li><a class="dropdown-item" href="pft_be_c.php">BE - DIV C</a></li>
                                        </li>
                                </ul> 
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="lfb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Library</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="ofb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Other Facilities</a>  
                        </li>
            </ul>
      </li>
       <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Elective Details
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                               <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">SE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="diselecdetail_se_a.php">SE-A</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_se_b.php">SE-B</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_se_c.php">SE-C</a></li>
                                    </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">TE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="diselecdetail_te_a.php">TE-A</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_te_b.php">TE-B</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_te_c.php">TE-C</a></li>
                                    </ul>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">BE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="diselecdetail_be_a.php">BE-A</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_be_b.php">BE-B</a></li>
                                        <li><a class="dropdown-item" href="diselecdetail_be_c.php">BE-C</a></li>
                                    </ul>  
                        </li>
            </ul>
      </li>
      

      <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Eligibility
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                               <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">SE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="eligible_se_a.php">SE-A</a></li>
                                        <li><a class="dropdown-item" href="eligible_se_b.php">SE-B</a></li>
                                        <li><a class="dropdown-item" href="eligible_se_c.php">SE-C</a></li>
                                    </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">TE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="eligible_te_a.php">TE-A</a></li>
                                        <li><a class="dropdown-item" href="eligible_te_b.php">TE-B</a></li>
                                        <li><a class="dropdown-item" href="eligible_te_c.php">TE-C</a></li>
                                    </ul>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">BE</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="eligible_be_a.php">BE-A</a></li>
                                        <li><a class="dropdown-item" href="eligible_be_b.php">BE-B</a></li>
                                        <li><a class="dropdown-item" href="eligible_be_c.php">BE-C</a></li>
                                    </ul>  
                        </li>
            </ul>
      </li>
      
      <li class="nav-item" style="padding-left: 450px;">
        <a class="nav-link" style="color: aqua;" href="faclogin.html">Log out</a>
      </li>
                    
                       
 </ul>        
        </div>
    </nav>

 <!-- navbar end -->
</header>


 <div class="container">
 <div class="col-lg-12">
 <br><br>
 <h1 class="text-warning text-center" >SE-C CIVIL -Average Theory Feedback </h1>
 <br>



<?php
error_reporting(0);
$conn=mysqli_connect("localhost","root","","college");
if(!$conn){
    die("connection failed:".mysqli_connect_error());
}

$f="Select distinct fac1 from feedback_civilc_se where fac1!=''";
    $s=mysqli_query($conn,$f);
    $datas= array();
    if(mysqli_num_rows($s)>0){
    while($row= mysqli_fetch_assoc($s)){
        $datas[]= $row;
    }
}

$f1="Select distinct fac2 from feedback_civilc_se where fac2!=''";
    $s1=mysqli_query($conn,$f1);
    $datas1= array();
    if(mysqli_num_rows($s1)>0){
    while($row1= mysqli_fetch_assoc($s1)){
        $datas1[]= $row1;
    }
}

$f2="Select distinct fac3 from feedback_civilc_se where fac3!=''";
    $s2=mysqli_query($conn,$f2);
    $datas2= array();
    if(mysqli_num_rows($s2)>0){
    while($row2= mysqli_fetch_assoc($s2)){
        $datas2[]= $row2;
    }
}

$f3="Select distinct fac4 from feedback_civilc_se where fac4!=''";
    $s3=mysqli_query($conn,$f3);
    $datas3= array();
    if(mysqli_num_rows($s3)>0){
    while($row3= mysqli_fetch_assoc($s3)){
        $datas3[]= $row3;
    }
}

$f4="Select distinct fac5 from feedback_civilc_se where fac5!=''";
    $s4=mysqli_query($conn,$f4);
    $datas4= array();
    if(mysqli_num_rows($s4)>0){
    while($row4= mysqli_fetch_assoc($s4)){
        $datas4[]= $row4;
    }
}

$f5="Select distinct fac6 from feedback_civilc_se where fac6!=''";
    $s5=mysqli_query($conn,$f5);
    $datas5= array();
    if(mysqli_num_rows($s5)>0){
    while($row5= mysqli_fetch_assoc($s5)){
        $datas5[]= $row5;
    }
}

$f6="Select distinct fac7 from feedback_civilc_se where fac7!=''";
    $s6=mysqli_query($conn,$f6);
    $datas6= array();
    if(mysqli_num_rows($s6)>0){
    while($row6= mysqli_fetch_assoc($s6)){
        $datas6[]= $row6;
    }
}

$f7="Select distinct fac8 from feedback_civilc_se where fac8!=''";
    $s7=mysqli_query($conn,$f7);
    $datas7= array();
    if(mysqli_num_rows($s7)>0){
    while($row7= mysqli_fetch_assoc($s7)){
        $datas7[]= $row7;
    }
}

$f8="Select distinct fac9 from feedback_civilc_se where fac9!=''";
    $s8=mysqli_query($conn,$f8);
    $datas8= array();
    if(mysqli_num_rows($s8)>0){
    while($row8= mysqli_fetch_assoc($s8)){
        $datas8[]= $row8;
    }
}

$f9="Select distinct fac10 from feedback_civilc_se where fac10!=''";
    $s9=mysqli_query($conn,$f9);
    $datas9= array();
    if(mysqli_num_rows($s9)>0){
    while($row9= mysqli_fetch_assoc($s9)){
        $datas9[]= $row9;
    }
}
    print_r($datas);
    print_r($datas1);
    print_r($datas2);
    print_r($datas3);
    print_r($datas4);
    print_r($datas5);
    print_r($datas6);
    print_r($datas7);
    print_r($datas8);
    print_r($datas9);
?>

 
 
 <!-- <tr class="bg-dark text-white text-center">
 
 <th> s1q1 </th>
 <th> s1q2</th>
 <th> s1q3 </th>
 <th> s1q4</th>
 <th> s1q5</th>
 <th> avg1</th> -->

<!-- <tr>
<th>Srno</th>
<th>Questions</th>
<th>Feedback</th>
</tr > -->


<!-- ********************************************************************************************* -->
<!-- fac1 -->
 <?php

 include 'eleconn.php'; 
 for ($i=0; $i <sizeof($datas) ; $i++) { 
    foreach($datas[$i] as $data)
    //$q = "select s1q1,s1q2,s1q3,s1q4,s1q5,avg1,distinct sub1,fac1 from feedback_civilc_se where fac1= $data";
    //echo $q;
    //$query = mysqli_query($conn,$q);
         if ($data != " " || $data != 'NULL' ) {
    $p="SELECT sub1, AVG(s1q1) as s1q1,AVG(s1q2) as s1q2,AVG(s1q3) as s1q3,AVG(s1q4) as s1q4,AVG(s1q5) as s1q5,AVG(avg1) as avg1 FROM feedback_civilc_se WHERE fac1 = '".$data."' GROUP BY fac1";

    $query1 = mysqli_query($conn,$p);
    if(mysqli_num_rows($query1)>0){
    while($result=mysqli_fetch_array($query1)){
        ?>
        <table  id="tabledata" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result['sub1'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <!-- <tr class="text-center">
             <td> <?php //echo $result['s1q1'];  ?> </td>
             <td> <?php //echo $result['s1q2'];  ?> </td>
             <td> <?php //echo $result['s1q3'];  ?> </td>
             <td> <?php //echo $result['s1q4'];  ?> </td>
             <td> <?php //echo $result['s1q5'];  ?> </td>
             <td> <?php //echo $result['avg1'];  ?> </td>
        </tr> -->
        <tr>
            <td>1</td>
            <td>Understanding content delivery of lecture</td>
            <td><?php echo $result['s1q1'];  ?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Communication skills / presentation ability of teacher</td>
            <td><?php echo $result['s1q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are  the lectures lively, interactive & interesting?</td>
            <td><?php echo $result['s1q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Efforts put in by teacher to give additional information</td>
            <td><?php echo $result['s1q4'];  ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td>Appreciation and motivation by teacher to solve the difficulties</td>
            <td><?php echo $result['s1q5'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total= ($result['s1q1']+$result['s1q2']+$result['s1q3']+$result['s1q4']+$result['s1q5'])/5; echo round($total,2);?></td>
        </tr>
         </table> 
 <br><br> 
      
<?php
    }
}
}
}
?>
<!-- <?php //unset($datas); $datas = array();?>   -->

<!-- **********************fac2************************* -->
<?php
include 'eleconn.php';
 for ($j=0; $j <sizeof($datas1) ; $j++) { 
    foreach($datas1[$j] as $data1)
     if ($data1 != " " || $data1 != 'NULL' ) {
    $p1="SELECT  sub2,AVG(s2q1) as s2q1,AVG(s2q2) as s2q2,AVG(s2q3) as s2q3,AVG(s2q4) as s2q4,AVG(s2q5) as s2q5,AVG(avg2) as avg2 FROM feedback_civilc_se WHERE fac2 = '".$data1."' GROUP BY fac2 ";
    echo "$p1";
    $query1 = mysqli_query($conn,$p1);
    if(mysqli_num_rows($query1)>0){
    while($result1=mysqli_fetch_array($query1)){
        ?>
        <table  id="tabledata1" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data1;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result1['sub2'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Understanding content delivery of lecture</td>
            <td><?php echo $result1['s2q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Communication skills / presentation ability of teacher</td>
            <td><?php echo $result1['s2q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are  the lectures lively, interactive & interesting?</td>
            <td><?php echo $result1['s2q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Efforts put in by teacher to give additional information</td>
            <td><?php echo $result1['s2q4'];  ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td>Appreciation and motivation by teacher to solve the difficulties</td>
            <td><?php echo $result1['s2q5'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total1= ($result1['s2q1']+$result1['s2q2']+$result1['s2q3']+$result1['s2q4']+$result1['s2q5'])/5; echo round($total1,2);?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
}
}
}
?>

<!-- **********************fac3*********************** -->
<?php
include 'eleconn.php';
 for ($j=0; $j <sizeof($datas2) ; $j++) { 
    foreach($datas2[$j] as $data2)
     if ($data2 != " " || $data2 != 'NULL' ) {
    $p2="SELECT  sub3,AVG(s3q1) as s3q1,AVG(s3q2) as s3q2,AVG(s3q3) as s3q3,AVG(s3q4) as s3q4,AVG(s3q5) as s3q5,AVG(avg3) as avg3 FROM feedback_civilc_se WHERE fac3 = '".$data2."' GROUP BY fac3 ";
    echo "$p2";
    $query2 = mysqli_query($conn,$p2);
    if(mysqli_num_rows($query2)>0){
    while($result2=mysqli_fetch_array($query2)){
        ?>
        <table  id="tabledata2" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data2;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result2['sub3'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Understanding content delivery of lecture</td>
            <td><?php echo $result2['s3q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Communication skills / presentation ability of teacher</td>
            <td><?php echo $result2['s3q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are  the lectures lively, interactive & interesting?</td>
            <td><?php echo $result2['s3q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Efforts put in by teacher to give additional information</td>
            <td><?php echo $result2['s3q4'];  ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td>Appreciation and motivation by teacher to solve the difficulties</td>
            <td><?php echo $result2['s3q5'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total2= ($result2['s3q1']+$result2['s3q2']+$result2['s3q3']+$result2['s3q4']+$result2['s3q5'])/5; echo round($total2,2);?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
}
}
}
?>

<!-- *************************************fac4******************************* -->
<?php
include 'eleconn.php';
 for ($j=0; $j <sizeof($datas3) ; $j++) { 
    foreach($datas3[$j] as $data3)
        if ($data3 != " " || $data3 != 'NULL' ) {
            $p3="SELECT  sub4,AVG(s4q1) as s4q1,AVG(s4q2) as s4q2,AVG(s4q3) as s4q3,AVG(s4q4) as s4q4,AVG(s4q5) as s4q5,AVG(avg4) as avg4 FROM feedback_civilc_se WHERE fac4 = '".$data3."' GROUP BY fac4 ";
    echo "$p3";
    $query3 = mysqli_query($conn,$p3);
    if(mysqli_num_rows($query3)>0){
    while($result3=mysqli_fetch_array($query3)){
        ?>
        <table  id="tabledata3" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data3;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result3['sub4'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Understanding content delivery of lecture</td>
            <td><?php echo $result3['s4q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Communication skills / presentation ability of teacher</td>
            <td><?php echo $result3['s4q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are  the lectures lively, interactive & interesting?</td>
            <td><?php echo $result3['s4q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Efforts put in by teacher to give additional information</td>
            <td><?php echo $result3['s4q4'];  ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td>Appreciation and motivation by teacher to solve the difficulties</td>
            <td><?php echo $result3['s4q5'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total3= ($result3['s4q1']+$result3['s4q2']+$result3['s4q3']+$result3['s4q4']+$result3['s4q5'])/5; echo round($total3,2);?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
        }
    
}
}
?>

<!-- *************************************fac5 ****************************** -->
<?php
include 'eleconn.php';
 for ($j=0; $j <sizeof($datas4) ; $j++) { 
    foreach($datas4[$j] as $data4)
        if ($data4 != " " || $data4 != 'NULL' ) {
            $p4="SELECT  sub5,AVG(s5q1) as s5q1,AVG(s5q2) as s5q2,AVG(s5q3) as s5q3,AVG(s5q4) as s5q4,AVG(s5q5) as s5q5,AVG(avg5) as avg5 FROM feedback_civilc_se WHERE fac5 = '".$data4."' GROUP BY fac5 ";
    echo "$p4";
    $query4 = mysqli_query($conn,$p4);
    if(mysqli_num_rows($query4)>0){
    while($result4=mysqli_fetch_array($query4)){
        ?>
        <table  id="tabledata3" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data4;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result4['sub5'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Understanding content delivery of lecture</td>
            <td><?php echo $result4['s5q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Communication skills / presentation ability of teacher</td>
            <td><?php echo $result4['s5q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are  the lectures lively, interactive & interesting?</td>
            <td><?php echo $result4['s5q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Efforts put in by teacher to give additional information</td>
            <td><?php echo $result4['s5q4'];  ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td>Appreciation and motivation by teacher to solve the difficulties</td>
            <td><?php echo $result4['s5q5'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total4= ($result4['s5q1']+$result4['s5q2']+$result4['s5q3']+$result4['s5q4']+$result4['s5q5'])/5; echo round($total4,2);?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
        }
    
}
}
?>

<!-- ***********************fac6************************** -->
<?php
include 'eleconn.php';
echo "hi";
 for ($j=0; $j <sizeof($datas5) ; $j++) { 
    foreach($datas5[$j] as $data5)
        if ($data5 != '' || $data5 != 'NULL' ) {
            $p5="SELECT  sub6,AVG(s6q1) as s6q1,AVG(s6q2) as s6q2,AVG(s6q3) as s6q3,AVG(s6q4) as s6q4,AVG(s6q5) as s6q5,AVG(avg5) as avg5 FROM feedback_civilc_se WHERE fac6 = '".$data5."' GROUP BY fac6 ";
    echo "$p5";
    $query5 = mysqli_query($conn,$p5);
    if(mysqli_num_rows($query5)>0){
    while($result5=mysqli_fetch_array($query5)){
        ?>
        <table  id="tabledata5" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data5;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result5['sub6'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Understanding content delivery of lecture</td>
            <td><?php echo $result5['s6q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Communication skills / presentation ability of teacher</td>
            <td><?php echo $result5['s6q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are  the lectures lively, interactive & interesting?</td>
            <td><?php echo $result5['s6q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Efforts put in by teacher to give additional information</td>
            <td><?php echo $result5['s6q4'];  ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td>Appreciation and motivation by teacher to solve the difficulties</td>
            <td><?php echo $result5['s6q5'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total5= ($result5['s6q1']+$result5['s6q2']+$result5['s6q3']+$result5['s6q4']+$result5['s6q5'])/5; echo round($total5,2);?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
        }
    
}
}
?>

<!-- ************************fac7************************* -->
<?php
include 'eleconn.php';
echo "hi";
 for ($j=0; $j <sizeof($datas6) ; $j++) { 
    foreach($datas6[$j] as $data6)
       if ($data6 != '' || $data6 != 'NULL' ) {
            $p6="SELECT  sub7,AVG(s7q1) as s7q1,AVG(s7q2) as s7q2,AVG(s7q3) as s7q3,AVG(s7q4) as s7q4,AVG(s7q5) as s7q5 FROM feedback_civilc_se WHERE fac7 = '".$data6."' GROUP BY fac7 ";
    echo "$p6";
    $query6 = mysqli_query($conn,$p6);
    if(mysqli_num_rows($query6)>0){
    while($result6=mysqli_fetch_array($query6)){
        ?>
        <table  id="tabledata6" class=" table table-striped table-hover table-bordered">
        <tr>
           <th colspan="2"><?php echo" Faculty Name: ", $data6;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result6['sub7'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Understanding content delivery of lecture</td>
            <td><?php echo $result6['s7q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Communication skills / presentation ability of teacher</td>
            <td><?php echo $result6['s7q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are  the lectures lively, interactive & interesting?</td>
            <td><?php echo $result6['s7q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Efforts put in by teacher to give additional information</td>
            <td><?php echo $result6['s7q4'];  ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td>Appreciation and motivation by teacher to solve the difficulties</td>
            <td><?php echo $result6['s7q5'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total6= ($result6['s7q1']+$result6['s7q2']+$result6['s7q3']+$result6['s7q4']+$result6['s7q5'])/5; echo round($total6,2);?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
        }
    
}
}
?>
<!-- *************************fac8************************** -->
<?php
include 'eleconn.php';
echo "hi";
 for ($j=0; $j <sizeof($datas7) ; $j++) { 
    foreach($datas7[$j] as $data7)
       if ($data7 != '' || $data7 != 'NULL' ) {
            $p7="SELECT  sub8,AVG(s8q1) as s8q1,AVG(s8q2) as s8q2,AVG(s8q3) as s8q3,AVG(s8q4) as s8q4,AVG(s8q5) as s8q5 FROM feedback_civilc_se WHERE fac8 = '".$data7."' GROUP BY fac8 ";
    echo "$p7";
    $query7 = mysqli_query($conn,$p7);
    if(mysqli_num_rows($query7)>0){
    while($result7=mysqli_fetch_array($query7)){
        ?>
        <table  id="tabledata7" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data7;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result7['sub8'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Understanding content delivery of lecture</td>
            <td><?php echo $result7['s8q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Communication skills / presentation ability of teacher</td>
            <td><?php echo $result7['s8q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are  the lectures lively, interactive & interesting?</td>
            <td><?php echo $result7['s8q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Efforts put in by teacher to give additional information</td>
            <td><?php echo $result7['s8q4'];  ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td>Appreciation and motivation by teacher to solve the difficulties</td>
            <td><?php echo $result7['s8q5'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total7= ($result7['s8q1']+$result7['s8q2']+$result7['s8q3']+$result7['s8q4']+$result7['s8q5'])/5; echo round($total7,2);?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
        }
    
}
}
?>

<!-- *****************************fac9****************************** -->
<?php
include 'eleconn.php';
//echo "hi";
 for ($j=0; $j <sizeof($datas8) ; $j++) { 
    foreach($datas8[$j] as $data8)
       if ($data8 != '' || $data8 != 'NULL' ) {
            $p8="SELECT sub9, AVG(s9q1) as s9q1,AVG(s9q2) as s9q2,AVG(s9q3) as s9q3,AVG(s9q4) as s9q4,AVG(s9q5) as s9q5 FROM feedback_civilc_se WHERE fac9 = '".$data8."' GROUP BY fac9 ";
    echo "$p8";
    $query8 = mysqli_query($conn,$p8);
    if(mysqli_num_rows($query8)>0){
    while($result8=mysqli_fetch_array($query8)){
        ?>
        <table  id="tabledata8" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data8;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result8['sub9'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Understanding content delivery of lecture</td>
            <td><?php echo $result8['s9q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Communication skills / presentation ability of teacher</td>
            <td><?php echo $result8['s9q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are  the lectures lively, interactive & interesting?</td>
            <td><?php echo $result8['s9q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Efforts put in by teacher to give additional information</td>
            <td><?php echo $result8['s9q4'];  ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td>Appreciation and motivation by teacher to solve the difficulties</td>
            <td><?php echo $result8['s9q5'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total8= ($result8['s9q1']+$result8['s9q2']+$result8['s9q3']+$result8['s9q4']+$result8['s9q5'])/5; echo round($total8,2);?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
        }
    
}
}
?>

<!-- **************************fac10****************************** -->
<?php
include 'eleconn.php';
//echo "hi";
 for ($j=0; $j <sizeof($datas9) ; $j++) { 
    foreach($datas9[$j] as $data9)
       if ($data9 != '' || $data9 != 'NULL' ) {
            $p9="SELECT sub10, AVG(s10q1) as s10q1,AVG(s10q2) as s10q2,AVG(s10q3) as s10q3,AVG(s10q4) as s10q4,AVG(s10q5) as s10q5 FROM feedback_civilc_se WHERE fac10 = '".$data9."' GROUP BY fac10 ";
    echo "$p9";
    $query9 = mysqli_query($conn,$p9);
    if(mysqli_num_rows($query9)>0){
    while($result9=mysqli_fetch_array($query9)){
        ?>
        <table  id="tabledata9" class=" table table-striped table-hover table-bordered">
        <tr>
            <th colspan="2"><?php echo" Faculty Name: ", $data9;?></th>
            <th colspan="1"><?php echo "Subject Name: ", $result9['sub10'];;?></th>
        </tr>
        <tr>
        <th>Srno</th>
        <th>Questions</th>
        <th>Feedback</th>
        </tr >
        <tr>
            <td>1</td>
            <td>Understanding content delivery of lecture</td>
            <td><?php echo $result9['s10q1'];?></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Communication skills / presentation ability of teacher</td>
            <td><?php echo $result9['s10q2'];  ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td>Are  the lectures lively, interactive & interesting?</td>
            <td><?php echo $result9['s10q3'];  ?></td>
        </tr>
        <tr>
            <td>4</td>
            <td>Efforts put in by teacher to give additional information</td>
            <td><?php echo $result9['s10q4'];  ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td>Appreciation and motivation by teacher to solve the difficulties</td>
            <td><?php echo $result9['s10q5'];  ?></td>
        </tr>
        <tr>
            <td colspan="2">Total</td>
            <td><?php $total9= ($result9['s10q1']+$result9['s10q2']+$result9['s10q3']+$result9['s10q4']+$result9['s10q5'])/5; echo round($total9,2);?></td>
        </tr>
         </table> 
 <br><br> 
        
<?php
    }
        }
    
}
}
?>


 </div>
 </div>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

      <!-- Js for Navbar, Multi-level dropdown -->
      <script src="js/bootnavbar.js" ></script>
        <script>
            $(function () {
                $('#main_navbar').bootnavbar({
                    //option
                    //animation: false
                });
            })
        </script>
</body>
</html>
