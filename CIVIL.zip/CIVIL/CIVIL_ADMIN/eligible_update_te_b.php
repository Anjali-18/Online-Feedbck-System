<?php

//multiple_update.php

include('database_connection.php');

if(isset($_POST['hidden_id']))
{
 $grno = $_POST['grno'];
 $rno = $_POST['rno'];
 $name = $_POST['name'];
 $division = $_POST['division'];
 $eligible = $_POST['eligible'];
 $feedback_given = $_POST['feedback_given'];
 $id = $_POST['hidden_id'];
 for($count = 0; $count < count($id); $count++)
 {
  $data = array(
   ':grno'   => $grno[$count],
   ':rno'   => $rno[$count],
   ':name'  => $name[$count],
   ':division'  => $division[$count],
   ':eligible' => $eligible[$count],
   ':feedback_given'   => $feedback_given[$count],
   ':id'   => $id[$count]
  );
  $query = "
  UPDATE studinfo_civilb_te
  SET grno = :grno, rno = :rno , name = :name, division = :division, eligible = :eligible, feedback_given = :feedback_given 
  WHERE id = :id
  ";
  $statement = $connect->prepare($query);
  $statement->execute($data);
 }
}

?>