<?php
				
			include 'conn.php';

				$grno = $_GET['grno'];

				$q = "DELETE FROM point_civilb_se WHERE grno = '$grno'";
				echo $q;
				if(mysqli_query($conn,$q)){
					echo "deleted";
				}

				header('location:dispoint_se_b.php');
					
?>