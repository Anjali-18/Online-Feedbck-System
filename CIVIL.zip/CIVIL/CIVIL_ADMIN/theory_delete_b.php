<?php

include 'conn.php';

$subject_code = $_GET['subject_code'];


$query = "SELECT `sem_no` FROM theory_civilb WHERE `subject_code` = '$subject_code'";

$res=mysqli_query($conn,$query);
while($row=$res->fetch_assoc()){
	$sem_no = $row ['sem_no'];
	echo $sem_no;
}



$q = "DELETE FROM theory_civilb WHERE subject_code = '$subject_code'";
echo $q;

 if(mysqli_query($conn,$q))
 {

	 	switch($sem_no)
		{
			case '3': header('location:theory_display_se_b.php'); 
						break;
			case '4': header('location:theory_display_se_b.php'); 
						break;
			case '5': header('location:theory_display_te_b.php'); 
						break;
			case '6': header('location:theory_display_te_b.php'); 
						break;
			case '7': header('location:theory_display_be_b.php'); 
						break;
			case '8': header('location:theory_display_be_b.php'); 
						break;
		}
	 }else
 	{
 		echo "error";
 	}


?>