<?php  
$servername="localhost";
  $username="root";
  $password="";
  $dbname="college";

  $conn=new mysqli($servername,$username,$password,$dbname);

$sql = "SELECT id,grno,name,rno,sts,phone,Adyr,DOB,division,dept,blogp,caste,subcaste FROM studinfo_civilc_se order by rno";

$setRec = mysqli_query($conn, $sql); 
$columnHeader = '';  
$columnHeader = "Grno" . "\t" . "Name" . "\t" ."Roll No" . "\t" ."status" . "\t" . "phone" . "\t"."Adyr"."\t"."DOB"."\t"."\t"."dept"."\t"."blogp"."\t"."caste"."\t"."Subcaste"."\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n"; 
 
?> 