<?php
				
			include 'conn.php';

				$grno = $_GET['grno'];

				$q = "DELETE FROM elecdetail_civilc_be WHERE grno = '$grno'";
				echo $q;
				if(mysqli_query($conn,$q)){
					echo "deleted";
				}

				header('location:diselecdetail_be_c.php');
					
?>