<?php 

	$srno = $sem = $batch = $subject_name = $faculty_name = '';
	$errors = array('srno' => '','sem' => '', 'batch' => '', 'subject_name' => '', 'faculty_name' => '');

	if(isset($_POST['submit'])){

		//check for srno
		if(empty($_POST['srno'])){
			$errors['srno'] = 'Srno is required';
		} else{
			$srno = $_POST['srno'];
			if(!filter_var($srno, FILTER_VALIDATE_INT)){
				$errors['srno'] = 'Srno must be number';
			}
		}
		
		// check sem
		if(empty($_POST['sem'])){
			$errors['sem'] = 'Sem is required';
		} else{
			$sem = $_POST['sem'];
			if(!filter_var($sem, FILTER_VALIDATE_INT)){
				$errors['sem'] = 'Sem must be number';
			}
		}

		//check for batch
		if(empty($_POST['batch'])){
			$errors['batch'] = 'Batch is required';
		} else{
			$batch = $_POST['batch'];
			if(!filter_var($batch, FILTER_VALIDATE_INT)){
				$errors['batch'] = 'Batch must be number';
			}
		}

		// check title
		/*if(empty($_POST['subject_code'])){
			$errors['subject_code'] = 'A subject_code is required';
		} else{
			$subject_code = $_POST['subject_code'];
			if(!preg_match('/^([a-zA-Z\s]+)([0-9]+)*$/', $subject_code)){
				$errors['subject_code'] = 'subject_code must be letters and spaces only';
			}
		}*/

		// check subject_name
		if(empty($_POST['subject_name'])){
			$errors['subject_name'] = 'Subject name is required';
		} else{
			$subject_name = $_POST['subject_name'];
			if(!preg_match('/^[a-zA-Z\s]+$/', $subject_name)){
				$errors['subject_name'] = 'subject_name must be in alphabet form';
			}
		}
		//check for faculty name
		if(empty($_POST['faculty_name'])){
			$errors['faculty_name'] = 'Faculty name is required';
		} else{
			$faculty_name = $_POST['faculty_name'];
			if(!preg_match('/^[a-zA-Z\s]+$/', $faculty_name)){
				$errors['faculty_name'] = 'faculty_name must be in alphabet form';
			}
		}
		if(array_filter($errors)){
			echo 'errors in form';
		}else{
			include 'conn.php';

			 $srno=$_POST['srno'];
			 $sem = $_POST['sem'];
			 $batch=$_POST['batch'];
			 $subject_name = $_POST['subject_name'];
			 $faculty_name=$_POST['faculty_name'];

			 $q = " INSERT INTO prac_civil_a (sr_no,sem,batch,subject_name,faculty_name) VALUES ($srno,$sem,$batch,'$subject_name','$faculty_name')";
			 echo $q;
			 if(mysqli_query($conn,$q))
			 {

				 	switch($sem)
					{
						case '3': header('location:displayprac_se_a.php'); 
									break;
						case '4': header('location:displayprac_se_a.php'); 
									break;
						case '5': header('location:displayprac_te_a.php'); 
									break;
						case '6': header('location:displayprac_te_a.php'); 
									break;
						case '7': header('location:displayprac_be_a.php'); 
									break;
						case '8': header('location:displayprac_be_a.php'); 
									break;
					}
				 }else
			 	{
			 		echo "error";
			 	}

		
		}
	} // end POST check;

?>

<!DOCTYPE html>
<html>
	<title>Add New Practical Subject</title>
	<?php include('templates/header.php'); ?>

	<section class="container grey-text">
		<h4 class="center">Add Practical Subject</h4>
		<form class="white" action="insertpractical_a.php" method="POST">
			<label>SRNO</label>
			<input type="text" name="srno" value="<?php echo htmlspecialchars($srno) ?>">
			<div class="red-text"><?php echo $errors['srno']; ?></div>
			<label>Sem</label>
			<input type="text" name="sem" value="<?php echo htmlspecialchars($sem) ?>">
			<div class="red-text"><?php echo $errors['sem']; ?></div>
			<label>batch</label>
			<input type="text" name="batch" value="<?php echo htmlspecialchars($batch) ?>">
			<div class="red-text"><?php echo $errors['batch']; ?></div>
			<label>Subject Name</label>
			<input type="text" name="subject_name" value="<?php echo htmlspecialchars($subject_name)?>">
			<div class="red-text"><?php echo $errors['subject_name']; ?></div>
			<label>Faculty Name</label>
			<input type="text" name="faculty_name" value="<?php echo htmlspecialchars($faculty_name)?>">
			<div class="red-text"><?php echo $errors['faculty_name']; ?></div>
			<div class="center">
				<input type="submit" name="submit" value="Submit" class="btn brand z-depth-0">
			</div>
		</form>
	</section>

	<?php include('templates/footer.php'); ?>

</html>