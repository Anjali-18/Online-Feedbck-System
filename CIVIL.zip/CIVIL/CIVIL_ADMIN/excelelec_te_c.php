<?php  
$servername="localhost";
  $username="root";
  $password="";
  $dbname="college";

  $conn=new mysqli($servername,$username,$password,$dbname);

$sql = "SELECT * FROM elecdetail_civilc_te order by rno";

$setRec = mysqli_query($conn, $sql); 
$columnHeader = '';  
$columnHeader = "Grno" . "\t" ."Roll No" . "\t" . "Name" . "\t" . "Sem" . "\t"."Batch"."\t"."Elective_subject1"."\t"."Faculty_name1"."\t"."Elective_subject2"."\t"."Faculty_name2"."\t"."Elective_subject3"."\t"."Faculty_name3"."\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n"; 
 
?> 