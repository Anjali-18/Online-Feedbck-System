<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";
$conn=new mysqli($servername,$username,$password,$dbname);

$sql="SELECT * FROM studinfo_civila_te order by rno";
$query=mysqli_query($conn,$sql);
if(mysqli_num_rows($query)>0){
	while($result=mysqli_fetch_array($query)){
		?>
		<form action="delstu_te_a.php" method="post">
		<tr>
			<td><?php echo $result['id'] ?></td>
			<td><?php echo $result['grno'] ?></td>
			<td><?php echo $result['name'] ?></td>
			<td><?php echo $result['rno'] ?></td>
			<td><?php echo $result['sts'] ?></td>
			<td><?php echo $result['phone'] ?></td>
			<td><?php echo $result['Adyr'] ?></td>
			<td><?php echo $result['DOB'] ?></td>			
			<td><?php echo $result['dept'] ?></td>
			<td><?php echo $result['blogp'] ?></td>
			<td><?php echo $result['caste'] ?></td>
			<td><?php echo $result['subcaste'] ?></td>
			<td> <button class="btn-danger btn" name="delete"><a href="delstu_te_a.php?id=<?php echo $result['id']; ?>" class="text-white"> Delete </a>  </button>
			
</td></tr></form>
			 </td>
		</tr>
<?php
	}
}
?>