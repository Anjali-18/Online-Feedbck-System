<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";

	$name=$_POST['name']; 
	//echo $name;
	$grno=$_POST['grno'];
	$phone=$_POST['phone'];
	$Adyr=$_POST['Adyr'];
	$DOB=$_POST['DOB'];
	$division=$_POST['division'];     
	$dept=$_POST['dept'];
	$blogp=$_POST['blogp'];
	$caste=$_POST['caste'];
	$subcaste=$_POST['subcaste'];
	$SE='SE';
	$TE='TE';
	$BE='BE';
	$A='A';
    $B='B';
    $C='C';

	
	session_start();
   	$_SESSION['name'] = "$name";
   	
   	$conn=new mysqli($servername,$username,$password,$dbname);
   	//echo "connected";
	if($conn->connect_error)
	{
		die("Connectivity Error:".$conn->connect_error);
	}
	else
	{
		if($SE==$Adyr && $A==$division){
			$sql="insert into studinfo_civila_se(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
				echo $sql;
				if(mysqli_query($conn,$sql))
				{
					echo'<script>alert("successfully submitted");
			 		 window.location = "point.html";
		            </script>';
			 	}
				 else
			 	{
			 		echo '<script>alert("Already Submitted");
		            window.location = "point.html";
		            </script>';
			 	}
			 }else{
			 	if($SE==$Adyr && $B==$division){
			 		$sql="insert into studinfo_civilb_se(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
						echo $sql;
						if(mysqli_query($conn,$sql))
						{
							echo'<script>alert("successfully submitted");
					 		 window.location = "point.html";
				            </script>';
					 	}
						 else
					 	{
					 		echo '<script>alert("Already Submitted");
				            window.location = "point.html";
				            </script>';
					 	}
					 }else{
					 	if ($SE==$Adyr && $C==$division) {
					 		$sql="insert into studinfo_civilc_se(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
								//echo $sql;
								if(mysqli_query($conn,$sql))
								{
									echo'<script>alert("successfully submitted");
							 		 window.location = "point.html";
						            </script>';
							 	}
								 else
							 	{
							 		echo '<script>alert("Already Submitted");
						            window.location = "point.html";
						            </script>';
							 	}
					 			}else{
							 			if($TE==$Adyr && $A==$division){
							 				$sql="insert into studinfo_civila_te(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
											//echo $sql;
											if(mysqli_query($conn,$sql))
											{
												echo'<script>alert("successfully submitted");
										 		 window.location = "point.html";
									            </script>';
										 	}
											 else
										 	{
										 		echo '<script>alert("Already Submitted");
									            window.location = "point.html";
									            </script>';
										 	}
						 				}else{
								 				if($TE==$Adyr && $B==$division){
								 				$sql="insert into studinfo_civilb_te(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
												//echo $sql;
												if(mysqli_query($conn,$sql))
												{
													echo'<script>alert("successfully submitted");
											 		 window.location = "point.html";
										            </script>';
											 	}
												 else
											 	{
											 		echo '<script>alert("Already Submitted");
										            window.location = "point.html";
										            </script>';
											 	}
							 			}else{
								 				if($TE==$Adyr && $C==$division){
								 				$sql="insert into studinfo_civilc_te(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
												//echo $sql;
												if(mysqli_query($conn,$sql))
												{
													echo'<script>alert("successfully submitted");
											 		 window.location = "point.html";
										            </script>';
											 	}
												 else
											 	{
											 		echo '<script>alert("Already Submitted");
										            window.location = "point.html";
										            </script>';
											 	}
							 			}else{
								 				if($BE==$Adyr && $A==$division){
								 				$sql="insert into studinfo_civila_be(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
												//echo $sql;
												if(mysqli_query($conn,$sql))
												{
													echo'<script>alert("successfully submitted");
											 		 window.location = "point.html";
										            </script>';
											 	}
												 else
											 	{
											 		echo '<script>alert("Already Submitted");
										            window.location = "point.html";
										            </script>';
											 	}
							 				}else{
								 					if($BE==$Adyr && $B==$division){
									 				$sql="insert into studinfo_civilb_be(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
													//echo $sql;
													if(mysqli_query($conn,$sql))
													{
														echo'<script>alert("successfully submitted");
												 		 window.location = "point.html";
											            </script>';
												 	}
													 else
												 	{
												 		echo '<script>alert("Already Submitted");
											            window.location = "point.html";
											            </script>';
												 	}
							 					}else{
									 				if($BE==$Adyr && $C==$division){	
										 				$sql="insert into studinfo_civilc_be(grno,name,phone,Adyr,DOB,division,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$division','$dept','$blogp','$caste','$subcaste')";
														//echo $sql;
														if(mysqli_query($conn,$sql))
														{
															echo'<script>alert("successfully submitted");
													 		 window.location = "point.html";
												            </script>';
													 	}
														 else
													 	{
													 		echo '<script>alert("Already Submitted");
												            window.location = "point.html";
												            </script>';
													 	}
							 					}
					 						}
					 					}
					 				}
					 			}
					 		}
						}	
			 		
			 		}
			 	}
	 	
	}

	$conn->close();
?>
