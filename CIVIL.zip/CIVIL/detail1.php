 <?php
            include('eleconn.php');
            // if(isset($_POST['submit'])){
                $grno = $_POST["grno"];
                $pass = $_POST["password"];
                $Adyr=$_POST["Adyr"];
                $sem=$_POST["sem"];
                $dept=$_POST['department'];

                session_start();
                $dept=$_SESSION['department'];
                $division=$_SESSION['division'];

                $CIVIL_SHIFT_I='CIVIL SHIFT-I';
                $CIVIL_SHIFT_II='CIVIL SHIFT-II';

                $SE='SE';
                $TE='TE';
                $BE='BE';
                $A='A';
                $B='B';
                $C='C';

                $conn=mysqli_connect("localhost","root","","college");

                if(!$conn){
                  die("connection failed:".mysqli_connect_error());
                }


                if($CIVIL_SHIFT_I==$dept){
                    $r=mysqli_query($conn,"SELECT password as password FROM reg_civil1 where grno='$grno'");
                    $row = mysqli_fetch_array($r);
                    $password = $row['password'];
                    //echo "$password";
                    //$sec_pass=password_verify($pass, $password);
                    //echo"$sec_pass";
                    if(password_verify($pass, $password)){
                     // echo "hii";
                    }else{
                     // echo"bye";
                    }
                  $sql="select grno from reg_civil1 where grno='$grno'";
                  ///echo "$sql";
                  $result=mysqli_query($conn,$sql);

                }elseif ($CIVIL_SHIFT_II==$dept) {
                    $r=mysqli_query($conn,"SELECT password as password FROM reg_civil2 where grno='$grno'");
                    $row = mysqli_fetch_array($r);
                    $password = $row['password'];
                    //echo "$password";
                    //$sec_pass=password_verify($pass, $password);
                    //echo"$sec_pass";
                    if(password_verify($pass, $password)){
                     // echo "hii";
                    }else{
                     // echo"bye";
                    }

                  $sql1="select grno,password from reg_civil2 where grno='$grno'";
                  $result=mysqli_query($conn,$sql1);

                }

                if($SE==$Adyr){
                  if ($A==$division) {
                    $sql1="select eligible,feedback_given from studinfo_civila_se where grno='$grno'";
                    $result1=mysqli_query($conn,$sql1);

                  }elseif ($B==$division) {
                    $sql1="select eligible,feedback_given from studinfo_civilb_se where grno='$grno'";
                    $result1=mysqli_query($conn,$sql1);
                  }elseif ($C==$division) {
                    $sql1="select eligible,feedback_given from studinfo_civilc_se where grno='$grno'";
                    $result1=mysqli_query($conn,$sql1); 
                  }

                  while($row=$result1->fetch_assoc()){
                                $eligible = $row ['eligible'];
                                //echo"\n $eligible";
                                $feedback_given= $row['feedback_given'];
                              // echo "\n $feedback_given";
                            }

                            if($eligible!='No'&& $feedback_given!='Yes' ){
                                   // if($feedback_given!='Yes'||$feedback_given=='No' ){
                                      if( mysqli_num_rows($result)>0 && password_verify($pass, $password)){
                                      echo'<script>
                                         alert("Given Feedback");
                                       window.location = "feedback.php";  
                                      </script>';
                                    }
                               // }
                              }
                              else{
                                  if($eligible=='No'){
                                      if(mysqli_num_rows($result1)>0 && password_verify($pass, $password)) {
                                        echo '<script>
                                               confirm("you are not eligible for feedback");
                                               window.location = "detail_se.php";
                                              </script>
                                              ';
                                        }
                                      // $error1="you are not eligible for feedback ";
                                      // echo $error1;
                                    }
                                  if($feedback_given=='Yes'){
                                      if(mysqli_num_rows($result1)>0 && password_verify($pass, $password) ) {
                                      echo'<script>
                                           alert("Feedback already given");
                                           window.location = "detail_se.php";
                                        </script>';
                                      }
                                      // $error2="Feedback already given";
                                      // echo "$error2";
                                    }

                              }



                }elseif ($TE==$Adyr) {
                  if ($A==$division) {
                    $sql1="select eligible,feedback_given from studinfo_civila_te where grno='$grno'";
                    $result1=mysqli_query($conn,$sql1);  
                  }elseif ($B==$division) {
                    $sql1="select eligible,feedback_given from studinfo_civilb_te where grno='$grno'";
                    $result1=mysqli_query($conn,$sql1);    
                  }elseif ($C==$division) {
                    $sql1="select eligible,feedback_given from studinfo_civilc_te where grno='$grno'";
                    $result1=mysqli_query($conn,$sql1);    
                  }

                  while($row=$result1->fetch_assoc()){
                                $eligible = $row ['eligible'];
                                echo"\n $eligible";
                                $feedback_given= $row['feedback_given'];
                              echo "\n $feedback_given";
                            }
                            echo "hii";
                            if($eligible!='No'&& $feedback_given!='Yes' ){
                                   // if($feedback_given!='Yes'||$feedback_given=='No' ){echo "hii";
                              echo "hii";
                                      if( mysqli_num_rows($result)>0 && password_verify($pass, $password)){
                                        echo "hii";
                                      echo'<script>
                                         alert("Given Feedback");
                                       window.location = "feedback.php";  
                                      </script>';
                                    }
                               // }
                              }
                              else{
                                  if($eligible=='No'){
                                      if(mysqli_num_rows($result1)>0 && password_verify($pass, $password)) {
                                        echo '<script>
                                               confirm("you are not eligible for feedback");
                                               window.location = "detail_te.php";
                                              </script>
                                              ';
                                        }
                                      // $error1="you are not eligible for feedback ";
                                      // echo $error1;
                                    }
                                  if($feedback_given=='Yes'){
                                      if(mysqli_num_rows($result1)>0 && password_verify($pass, $password) ) {
                                      echo'<script>
                                           alert("Feedback already given");
                                           window.location = "detail_te.php";
                                        </script>';
                                      }
                                      // $error2="Feedback already given";
                                      // echo "$error2";
                                    }

                              }


                }elseif ($BE==$Adyr) {
                  if ($A==$division) {
                    $sql1="select eligible,feedback_given from studinfo_civila_be where grno='$grno'";
                    $result1=mysqli_query($conn,$sql1);   
                  }elseif ($B==$division) {
                    $sql1="select eligible,feedback_given from studinfo_civilb_be where grno='$grno'";
                    $result1=mysqli_query($conn,$sql1);    
                  }elseif ($C==$division) {
                    $sql1="select eligible,feedback_given from studinfo_civilc_be where grno='$grno'";
                    $result1=mysqli_query($conn,$sql1);   
                  }

                  while($row=$result1->fetch_assoc()){
                                $eligible = $row ['eligible'];
                                //echo"\n $eligible";
                                $feedback_given= $row['feedback_given'];
                              // echo "\n $feedback_given";
                            }

                            if($eligible!='No'&& $feedback_given!='Yes' ){
                                   // if($feedback_given!='Yes'||$feedback_given=='No' ){
                                      if( mysqli_num_rows($result)>0 && password_verify($pass, $password)){
                                      echo'<script>
                                         alert("Given Feedback");
                                       window.location = "feedback.php";  
                                      </script>';
                                    }
                               // }
                              }
                              else{
                                  if($eligible=='No'){
                                      if(mysqli_num_rows($result1)>0 && password_verify($pass, $password)) {
                                        echo '<script>
                                               confirm("you are not eligible for feedback");
                                               window.location = "detail_be.php";
                                              </script>
                                              ';
                                        }
                                      // $error1="you are not eligible for feedback ";
                                      // echo $error1;
                                    }
                                  if($feedback_given=='Yes'){
                                      if(mysqli_num_rows($result1)>0 && password_verify($pass, $password) ) {
                                      echo'<script>
                                           alert("Feedback already given");
                                           window.location = "detail_be.php";
                                        </script>';
                                      }
                                      // $error2="Feedback already given";
                                      // echo "$error2";
                                    }

                              }

                }

                            
                           
                              
                            
                //
               // mysqli_close($conn);

            // }
        

        ?>