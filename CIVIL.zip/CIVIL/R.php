<?php

	$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";

	

	$conn=new mysqli($servername,$username,$password,$dbname); 
	 if($conn->connect_error)
	 {
	 	die("connectivity Error:".$conn->connect_error);
	 }

	if(isset($_POST['register'])){
	session_start();
	// $_SESSION['full_name']=$full_name;

	$full_name=$_POST['full_name'];
	$email=$_POST['email'];
	$grno=$_POST['grno'];
	$Branch=$_POST['Branch'];
	echo $Branch;
	$Adyr=$_POST['Adyr'];
	$pass=$_POST['confirmPassword'];
	$CIVIL1='CIVIL SHIFT-I';
	$CIVIL2='CIVIL SHIFT-II';
	$dept='FE';

	if($CIVIL1==$Branch){
	$sql_u= "SELECT* FROM reg_civil1 WHERE full_name='$full_name' ";
	/*echo $sql_u;*/
	$sql_e= "SELECT * FROM reg_civil1 WHERE email='$email' ";
	$sql_g= "SELECT * FROM reg_civil1 WHERE grno='$grno' ";
	$res_u=mysqli_query($conn, $sql_u);
	$res_e=mysqli_query($conn, $sql_e);
	$res_g=mysqli_query($conn, $sql_g);
	}elseif ($CIVIL2==$Branch) {
		$sql_u= "SELECT* FROM reg_civil2 WHERE full_name='$full_name' ";
		/*echo $sql_u;*/
		$sql_e= "SELECT * FROM reg_civil2 WHERE email='$email' ";
		$sql_g= "SELECT * FROM reg_civil2 WHERE grno='$grno' ";
		$res_u=mysqli_query($conn, $sql_u);
		$res_e=mysqli_query($conn, $sql_e);
		$res_g=mysqli_query($conn, $sql_g);
	}
	
	
	if(mysqli_num_rows($res_u)> 0){
		$name_error= "User name already exist... ";
	}
	if(mysqli_num_rows($res_e)> 0){
		$email_error="Email already exiest...";
	}
	if(mysqli_num_rows($res_g)> 0){
		$grno_error="Grno already exist";
	}
	else{
		if($CIVIL1 == $Branch && $dept != $Adyr){
			$sql1="insert into reg_civil1(grno,full_name,email,department,year,password)values('$grno','$full_name','$email','$Branch','$Adyr','$pass')";

				 if(mysqli_query($conn,$sql1)){
				 	echo'<script>alert("Registration successfully");
			           
			            </script>';
				 }
				 else
				 {
				 	echo '<script>alert("Registration failed ");
			            window.location = "login.html";
			            </script>';
				 }
		}elseif($CIVIL2 == $Branch && $dept != $Adyr){
			$sql1="insert into reg_civil2(grno,full_name,email,department,year,password)values('$grno','$full_name','$email','$Branch','$Adyr','$pass')";

				 if(mysqli_query($conn,$sql1)){
				 	echo'<script>alert("Registration successfully");
			           
			            </script>';
				 }
				 else
				 {
				 	echo '<script>alert("Registration failed ");
			            window.location = "login.html";
			            </script>';
				 }
		}else{
			echo'<script>alert("You can not register in FE"); window.location="reg.php";</script>';
		}
	
	}
	}

	 $conn->close();
?>