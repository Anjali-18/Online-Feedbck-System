<?php include('eleconn.php');
session_start(); 
$sem=$_SESSION['sem'];
   $grno=$_SESSION['grno'];
   //echo $grno;
   $Adyr=$_SESSION['Adyr'];
   //echo $Adyr;
   $division=$_SESSION['division'];
   //echo $division;
   $dept=$_SESSION['department'];
   //echo $dept;
   
    $SE='SE';
    $TE='TE';
    $BE='BE';
    $A='A';
    $B='B';
    $C='C';

if($SE==$Adyr){
    if($A==$division){
         $sql2= "select `elec_no`,`batch` from elecdetail_civila_se where grno='$grno'";
            $res=mysqli_query($conn,$sql2);
            while($row=$res->fetch_assoc()){
                $elec = $row ['elec_no'];
               // echo"\n $elec";
                $batch= $row['batch'];
                //echo "\n $batch";
            }
    }elseif ($B==$division) {
       $sql2= "select `elec_no`,`batch` from elecdetail_civilb_se where grno='$grno'";
            $res=mysqli_query($conn,$sql2);
            while($row=$res->fetch_assoc()){
                $elec = $row ['elec_no'];
                //echo"\n $elec";
                $batch= $row['batch'];
              // echo "\n $batch";
            }    
        }elseif ($C==$division) {
             $sql2= "select `elec_no`,`batch` from elecdetail_civilc_se where grno='$grno'";
            $res=mysqli_query($conn,$sql2);
            while($row=$res->fetch_assoc()){
                $elec = $row ['elec_no'];
                //echo"\n $elec";
                $batch= $row['batch'];
              //  echo "\n $batch";
            }
         }
}else{
    if($TE==$Adyr){
        if($A==$division){
         $sql2= "select `elec_no`,`batch` from elecdetail_civila_te where grno='$grno'";
            $res=mysqli_query($conn,$sql2);
            while($row=$res->fetch_assoc()){
                $elec = $row ['elec_no'];
                //echo"\n $elec";
                $batch= $row['batch'];
              //  echo "\n $batch";
            }
    }elseif ($B==$division) {
       $sql2= "select `elec_no`,`batch` from elecdetail_civilb_te where grno='$grno'";
            $res=mysqli_query($conn,$sql2);
            while($row=$res->fetch_assoc()){
                $elec = $row ['elec_no'];
                //echo"\n $elec";
                $batch= $row['batch'];
              //  echo "\n $batch";
            }    
        }elseif ($C==$division) {
             $sql2= "select `elec_no`,`batch` from elecdetail_civilc_te where grno='$grno'";
            $res=mysqli_query($conn,$sql2);
            while($row=$res->fetch_assoc()){
                $elec = $row ['elec_no'];
                //echo"\n $elec";
                $batch= $row['batch'];
              //  echo "\n $batch";
            }
         }
        }else{
            if($BE==$Adyr){
                if($A==$division){
         $sql2= "select `elec_no`,`batch` from elecdetail_civila_be where grno='$grno'";
            $res=mysqli_query($conn,$sql2);
            while($row=$res->fetch_assoc()){
                $elec = $row ['elec_no'];
                //echo"\n $elec";
                $batch= $row['batch'];
              //  echo "\n $batch";
            }
    }elseif ($B==$division) {
       $sql2= "select `elec_no`,`batch` from elecdetail_civilb_be where grno='$grno'";
            $res=mysqli_query($conn,$sql2);
            while($row=$res->fetch_assoc()){
                $elec = $row ['elec_no'];
                //echo"\n $elec";
                $batch= $row['batch'];
              //  echo "\n $batch";
            }    
        }elseif ($C==$division) {
             $sql2= "select `elec_no`,`batch` from elecdetail_civilc_be where grno='$grno'";
            $res=mysqli_query($conn,$sql2);
            while($row=$res->fetch_assoc()){
                $elec = $row ['elec_no'];
                //echo"\n $elec";
                $batch= $row['batch'];
              //  echo "\n $batch";
            }
         }
            }
        }
}

if($A==$division){
        $result = mysqli_query($conn, "SELECT COUNT(*) AS `count` FROM `theory_civila` WHERE sem_no=$sem");
        $row = mysqli_fetch_array($result);
        $count = $row['count'];
        //echo $count;

        $q="SELECT COUNT(*) AS `counts` FROM `prac_civil_a` WHERE sem=$sem AND batch=$batch";
        //echo $q;
        $result1 = mysqli_query($conn,$q);
        $row1 = mysqli_fetch_array($result1);
        $count1 = $row1['counts'];
        //echo $count1;
   }elseif ($B==$division) {
        $result = mysqli_query($conn, "SELECT COUNT(*) AS `count` FROM `theory_civilb` WHERE sem_no=$sem");
        $row = mysqli_fetch_array($result);
        $count = $row['count'];
        //echo $count;

        $q="SELECT COUNT(*) AS `counts` FROM `prac_civil_b` WHERE sem=$sem AND batch=$batch";
        //echo $q;
        $result1 = mysqli_query($conn,$q);
        $row1 = mysqli_fetch_array($result1);
        $count1 = $row1['counts'];
        //echo $count1;
           
   }elseif ($C==$division) {
        $result = mysqli_query($conn, "SELECT COUNT(*) AS `count` FROM `theory_civilc` WHERE sem_no=$sem");
        $row = mysqli_fetch_array($result);
        $count = $row['count'];
        //echo $count;

        $q="SELECT COUNT(*) AS `counts` FROM `prac_civil_c` WHERE sem=$sem AND batch=$batch";
        //echo $q;
        $result1 = mysqli_query($conn,$q);
        $row1 = mysqli_fetch_array($result1);
        $count1 = $row1['counts'];
        //echo $count1;
   }


?> 
 
<!DOCTYPE html>
<html>                                   
<head>
    <title>Feedback</title>
    <link rel="stylesheet" class="bootswatcher" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/yeti/bootstrap.min.css" />
    <link href="css.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- Ajax Query -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    </head>
    <body>
 <nav class="navbar navbar-default" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><img src="//www.sce.edu.in/files/images/revera.png" height="45" class="pull-left" style="margin:  -15px 10px 0 10px;" />Saraswati College of Engineering</a>
    </div>
    
    <ul class="nav navbar-nav navbar-right">
     <li>
        <a class="nav-link" href="login.html">Log out <?php echo $grno;?></a>
    </li>
    </ul>
  </div>
</nav>
    

<style>
    .color{
        color: blue;
    }
</style>


<script>
    $(document).ready(function(){

        if ('1'== <?php echo $elec ?>)
        {
            $("#e1").show();
            $("#e2").hide();
            $("#e3").hide();
        }else if ('2'== <?php echo $elec ?>)
        {
            $("#e1").show();
            $("#e2").show();
            $("#e3").hide();
        }
        else if('3'== <?php echo $elec ?>){
             $("#e1").show();
            $("#e2").show();
            $("#e3").show();
        }
        else{
            $("#e1").hide();
            $("#e2").hide();
            $("#e3").hide();
        }
        });
</script> 


<div class="container">
    <div class="clearfix"></div>
    <h3 style="text-align: center; margin: 30px; color: green;">Student Feedback</h3>
     <p class="pull-left well color"><?php echo"\n$Adyr A"; echo "\n $dept ENGINEERING";?>  </p>
    <p class="pull-right well  color">Date : <?php echo date("D, d-M-yy")."\n"; ?></p>
    <div class="clearfix"></div>
  <ul  id="mytabs" class="nav nav-tabs" role="tablist" style="text-align:center">
    <li class="active"><a data-toggle="tab" href="#1">Theory Feedback</a></li>
    <li><a data-toggle="tab" href="#2">Practical Feedback</a></li>
    <li><a data-toggle="tab" href="#3">Library Feedback</a></li>
    <li><a data-toggle="tab" href="#4">Other Feedback</a></li>
  </ul>

<div class="tab-content">
    <div id="1" class="tab-pane fade in active">
        <form action="tf.php" method="POST">
    <?php /*include('feed.php');*/
                       
            if($SE==$Adyr){

                    if($A==$division){
                            $sql="select subject_name from theory_civila where sem_no=$sem";
                            $query=mysqli_query($conn, $sql);
                            $datas= array();
                            if(mysqli_num_rows($query)>0){
                                while($row= mysqli_fetch_assoc($query)){
                                    $datas[]= $row;
                                }
                            }

                            $sql1="select faculty_name from theory_civila where sem_no=$sem";
                            $query1=mysqli_query($conn, $sql1);
                            $datas1= array();
                            if(mysqli_num_rows($query1)>0){
                                while($row1= mysqli_fetch_assoc($query1)){
                                    $datas1[]= $row1;
                                }
                            }

                            $sql2="select elective_subject1 from elecdetail_civila_se where sem='$sem' and grno = '$grno'";
                            $query2=mysqli_query($conn, $sql2);
                            $datas2= array();
                            if(mysqli_num_rows($query2)>0){
                                while($row2= mysqli_fetch_assoc($query2)){
                                    $datas2[]= $row2;
                                }
                            }
                            $sql3="select faculty_name1 from elecdetail_civila_se where sem='$sem' and grno = '$grno'";
                            $query3=mysqli_query($conn, $sql3);
                            $datas3= array();
                            if(mysqli_num_rows($query3)>0){
                                while($row3= mysqli_fetch_assoc($query3)){
                                    $datas3[]= $row3;
                                }
                            }

                            $sql4="select elective_subject2 from elecdetail_civila_se where sem='$sem' and grno = '$grno'";
                            $query4=mysqli_query($conn, $sql4);
                            $datas4= array();
                            if(mysqli_num_rows($query4)>0){
                                while($row4= mysqli_fetch_assoc($query4)){
                                    $datas4[]= $row4;
                                }
                            }

                            $sql5="select faculty_name2 from elecdetail_civila_se where sem='$sem' and grno = '$grno'";
                            $query5=mysqli_query($conn, $sql5);
                            $datas5= array();
                            if(mysqli_num_rows($query5)>0){
                                while($row5= mysqli_fetch_assoc($query5)){
                                    $datas5[]= $row5;
                                }
                            }

                            $sql6="select elective_subject3 from elecdetail_civila_se where sem='$sem' and grno = '$grno'";
                            $query6=mysqli_query($conn, $sql6);
                            $datas6= array();
                            if(mysqli_num_rows($query6)>0){
                                while($row6= mysqli_fetch_assoc($query6)){
                                    $datas6[]= $row6;
                                }
                            }

                            $sql7="select faculty_name3 from elecdetail_civila_se where sem='$sem' and grno = '$grno'";
                            $query7=mysqli_query($conn, $sql7);
                            $datas7= array();
                            if(mysqli_num_rows($query7)>0){
                                while($row7= mysqli_fetch_assoc($query7)){
                                    $datas7[]= $row7;
                                }
                            }
                    }elseif ($B==$division) {
                            $sql="select subject_name from theory_civilb where sem_no=$sem";
                            $query=mysqli_query($conn, $sql);
                            $datas= array();
                            if(mysqli_num_rows($query)>0){
                                while($row= mysqli_fetch_assoc($query)){
                                    $datas[]= $row;
                                }
                            }

                            $sql1="select faculty_name from theory_civilb where sem_no=$sem";
                            $query1=mysqli_query($conn, $sql1);
                            $datas1= array();
                            if(mysqli_num_rows($query1)>0){
                                while($row1= mysqli_fetch_assoc($query1)){
                                    $datas1[]= $row1;
                                }
                            }

                            $sql2="select elective_subject1 from elecdetail_civilb_se where sem='$sem' and grno = '$grno'";
                            $query2=mysqli_query($conn, $sql2);
                            $datas2= array();
                            if(mysqli_num_rows($query2)>0){
                                while($row2= mysqli_fetch_assoc($query2)){
                                    $datas2[]= $row2;
                                }
                            }
                            $sql3="select faculty_name1 from elecdetail_civilb_se where sem='$sem' and grno = '$grno'";
                            $query3=mysqli_query($conn, $sql3);
                            $datas3= array();
                            if(mysqli_num_rows($query3)>0){
                                while($row3= mysqli_fetch_assoc($query3)){
                                    $datas3[]= $row3;
                                }
                            }

                            $sql4="select elective_subject2 from elecdetail_civilb_se where sem='$sem' and grno = '$grno'";
                            $query4=mysqli_query($conn, $sql4);
                            $datas4= array();
                            if(mysqli_num_rows($query4)>0){
                                while($row4= mysqli_fetch_assoc($query4)){
                                    $datas4[]= $row4;
                                }
                            }

                            $sql5="select faculty_name2 from elecdetail_civilb_se where sem='$sem' and grno = '$grno'";
                            $query5=mysqli_query($conn, $sql5);
                            $datas5= array();
                            if(mysqli_num_rows($query5)>0){
                                while($row5= mysqli_fetch_assoc($query5)){
                                    $datas5[]= $row5;
                                }
                            }

                            $sql6="select elective_subject3 from elecdetail_civilb_se where sem='$sem' and grno = '$grno'";
                            $query6=mysqli_query($conn, $sql6);
                            $datas6= array();
                            if(mysqli_num_rows($query6)>0){
                                while($row6= mysqli_fetch_assoc($query6)){
                                    $datas6[]= $row6;
                                }
                            }

                            $sql7="select faculty_name3 from elecdetail_civilb_se where sem='$sem' and grno = '$grno'";
                            $query7=mysqli_query($conn, $sql7);
                            $datas7= array();
                            if(mysqli_num_rows($query7)>0){
                                while($row7= mysqli_fetch_assoc($query7)){
                                    $datas7[]= $row7;
                                }
                            }
                    }elseif ($C==$division) {
                            $sql="select subject_name from theory_auto where sem_no=$sem";
                            $query=mysqli_query($conn, $sql);
                            $datas= array();
                            if(mysqli_num_rows($query)>0){
                                while($row= mysqli_fetch_assoc($query)){
                                    $datas[]= $row;
                                }
                            }

                            $sql1="select faculty_name from theory_auto where sem_no=$sem";
                            $query1=mysqli_query($conn, $sql1);
                            $datas1= array();
                            if(mysqli_num_rows($query1)>0){
                                while($row1= mysqli_fetch_assoc($query1)){
                                    $datas1[]= $row1;
                                }
                            }

                            $sql2="select elective_subject1 from elecdetail_auto_se where sem='$sem' and grno = '$grno'";
                            $query2=mysqli_query($conn, $sql2);
                            $datas2= array();
                            if(mysqli_num_rows($query2)>0){
                                while($row2= mysqli_fetch_assoc($query2)){
                                    $datas2[]= $row2;
                                }
                            }
                            $sql3="select faculty_name1 from elecdetail_auto_se where sem='$sem' and grno = '$grno'";
                            $query3=mysqli_query($conn, $sql3);
                            $datas3= array();
                            if(mysqli_num_rows($query3)>0){
                                while($row3= mysqli_fetch_assoc($query3)){
                                    $datas3[]= $row3;
                                }
                            }

                            $sql4="select elective_subject2 from elecdetail_auto_se where sem='$sem' and grno = '$grno'";
                            $query4=mysqli_query($conn, $sql4);
                            $datas4= array();
                            if(mysqli_num_rows($query4)>0){
                                while($row4= mysqli_fetch_assoc($query4)){
                                    $datas4[]= $row4;
                                }
                            }

                            $sql5="select faculty_name2 from elecdetail_auto_se where sem='$sem' and grno = '$grno'";
                            $query5=mysqli_query($conn, $sql5);
                            $datas5= array();
                            if(mysqli_num_rows($query5)>0){
                                while($row5= mysqli_fetch_assoc($query5)){
                                    $datas5[]= $row5;
                                }
                            }

                            $sql6="select elective_subject3 from elecdetail_auto_be where sem='$sem' and grno = '$grno'";
                            $query6=mysqli_query($conn, $sql6);
                            $datas6= array();
                            if(mysqli_num_rows($query6)>0){
                                while($row6= mysqli_fetch_assoc($query6)){
                                    $datas6[]= $row6;
                                }
                            }

                            $sql7="select faculty_name3 from elecdetail_auto_be where sem='$sem' and grno = '$grno'";
                            $query7=mysqli_query($conn, $sql7);
                            $datas7= array();
                            if(mysqli_num_rows($query7)>0){
                                while($row7= mysqli_fetch_assoc($query7)){
                                    $datas7[]= $row7;
                                }
                            }
                        }
            }elseif($TE==$Adyr){
                    if($A==$division){
                            $sql="select subject_name from theory_civila where sem_no=$sem";
                            $query=mysqli_query($conn, $sql);
                            $datas= array();
                            if(mysqli_num_rows($query)>0){
                                while($row= mysqli_fetch_assoc($query)){
                                    $datas[]= $row;
                                }
                            }

                            $sql1="select faculty_name from theory_civila where sem_no=$sem";
                            $query1=mysqli_query($conn, $sql1);
                            $datas1= array();
                            if(mysqli_num_rows($query1)>0){
                                while($row1= mysqli_fetch_assoc($query1)){
                                    $datas1[]= $row1;
                                }
                            }

                            $sql2="select elective_subject1 from elecdetail_civila_te where sem='$sem' and grno = '$grno'";
                            $query2=mysqli_query($conn, $sql2);
                            $datas2= array();
                            if(mysqli_num_rows($query2)>0){
                                while($row2= mysqli_fetch_assoc($query2)){
                                    $datas2[]= $row2;
                                }
                            }
                            $sql3="select faculty_name1 from elecdetail_civila_te where sem='$sem' and grno = '$grno'";
                            $query3=mysqli_query($conn, $sql3);
                            $datas3= array();
                            if(mysqli_num_rows($query3)>0){
                                while($row3= mysqli_fetch_assoc($query3)){
                                    $datas3[]= $row3;
                                }
                            }

                            $sql4="select elective_subject2 from elecdetail_civila_te where sem='$sem' and grno = '$grno'";
                            $query4=mysqli_query($conn, $sql4);
                            $datas4= array();
                            if(mysqli_num_rows($query4)>0){
                                while($row4= mysqli_fetch_assoc($query4)){
                                    $datas4[]= $row4;
                                }
                            }

                            $sql5="select faculty_name2 from elecdetail_civila_te where sem='$sem' and grno = '$grno'";
                            $query5=mysqli_query($conn, $sql5);
                            $datas5= array();
                            if(mysqli_num_rows($query5)>0){
                                while($row5= mysqli_fetch_assoc($query5)){
                                    $datas5[]= $row5;
                                }
                            }

                            $sql6="select elective_subject3 from elecdetail_civila_te where sem='$sem' and grno = '$grno'";
                            $query6=mysqli_query($conn, $sql6);
                            $datas6= array();
                            if(mysqli_num_rows($query6)>0){
                                while($row6= mysqli_fetch_assoc($query6)){
                                    $datas6[]= $row6;
                                }
                            }

                            $sql7="select faculty_name3 from elecdetail_civila_te where sem='$sem' and grno = '$grno'";
                            $query7=mysqli_query($conn, $sql7);
                            $datas7= array();
                            if(mysqli_num_rows($query7)>0){
                                while($row7= mysqli_fetch_assoc($query7)){
                                    $datas7[]= $row7;
                                }
                            }
                    }elseif ($B==$division) {
                            $sql="select subject_name from theory_civilb where sem_no=$sem";
                            $query=mysqli_query($conn, $sql);
                            $datas= array();
                            if(mysqli_num_rows($query)>0){
                                while($row= mysqli_fetch_assoc($query)){
                                    $datas[]= $row;
                                }
                            }

                            $sql1="select faculty_name from theory_civilb where sem_no=$sem";
                            $query1=mysqli_query($conn, $sql1);
                            $datas1= array();
                            if(mysqli_num_rows($query1)>0){
                                while($row1= mysqli_fetch_assoc($query1)){
                                    $datas1[]= $row1;
                                }
                            }

                            $sql2="select elective_subject1 from elecdetail_civilb_te where sem='$sem' and grno = '$grno'";
                            $query2=mysqli_query($conn, $sql2);
                            $datas2= array();
                            if(mysqli_num_rows($query2)>0){
                                while($row2= mysqli_fetch_assoc($query2)){
                                    $datas2[]= $row2;
                                }
                            }
                            $sql3="select faculty_name1 from elecdetail_civilb_te where sem='$sem' and grno = '$grno'";
                            $query3=mysqli_query($conn, $sql3);
                            $datas3= array();
                            if(mysqli_num_rows($query3)>0){
                                while($row3= mysqli_fetch_assoc($query3)){
                                    $datas3[]= $row3;
                                }
                            }

                            $sql4="select elective_subject2 from elecdetail_civilb_te where sem='$sem' and grno = '$grno'";
                            $query4=mysqli_query($conn, $sql4);
                            $datas4= array();
                            if(mysqli_num_rows($query4)>0){
                                while($row4= mysqli_fetch_assoc($query4)){
                                    $datas4[]= $row4;
                                }
                            }

                            $sql5="select faculty_name2 from elecdetail_civilb_te where sem='$sem' and grno = '$grno'";
                            $query5=mysqli_query($conn, $sql5);
                            $datas5= array();
                            if(mysqli_num_rows($query5)>0){
                                while($row5= mysqli_fetch_assoc($query5)){
                                    $datas5[]= $row5;
                                }
                            }

                            $sql6="select elective_subject3 from elecdetail_civilb_te where sem='$sem' and grno = '$grno'";
                            $query6=mysqli_query($conn, $sql6);
                            $datas6= array();
                            if(mysqli_num_rows($query6)>0){
                                while($row6= mysqli_fetch_assoc($query6)){
                                    $datas6[]= $row6;
                                }
                            }

                            $sql7="select faculty_name3 from elecdetail_civilb_te where sem='$sem' and grno = '$grno'";
                            $query7=mysqli_query($conn, $sql7);
                            $datas7= array();
                            if(mysqli_num_rows($query7)>0){
                                while($row7= mysqli_fetch_assoc($query7)){
                                    $datas7[]= $row7;
                                }
                            }
                    }elseif ($C==$division) {
                            $sql="select subject_name from theory_civilc where sem_no=$sem";
                            $query=mysqli_query($conn, $sql);
                            $datas= array();
                            if(mysqli_num_rows($query)>0){
                                while($row= mysqli_fetch_assoc($query)){
                                    $datas[]= $row;
                                }
                            }

                            $sql1="select faculty_name from theory_civilc where sem_no=$sem";
                            $query1=mysqli_query($conn, $sql1);
                            $datas1= array();
                            if(mysqli_num_rows($query1)>0){
                                while($row1= mysqli_fetch_assoc($query1)){
                                    $datas1[]= $row1;
                                }
                            }

                            $sql2="select elective_subject1 from elecdetail_civilc_te where sem='$sem' and grno = '$grno'";
                            $query2=mysqli_query($conn, $sql2);
                            $datas2= array();
                            if(mysqli_num_rows($query2)>0){
                                while($row2= mysqli_fetch_assoc($query2)){
                                    $datas2[]= $row2;
                                }
                            }
                            $sql3="select faculty_name1 from elecdetail_civilc_te where sem='$sem' and grno = '$grno'";
                            $query3=mysqli_query($conn, $sql3);
                            $datas3= array();
                            if(mysqli_num_rows($query3)>0){
                                while($row3= mysqli_fetch_assoc($query3)){
                                    $datas3[]= $row3;
                                }
                            }

                            $sql4="select elective_subject2 from elecdetail_civilc_te where sem='$sem' and grno = '$grno'";
                            $query4=mysqli_query($conn, $sql4);
                            $datas4= array();
                            if(mysqli_num_rows($query4)>0){
                                while($row4= mysqli_fetch_assoc($query4)){
                                    $datas4[]= $row4;
                                }
                            }

                            $sql5="select faculty_name2 from elecdetail_civilc_te where sem='$sem' and grno = '$grno'";
                            $query5=mysqli_query($conn, $sql5);
                            $datas5= array();
                            if(mysqli_num_rows($query5)>0){
                                while($row5= mysqli_fetch_assoc($query5)){
                                    $datas5[]= $row5;
                                }
                            }

                            $sql6="select elective_subject3 from elecdetail_civilc_te where sem='$sem' and grno = '$grno'";
                            $query6=mysqli_query($conn, $sql6);
                            $datas6= array();
                            if(mysqli_num_rows($query6)>0){
                                while($row6= mysqli_fetch_assoc($query6)){
                                    $datas6[]= $row6;
                                }
                            }

                            $sql7="select faculty_name3 from elecdetail_civilc_te where sem='$sem' and grno = '$grno'";
                            $query7=mysqli_query($conn, $sql7);
                            $datas7= array();
                            if(mysqli_num_rows($query7)>0){
                                while($row7= mysqli_fetch_assoc($query7)){
                                    $datas7[]= $row7;
                                }
                            }
                        }
            }elseif ($BE==$Adyr) {
                    if($A==$division){
                            $sql="select subject_name from theory_civila where sem_no=$sem";
                            $query=mysqli_query($conn, $sql);
                            $datas= array();
                            if(mysqli_num_rows($query)>0){
                                while($row= mysqli_fetch_assoc($query)){
                                    $datas[]= $row;
                                }
                            }

                            $sql1="select faculty_name from theory_civila where sem_no=$sem";
                            $query1=mysqli_query($conn, $sql1);
                            $datas1= array();
                            if(mysqli_num_rows($query1)>0){
                                while($row1= mysqli_fetch_assoc($query1)){
                                    $datas1[]= $row1;
                                }
                            }

                            $sql2="select elective_subject1 from elecdetail_civila_be where sem='$sem' and grno = '$grno'";
                            $query2=mysqli_query($conn, $sql2);
                            $datas2= array();
                            if(mysqli_num_rows($query2)>0){
                                while($row2= mysqli_fetch_assoc($query2)){
                                    $datas2[]= $row2;
                                }
                            }
                            $sql3="select faculty_name1 from elecdetail_civila_be where sem='$sem' and grno = '$grno'";
                            $query3=mysqli_query($conn, $sql3);
                            $datas3= array();
                            if(mysqli_num_rows($query3)>0){
                                while($row3= mysqli_fetch_assoc($query3)){
                                    $datas3[]= $row3;
                                }
                            }

                            $sql4="select elective_subject2 from elecdetail_civila_be where sem='$sem' and grno = '$grno'";
                            $query4=mysqli_query($conn, $sql4);
                            $datas4= array();
                            if(mysqli_num_rows($query4)>0){
                                while($row4= mysqli_fetch_assoc($query4)){
                                    $datas4[]= $row4;
                                }
                            }

                            $sql5="select faculty_name2 from elecdetail_civila_be where sem='$sem' and grno = '$grno'";
                            $query5=mysqli_query($conn, $sql5);
                            $datas5= array();
                            if(mysqli_num_rows($query5)>0){
                                while($row5= mysqli_fetch_assoc($query5)){
                                    $datas5[]= $row5;
                                }
                            }

                            $sql6="select elective_subject3 from elecdetail_civila_be where sem='$sem' and grno = '$grno'";
                            $query6=mysqli_query($conn, $sql6);
                            $datas6= array();
                            if(mysqli_num_rows($query6)>0){
                                while($row6= mysqli_fetch_assoc($query6)){
                                    $datas6[]= $row6;
                                }
                            }

                            $sql7="select faculty_name3 from elecdetail_civila_be where sem='$sem' and grno = '$grno'";
                            $query7=mysqli_query($conn, $sql7);
                            $datas7= array();
                            if(mysqli_num_rows($query7)>0){
                                while($row7= mysqli_fetch_assoc($query7)){
                                    $datas7[]= $row7;
                                }
                            }
                    }elseif ($B==$division) {
                            $sql="select subject_name from theory_civilb where sem_no=$sem";
                            $query=mysqli_query($conn, $sql);
                            $datas= array();
                            if(mysqli_num_rows($query)>0){
                                while($row= mysqli_fetch_assoc($query)){
                                    $datas[]= $row;
                                }
                            }

                            $sql1="select faculty_name from theory_civilb where sem_no=$sem";
                            $query1=mysqli_query($conn, $sql1);
                            $datas1= array();
                            if(mysqli_num_rows($query1)>0){
                                while($row1= mysqli_fetch_assoc($query1)){
                                    $datas1[]= $row1;
                                }
                            }

                            $sql2="select elective_subject1 from elecdetail_civilb_be where sem='$sem' and grno = '$grno'";
                            $query2=mysqli_query($conn, $sql2);
                            $datas2= array();
                            if(mysqli_num_rows($query2)>0){
                                while($row2= mysqli_fetch_assoc($query2)){
                                    $datas2[]= $row2;
                                }
                            }
                            $sql3="select faculty_name1 from elecdetail_civilb_be where sem='$sem' and grno = '$grno'";
                            $query3=mysqli_query($conn, $sql3);
                            $datas3= array();
                            if(mysqli_num_rows($query3)>0){
                                while($row3= mysqli_fetch_assoc($query3)){
                                    $datas3[]= $row3;
                                }
                            }

                            $sql4="select elective_subject2 from elecdetail_civilb_be where sem='$sem' and grno = '$grno'";
                            $query4=mysqli_query($conn, $sql4);
                            $datas4= array();
                            if(mysqli_num_rows($query4)>0){
                                while($row4= mysqli_fetch_assoc($query4)){
                                    $datas4[]= $row4;
                                }
                            }

                            $sql5="select faculty_name2 from elecdetail_civilb_be where sem='$sem' and grno = '$grno'";
                            $query5=mysqli_query($conn, $sql5);
                            $datas5= array();
                            if(mysqli_num_rows($query5)>0){
                                while($row5= mysqli_fetch_assoc($query5)){
                                    $datas5[]= $row5;
                                }
                            }

                            $sql6="select elective_subject3 from elecdetail_civilb_be where sem='$sem' and grno = '$grno'";
                            $query6=mysqli_query($conn, $sql6);
                            $datas6= array();
                            if(mysqli_num_rows($query6)>0){
                                while($row6= mysqli_fetch_assoc($query6)){
                                    $datas6[]= $row6;
                                }
                            }

                            $sql7="select faculty_name3 from elecdetail_civilb_be where sem='$sem' and grno = '$grno'";
                            $query7=mysqli_query($conn, $sql7);
                            $datas7= array();
                            if(mysqli_num_rows($query7)>0){
                                while($row7= mysqli_fetch_assoc($query7)){
                                    $datas7[]= $row7;
                                }
                            }
                    }elseif ($C==$division) {
                            $sql="select subject_name from theory_civilc where sem_no=$sem";
                            $query=mysqli_query($conn, $sql);
                            $datas= array();
                            if(mysqli_num_rows($query)>0){
                                while($row= mysqli_fetch_assoc($query)){
                                    $datas[]= $row;
                                }
                            }

                            $sql1="select faculty_name from theory_civilc where sem_no=$sem";
                            $query1=mysqli_query($conn, $sql1);
                            $datas1= array();
                            if(mysqli_num_rows($query1)>0){
                                while($row1= mysqli_fetch_assoc($query1)){
                                    $datas1[]= $row1;
                                }
                            }

                            $sql2="select elective_subject1 from elecdetail_civilc_be where sem='$sem' and grno = '$grno'";
                            $query2=mysqli_query($conn, $sql2);
                            $datas2= array();
                            if(mysqli_num_rows($query2)>0){
                                while($row2= mysqli_fetch_assoc($query2)){
                                    $datas2[]= $row2;
                                }
                            }
                            $sql3="select faculty_name1 from elecdetail_civilc_be where sem='$sem' and grno = '$grno'";
                            $query3=mysqli_query($conn, $sql3);
                            $datas3= array();
                            if(mysqli_num_rows($query3)>0){
                                while($row3= mysqli_fetch_assoc($query3)){
                                    $datas3[]= $row3;
                                }
                            }

                            $sql4="select elective_subject2 from elecdetail_civilc_be where sem='$sem' and grno = '$grno'";
                            $query4=mysqli_query($conn, $sql4);
                            $datas4= array();
                            if(mysqli_num_rows($query4)>0){
                                while($row4= mysqli_fetch_assoc($query4)){
                                    $datas4[]= $row4;
                                }
                            }

                            $sql5="select faculty_name2 from elecdetail_civilc_be where sem='$sem' and grno = '$grno'";
                            $query5=mysqli_query($conn, $sql5);
                            $datas5= array();
                            if(mysqli_num_rows($query5)>0){
                                while($row5= mysqli_fetch_assoc($query5)){
                                    $datas5[]= $row5;
                                }
                            }

                            $sql6="select elective_subject3 from elecdetail_civilc_be where sem='$sem' and grno = '$grno'";
                            $query6=mysqli_query($conn, $sql6);
                            $datas6= array();
                            if(mysqli_num_rows($query6)>0){
                                while($row6= mysqli_fetch_assoc($query6)){
                                    $datas6[]= $row6;
                                }
                            }

                            $sql7="select faculty_name3 from elecdetail_civilc_be where sem='$sem' and grno = '$grno'";
                            $query7=mysqli_query($conn, $sql7);
                            $datas7= array();
                            if(mysqli_num_rows($query7)>0){
                                while($row7= mysqli_fetch_assoc($query7)){
                                    $datas7[]= $row7;
                                }
                            }
                        }
                }    
                            //print_r($datas);
        ?>
                <div id="t1">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                        <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h6><?php foreach($datas[0] as $data){echo $data;}?></h6>
                                <h4><?php foreach($datas1[0] as $data1){echo $data1;}?></h4>
                            </div>
                            <input type='hidden' name='fac1' value="<?php error_reporting(0); foreach($datas[0] as $data){echo $data;}?>" />
                            <input type='hidden' name='sub1' value="<?php error_reporting(0); foreach($datas1[0] as $data1){echo $data1;}?>" />
                            <div class="form-group mt-4">
                                <select name="s1q1" class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class="form-group mt-4">
                                <select name="s1q2" class='form-control  mt-4'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name="s1q3" class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name="s1q4" class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name="s1q5" class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>

                </div>

                <div id="t2">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                        <div class='col-md-4 ' id="answers" >
                            <div class="fac">
                                <h5><?php foreach($datas[1] as $data){echo $data;}?></h5>
                                <h4><?php foreach($datas1[1] as $data1){echo $data1;}?></h4>
                            </div>
                            <input type='hidden' name='fac2' value="<?php error_reporting(0); foreach($datas[1] as $data){echo $data;}?>" />
                            <input type='hidden' name='sub2' value="<?php error_reporting(0); foreach($datas1[1] as $data1){echo $data1;}?>" />
                            <div class='form-group'>
                                <select name='s2q1' class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s2q2' class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s2q3' class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s2q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s2q5' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="t3">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                         <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas[2] as $data){echo $data;}?></h5>
                                <h4><?php foreach($datas1[2] as $data1){echo $data1;}?></h4>
                            </div>
                            <input type='hidden' name='fac3' value='<?php error_reporting(0); foreach($datas[2] as $data){echo $data;}?>' />
                            <input type='hidden' name='sub3' value='<?php error_reporting(0); foreach($datas1[2] as $data1){echo $data1;}?>' />
                            <div class='form-group'>
                                <select name='s3q1' class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s3q2' class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s3q3' class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s3q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s3q5' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

               <div id="t4">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                         <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas[3] as $data){echo $data;}?></h5>
                                <h4><?php foreach($datas1[3] as $data1){echo $data1;}?></h4>
                            </div>
                            <input type='hidden' name='fac4' value='<?php error_reporting(0); foreach($datas[3] as $data){echo $data;}?>' />
                            <input type='hidden' name='sub4' value='<?php error_reporting(0); foreach($datas1[3] as $data1){echo $data1;}?>' />
                            <div class='form-group'>
                                <select name='s4q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s4q2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s4q3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s4q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s4q5' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
               </div>

                <div id="t5">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                         <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas[4] as $data){echo $data;}?></h5>
                                <h4><?php foreach($datas1[4] as $data1){echo $data1;}?></h4>
                            </div>
                            <input type='hidden' name='fac5' value='<?php error_reporting(0); foreach($datas[4] as $data){echo $data;}?>' />
                            <input type='hidden' name='sub5' value='<?php error_reporting(0); foreach($datas1[4] as $data1){echo $data1;}?>' />
                            <div class='form-group'>
                                <select name='s5q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s5q2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s5q3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s5q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s5q5' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="t6">
                    <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                         <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas[5] as $data){echo $data;}?></h5>
                                <h4><?php foreach($datas1[5] as $data1){echo $data1;}?></h4>
                            </div>
                            <input type='hidden' name='fac6' value='<?php error_reporting(0); foreach($datas[5] as $data){echo $data;}?>' />
                            <input type='hidden' name='sub6' value='<?php error_reporting(0); foreach($datas1[5] as $data1){echo $data1;}?>' />
                            <div class='form-group'>
                                <select name='s6q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s6q2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s6q3' class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s6q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s6q5' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="t7">
                    <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                         <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas[6] as $data){echo $data;}?></h5>
                                <h4><?php foreach($datas1[6] as $data1){echo $data1;}?></h4>
                            </div>
                            <input type='hidden' name='fac7' value='<?php error_reporting(0); foreach($datas[6] as $data){echo $data;}?>' />
                            <input type='hidden' name='sub7' value='<?php error_reporting(0); foreach($datas1[6] as $data1){echo $data1;}?>' />
                            <div class='form-group'>
                                <select name='s7q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s7q2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s7q3' class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s7q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s7q5' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>


                <div id="e1">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                        <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas2[0] as $data2){echo $data2;}?></h5>
                                <h4><?php foreach($datas3[0] as $data3){echo $data3;}?></h4>
                            </div>
                            <input type='hidden' name='fac8' value='<?php error_reporting(0); foreach($datas2[0] as $data2){echo $data2;}?>' />
                            <input type='hidden' name='sub8' value='<?php error_reporting(0); foreach($datas3[0] as $data3){echo $data3;}?>' />
                            <div class='form-group'>
                                <select name='s8q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s8q2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s8q3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s8q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s8q5' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>

                </div>

               <div id="e2">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                        <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas4[0] as $data4){echo $data4;}?></h5>
                                <h4><?php foreach($datas5[0] as $data5){echo $data5;}?></h4>
                            </div>
                            <input type='hidden' name='fac9' value='<?php error_reporting(0); foreach($datas4[0] as $data4){echo $data4;}?>' />
                            <input type='hidden' name='sub9' value='<?php error_reporting(0); foreach($datas5[0] as $data5){echo $data5;}?>' />
                            <div class='form-group'>
                                <select name='s9q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s9q2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s9q3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s9q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s9q5' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>

               </div>

               <div id="e3">
                <div id="questions" class="col-md-8 questions">
                <h4 class="color">Questions</h4>
                <ol >
                    <li> Understanding content delivery of lecture</li>
                    <li>Communication skills / presentation ability of teacher</li>
                    <li>Are  the lectures lively, interactive & interesting?</li>
                    <li>Efforts put in by teacher to give additional information</li>
                    <li>Appreciation and motivation by teacher to solve the difficulties</li>

                </ol>
                </div>
                        <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas6[0] as $data6){echo $data6;}?></h5>
                                <h4><?php foreach($datas7[0] as $data7){echo $data7;}?></h4>
                            </div>
                            <input type='hidden' name='fac10' value='<?php error_reporting(0); foreach($datas6[0] as $data6){echo $data6;}?>' />
                            <input type='hidden' name='sub10' value='<?php error_reporting(0); foreach($datas7[0] as $data7){echo $data7;}?>' />
                            <div class='form-group'>
                                <select name='s10q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s10q2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s10q3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s10q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='s10q5' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row"></div>
               <div class="row mt-10">

                   <center><button class="btn-success btn">Submit</button></center>

               </div>
<script type="text/JavaScript">
    function myFunction() {
    var i,l;
    l = <?php echo $count?>;
    for (i = l+1; i <=7; i++) {
        var j="t"+i.toString();
        console.log(j);
      document.getElementById(j).style.display = "none";

    }
}
myFunction()
</script>              

</form>
</div>

<div id="2" class="tab-pane">
<form action="pf.php" method="POST">

                <?php

                    if($A==$division){
                        $sql8="select subject_name from prac_civil_a where sem=$sem and batch=$batch";
                       // echo $sql8;
                        $query8=mysqli_query($conn, $sql8);
                        $datas8= array();
                        if(mysqli_num_rows($query8)>0){
                            while($row8= mysqli_fetch_assoc($query8)){
                                        $datas8[]= $row8;
                                }
                        }   
                        //print_r($datas4);
                        $sql9="select faculty_name from prac_civil_a where sem=$sem and batch=$batch";
                        $query9=mysqli_query($conn, $sql9);
                        $datas9= array();
                        if(mysqli_num_rows($query9)>0){
                            while($row9= mysqli_fetch_assoc($query9)){
                                        $datas9[]= $row9;
                                }
                        }

                    }elseif ($B==$division) {
                        $sql8="select subject_name from prac_civil_b where sem=$sem and batch=$batch";
                       // echo $sql8;
                        $query8=mysqli_query($conn, $sql8);
                        $datas8= array();
                        if(mysqli_num_rows($query8)>0 ){
                            while($row8= mysqli_fetch_assoc($query8)){
                                        $datas8[]= $row8;
                                }
                        }   
                        //print_r($datas4);
                        $sql9="select faculty_name from prac_civil_b where sem=$sem and batch=$batch";
                        $query9=mysqli_query($conn, $sql9);
                        $datas9= array();
                        if(mysqli_num_rows($query9)>0){
                            while($row9= mysqli_fetch_assoc($query9)){
                                        $datas9[]= $row9;
                                }
                        }
                           
                    }elseif ($C==$division) {
                        $sql8="select subject_name from prac_civil_c where sem=$sem and batch=$batch";
                       // echo $sql8;
                        $query8=mysqli_query($conn, $sql8);
                        $datas8= array();
                        if(mysqli_num_rows($query8)>0){
                            while($row8= mysqli_fetch_assoc($query8)){
                                        $datas8[]= $row8;
                                }
                        }   
                        //print_r($datas4);
                        $sql9="select faculty_name from prac_civil_c where sem=$sem and batch=$batch";
                        $query9=mysqli_query($conn, $sql9);
                        $datas9= array();
                        if(mysqli_num_rows($query9)>0){
                            while($row9= mysqli_fetch_assoc($query9)){
                                        $datas9[]= $row9;
                                }
                        }
                           
                    }



                              
                ?>

                <div id="p1">
                <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>               
                </ol>
                </div>
                         <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas8[0] as $data8){echo $data8;}?></h5>
                                <h4><?php foreach($datas9[0] as $data9){echo $data9;}?></h4>
                            </div>
                            <input type='hidden' name='fac1' value='<?php error_reporting(0); foreach($datas8[0] as $data8){echo $data8;}?>' />
                            <input type='hidden' name='sub1' value='<?php error_reporting(0); foreach($datas9[0] as $data9){echo $data9;}?>' />
                            <div class='form-group'>
                                <select name='p1q1' class='form-control mt-10'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p1q2' class='form-control mt-10'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p1q3' class='form-control mt-10'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p1q4' class='form-control mt-10'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="p2">
                <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>               
                </ol>
                </div>
                         <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas8[1] as $data8){echo $data8;}?></h5>
                                <h4><?php foreach($datas9[1] as $data9){echo $data9;}?></h4>
                            </div>
                            <input type='hidden' name='fac2' value='<?php error_reporting(0); foreach($datas8[1] as $data8){echo $data8;}?>' />
                            <input type='hidden' name='sub2' value='<?php error_reporting(0); foreach($datas9[1] as $data9){echo $data9;}?>' />
                            <div class='form-group'>
                                <select name='p2q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p2q2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p2q3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p2q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="p3">
                <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>               
                </ol>
                </div>
                         <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas8[2] as $data8){echo $data8;}?></h5>
                                <h4><?php foreach($datas9[2] as $data9){echo $data9;}?></h4>
                            </div>
                            <input type='hidden' name='fac3' value='<?php error_reporting(0); foreach($datas8[2] as $data8){echo $data8;}?>' />
                            <input type='hidden' name='sub3' value='<?php error_reporting(0); foreach($datas9[2] as $data9){echo $data9;}?>' />
                            <div class='form-group'>
                                <select name='p3q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p3q2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p3q3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p3q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="p4">
                <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>               
                </ol>
                </div>
                         <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas8[3] as $data8){echo $data8;}?></h5>
                                <h4><?php foreach($datas9[3] as $data9){echo $data9;}?></h4>
                            </div>
                            <input type='hidden' name='fac4' value='<?php error_reporting(0); foreach($datas8[3] as $data8){echo $data8;}?>' />
                            <input type='hidden' name='sub4' value='<?php error_reporting(0); foreach($datas9[3] as $data9){echo $data9;}?>' />
                            <div class='form-group'>
                                <select name='p4q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p4q2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p4q3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p4q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="p5">
                <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>               
                </ol>
                </div>
                        <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas8[4] as $data8){echo $data8;}?></h5>
                                <h4><?php foreach($datas9[4] as $data9){echo $data9;}?></h4>
                            </div>
                            <input type='hidden' name='fac5' value='<?php error_reporting(0); foreach($datas8[4] as $data8){echo $data8;}?>' />
                            <input type='hidden' name='sub5' value='<?php error_reporting(0); foreach($datas9[4] as $data9){echo $data9;}?>' />
                            <div class='form-group'>
                                <select name='p5q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p5q2' class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p5q3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p5q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div id="p6">
                <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol>
                    <li>Involvement of faculty</li>
                    <li>Avaialability of resources in lab</li>
                    <li>Are the objectives and scopes being explained by the faculty?</li>
                    <li>Timely evaluation of experiment records</li>               
                </ol>
                </div>
                        <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5><?php foreach($datas8[5] as $data8){echo $data8;}?></h5>
                                <h4><?php foreach($datas9[5] as $data9){echo $data9;}?></h4>
                            </div>
                            <input type='hidden' name='fac6' value='<?php error_reporting(0); foreach($datas8[5] as $data8){echo $data8;}?>' />
                            <input type='hidden' name='sub6' value='<?php error_reporting(0); foreach($datas9[5] as $data9){echo $data9;}?>' />
                            <div class='form-group'>
                                <select name='p6q1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p6q2' class='form-control '>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p6q3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='p6q4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                </div>


        <section>
          <center><label style="color: red ; display: none; font-size: 30px; " id="s1" class="mt-4">No practical subjects for this semester</label></center>
        </section>

                <div class="row">

                   <center><button class="btn-success btn">Submit</button></center>

                </div>

<script type="text/JavaScript">
    function myFunction() {
    var i,l;
    l = <?php echo $count1?>;
    for (i = l+1; i <=6; i++) {
        var j="p"+i.toString();
        console.log(j);
      document.getElementById(j).style.display = "none";

    }

    if(l=='0'){
       document.getElementById('s1').style.display = "block"; 
    }
}
myFunction()
</script>   
    
</form>
</div>

    <div id="3" class="tab-pane fade">
        <form action="libf.php" method="POST">
            <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                <ol >
                    <li>Availability of books set / issue</li>
                    <li>Adequate seating arrangement</li>
                    <li>Digital library/National internal journal</li>
                    <li>Other reading facility</li>  
                </ol>
                </div>
                        <div class='col-md-4 ' id="answers">
                            <div class="fac">
                                <h5>&nbsp;</h5>
                                <h4>&nbsp;</h4>
                            </div>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='libq1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='libq2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='libq3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='libq4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <center><button class="btn-success btn">Submit</button></center>
                        </div>  
        </form>
              

</div>

    <div id="4" class="tab-pane fade">
      <form action="of.php" method="POST">
           <div id="questions" class="col-md-8 questions">
                <h4>Questions</h4>
                    <ol>
                    <li>Conveyence</li>
                    <li>Girl/Boys Room</li>
                    <li>Lift Facilities</li>
                    <li>Classrooms</li>
                    <li>Gymkhana</li>
                    <li>Student Activities</li>
                    <li>Canteen</li>
                    <li>Drinking Water</li>
                    <li>Account section</li>
                    <li>Student Section</li>
                    <li>Internet Facilities</li>
                    <li>Exam Section</li>
                </ol>
                    
                
                </div>
                        <div class='col-md-4' id="answers">
                            <div class="fac">
                                <h5>&nbsp;</h5>
                                <h4>&nbsp;</h4>
                            </div>
                            <input type='hidden' name='fac1' value='6542' />
                            <input type='hidden' name='sub1' value='SE' />
                            <div class='form-group'>
                                <select name='oq1' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='oq2' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='oq3' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='oq4' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='oq5' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='oq6' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='oq7' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='oq8' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='oq9' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='oq10' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='oq11' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='oq12' class='form-control'>
                                    <option value='NULL'>Select one</option>
                                    <option value='5'>5. Excellent</option>
                                    <option value='4'>4. Good</option>
                                    <option value='3'>3. Satisfactory</option>
                                    <option value='2'>2. Average</option>
                                    <option value='1'>1. Needs Improvement</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-10">

                            <center><button class="btn-success btn">Submit</button></center>
                        </div>
      </form> 
    </div>
  </div>
</div>
</body>
</html>