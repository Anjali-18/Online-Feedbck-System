<?php
session_start();
$grno=$_SESSION['grno'];

?>
<!DOCTYPE html>
<html>
<head>
  <title>Information</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <!-- Popper JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
  <header>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College Of Engineering</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="main.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="main.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Student
        </a>
         <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="studinfo.php">Information</a>
          <a class="dropdown-item" href="point1.php">Marks</a>
        </div>
      </li>
   
      <li class="nav-item">
        <a class="nav-link" href="detail.php">Feedback</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.html" style="color: aqua">Log out <?php echo $grno;?></a>
      </li>
     
    </ul>
  </div>
 </nav>
 <!-- navbar end -->
</header>
  <center><h3 style="color:darkgreen;" class="mt-3">Feedback Login</h3></center>
<form  method="POST" autocomplete="off"  action="detail1.php">
  <div class="Container">
    <div class="row mt-5">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      GR NO.:
      <input type="text" name="grno" class="form-control">
    </div>
    </div>

    <div class="row mt-3">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      DEPARTMENT:
      <select name="department" class="form-control" required>
        <option></option>
        <option>COMPUTER</option>
        <option>IT</option>
        <option>CIVIL(FE)</option>
        <option>CIVIL SHIFT-I</option>
        <option>CIVIL SHIFT-II</option>
        <option>MECHANICAL(FE)</option>
        <option>MECHANICAL SHIFT-I</option>
        <option>MECHANICAL SHIFT-II</option>
        <option>AUTOMOBILE</option>
        <option>EXTC</option>
      </select>
    </div>
    </div>

    <div class="row mt-3">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      Academic Year:
      <select class="form-control" name="Adyr">
          <option></option>
         <!--  <option>FE</option> -->
          <option>SE</option>
         <!--  <option>TE</option>
          <option>BE</option> -->
        </select>
    </div>
    </div>

    <div class="row mt-3">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      SEMESTER:
      <select name="sem"  id="selection" class="form-control" required>
        <option value="#">Select Semester</option>
        <option value="3">Sem 3</option>
        <option value="4">Sem 4</option>
      </select>
    </div>
    </div>

    <div class="row mt-3">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      PASSWORD:
      <input type="password" name="password" class="form-control">
    </div>
    </div>

    <div class="row mt-5">
      <div class="col-md-4"></div>
      <div class="col-md-4">
      <center><button type="submit" name="submit" class="btn btn-success form-control">SUBMIT</button>
      </center>
      </div>
    </div>

  </div>

</form>
</body>
</html>


