<?php
	
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";

	$e1=$_POST['e1'];
	$e2=$_POST['e2'];
	$e3=$_POST['e3'];
	$e4=$_POST['e4'];
	$e5=$_POST['e5'];
	$e6=$_POST['e6'];
	$bt=$_POST['bt'];
	$elec=$_POST['elec'];

	/*if($elec==1)
	{
		$e3='none';
		$e4='none';
		$e5='none';
		$e6='none';

	}else if($elec==2)
	{
		$e5='none';
		$e6='none';

	}*/

	session_start();
	$grno=$_SESSION['grno'];
	$name=$_SESSION['name'];
	$sem=$_SESSION['sem'];
	$_SESSION['bt']=$bt;
	$Adyr=$_SESSION['Adyr'];
	//echo $Adyr;
	$division=$_SESSION['division'];
   //echo "$division";
    $SE='SE';
    $TE='TE';
    $BE='BE';
    $A='A';
    $B='B';
    $C='C';

	
	$conn=new mysqli($servername, $username, $password, $dbname);
	if ($conn->connect_error){
		die("Connection failed:" .$conn->connect_error);
	}
	else
	{
			if($SE==$Adyr){
				if($A==$division){
					$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_civila_se where grno='$grno'");
					$row = mysqli_fetch_array($result);
	    			$rno = $row['rno'];


					$sql="insert into elecdetail_civila_se (grno,rno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno', '$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
					if(mysqli_query($conn,$sql))
					{
			 			echo'<script>alert("successfully submitted");
			 			window.location="detail_se.php";
		            	</script>';
			 		}else{
			 			echo'<script>alert("Submission failed, you have already submitted");
			 			window.location="detail_se.php";
		            	</script>';
			 		}
				}else{
					if($B==$division){
							$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_civilb_se where grno='$grno'");
							$row = mysqli_fetch_array($result);
			    			$rno = $row['rno'];

						$sql="insert into elecdetail_civilb_se (grno,rno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno', '$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
						if(mysqli_query($conn,$sql))
						{
				 			echo'<script>alert("successfully submitted");
				 			window.location="detail_se.php";
			            	</script>';
				 		}else{
				 			echo'<script>alert("Submission failed, you have already submitted");
				 			window.location="detail_se.php";
			            	</script>';
				 		}
					}else{
						if($C==$division){
							$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_civilc_se where grno='$grno'");
							$row = mysqli_fetch_array($result);
			    			$rno = $row['rno'];

							$sql="insert into elecdetail_civilc_se (grno,rno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno', '$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
							if(mysqli_query($conn,$sql))
							{
					 			echo'<script>alert("successfully submitted");
					 			window.location="detail_se.php";
				            	</script>';
					 		}else{
					 			echo'<script>alert("Submission failed, you have already submitted");
					 			window.location="detail_se.php";
				            	</script>';
					 		}
						}
					}
				}
			}else{
				if($TE==$Adyr){
					if($A==$division){
						$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_civila_te where grno='$grno'");
						$row = mysqli_fetch_array($result);
		    			$rno = $row['rno'];

					$sql="insert into elecdetail_civila_te (grno,rno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno', '$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
					if(mysqli_query($conn,$sql))
					{
			 			echo'<script>alert("successfully submitted");
			 			window.location="detail_te.php";
		            	</script>';
			 		}else{
			 			echo'<script>alert("Submission failed, you have already submitted");
			 			window.location="detail_te.php";
		            	</script>';
			 		}
				}else{
					if($B==$division){
						$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_civilb_te where grno='$grno'");
						$row = mysqli_fetch_array($result);
		    			$rno = $row['rno'];

						$sql="insert into elecdetail_civilb_te (grno,rno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno', '$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
						if(mysqli_query($conn,$sql))
						{
				 			echo'<script>alert("successfully submitted");
				 			window.location="detail_te.php";
			            	</script>';
				 		}else{
				 			echo'<script>alert("Submission failed, you have already submitted");
				 			window.location="detail_te.php";
			            	</script>';
				 		}
					}else{
						if($C==$division){
							$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_civilc_te where grno='$grno'");
							$row = mysqli_fetch_array($result);
			    			$rno = $row['rno'];

							$sql="insert into elecdetail_civilc_te (grno,rno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno','$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
							if(mysqli_query($conn,$sql))
							{
					 			echo'<script>alert("successfully submitted");
					 			window.location="detail_te.php";
				            	</script>';
					 		}else{
					 			echo'<script>alert("Submission failed, you have already submitted");
					 			window.location="detail_te.php";
				            	</script>';
					 		}
						}
					}
				}
					
				}else{
					if($BE==$Adyr){
						if($A==$division){
							$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_civila_be where grno='$grno'");
							$row = mysqli_fetch_array($result);
			    			$rno = $row['rno'];

					$sql="insert into elecdetail_civila_be (grno,rno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno','$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
					if(mysqli_query($conn,$sql))
					{
			 			echo'<script>alert("successfully submitted");
			 			window.location="detail_be.php";
		            	</script>';
			 		}else{
			 			echo'<script>alert("Submission failed, you have already submitted");
			 			window.location="detail_be.php";
		            	</script>';
			 		}
				}else{
					if($B==$division){
						$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_civilb_be where grno='$grno'");
						$row = mysqli_fetch_array($result);
		    			$rno = $row['rno'];

						$sql="insert into elecdetail_civilb_be (grno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno', '$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
						if(mysqli_query($conn,$sql))
						{
				 			echo'<script>alert("successfully submitted");
				 			window.location="detail_be.php";
			            	</script>';
				 		}else{
				 			echo'<script>alert("Submission failed, you have already submitted");
				 			window.location="detail_be.php";
			            	</script>';
				 		}
					}else{
						if($C==$division){
							$result=mysqli_query($conn,"SELECT rno as rno FROM studinfo_civilc_be where grno='$grno'");
							$row = mysqli_fetch_array($result);
			    			$rno = $row['rno'];

							$sql="insert into elecdetail_civilc_be (grno,rno,name,sem,elec_no,batch,elective_subject1,faculty_name1, elective_subject2,faculty_name2,elective_subject3,faculty_name3) VALUES ('$grno','$rno','$name', '$sem','$elec', '$bt', '$e1', '$e2', '$e3', '$e4', '$e5', '$e6')";
							if(mysqli_query($conn,$sql))
							{
					 			echo'<script>alert("successfully submitted");
					 			window.location="detail_be.php";
				            	</script>';
					 		}else{
					 			echo'<script>alert("Submission failed, you have already submitted");
					 			window.location="detail_be.php";
				            	</script>';
					 		}
						}
					}
				}
					}
				}
			}
	}
	
?>