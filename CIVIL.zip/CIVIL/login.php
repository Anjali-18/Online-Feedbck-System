<?php
error_reporting(0);
$grno = $_POST["grno"];
$pass = $_POST["password"];
$dept = $_POST["department"];
//echo $dept;
$Adyr = $_POST["Adyr"];
$division=$_POST['division'];

session_start();
   $_SESSION['department']="$dept";
   $_SESSION['grno'] = "$grno";
   $_SESSION['division']="$division";
   $_SESSION['Adyr']="$Adyr";
   //echo "$Adyr";

    $CIVIL_SHIFT_I='CIVIL SHIFT-I';
    $CIVIL_SHIFT_II='CIVIL SHIFT-II';
   //$_COOKIE['department'] = $dept;

  
$conn=mysqli_connect("localhost","root","","college"); 
if(!$conn){
    die("connection failed:".mysqli_connect_error());
}
if( $CIVIL_SHIFT_I==$dept){
  $r1=mysqli_query($conn,"SELECT password as password FROM reg_civil1 where grno='$grno'");
  $row = mysqli_fetch_array($r1);
  $password = $row['password'];
  //echo "$password";

  // if(password_verify($pass, $password) ){
  //   echo "hii";
  // }else{
  //   echo"bye";
  // }

}
if($CIVIL_SHIFT_II==$dept){
  $r1=mysqli_query($conn,"SELECT password as password FROM reg_civil2 where grno='$grno'");
  $row = mysqli_fetch_array($r1);
  $password = $row['password'];
 // echo "$password";

  // if(password_verify($pass, $password) ){
  //   echo "hii";
  // }else{
  //   echo"bye";
  // }
}

$sql="select grno,department,year from reg_civil1 where grno='$grno'  and department='$dept' and year='$Adyr'";
//echo $sql;
$result=mysqli_query($conn,$sql);
$sql1="select grno,department,year from reg_civil2 where grno='$grno' and department='$dept' and year='$Adyr'";
$result1=mysqli_query($conn,$sql1);

if((mysqli_num_rows($result)>0 && password_verify($pass, $password)) || (mysqli_num_rows($result1)>0 && password_verify($pass, $password))){
    echo '<script>
             confirm("Login successfully");
             window.location = "main.php";
            </script>
            ';
}else{
    echo'<script>
             alert("Login Failed");
              window.location = "login.html";
        </script>';
}
mysqli_close($conn);

?>

    
