<?php

	$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";

	

	$conn=new mysqli($servername,$username,$password,$dbname); 
	 if($conn->connect_error)
	 {
	 	die("connectivity Error:".$conn->connect_error);
	 }

	if(isset($_POST['register'])){
	session_start();
	// $_SESSION['full_name']=$full_name;

	$full_name=$_POST['full_name'];
	$email=$_POST['email'];
	$id=$_POST['id'];
	$Branch=$_POST['Branch'];
	$Adyr=$_POST['Adyr'];
	$pass=$_POST['confirmPassword'];
	$AUTO='AUTOMOBILE';
	$dept='FE';

	$sql_u= "SELECT* FROM facregi WHERE full_name='$full_name' ";
	/*echo $sql_u;*/
	$sql_e= "SELECT * FROM facregi WHERE email='$email' ";
	$sql_g= "SELECT * FROM facregi WHERE id='$id' ";
	$res_u=mysqli_query($conn, $sql_u);
	$res_e=mysqli_query($conn, $sql_e);
	$res_g=mysqli_query($conn, $sql_g);
	
	if(mysqli_num_rows($res_u)> 0){
		$name_error= "User name already exist... ";
	}
	if(mysqli_num_rows($res_e)> 0){
		$email_error="Email already exiest...";
	}
	if(mysqli_num_rows($res_g)> 0){
		$id_error="id already exist";
	}
	else{
		if($AUTO == $Branch && $dept != $Adyr){
			$sql1="insert into facregi(id,full_name,email,department,password)values('$id','$full_name','$email','$Branch','$Adyr','$pass')";

				 if(mysqli_query($conn,$sql1)){
				 	echo'<script>alert("Registration successfully");
			            window.location = "login.html";
			            </script>';
				 }
				 else
				 {
				 	echo '<script>alert("Registration failed ");
			            window.location = "login.html";
			            </script>';
				 }
		}else{
			echo'<script>alert("You can not register in FE"); window.location="fr1.php";</script>';
		}
	
	}
	}

	 $conn->close();
?>