<?php
$grno = $_POST["grno"];
$pass = $_POST["password"];
$dept = $_POST['Branch'];

$conn=mysqli_connect("localhost","root","","college");
if(!$conn){
    die("connection_failed:".mysqli_connect_error());

}
$r=mysqli_query($conn,"SELECT password as password FROM facregi where id='$grno'");
$row = mysqli_fetch_array($r);
$password = $row['password'];
//echo "$password";
$sec_pass=password_verify($pass, $password);
//echo"$sec_pass";
if(password_verify($pass, $password)){
  echo "hii";
}else{
  echo"bye";
}

$sql="select  id,dept,password from facregi where id='$grno' and dept='$dept'";
$result=mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0 && password_verify($pass, $password)){
    
    echo '<script>
             alert("Login successfully");
             window.location="main1.html";
            </script>
            ';


}else{
    echo'<script>
             alert("Login Failed");
             window.location = "faclogin.html";
        </script>';
}
mysqli_close($conn);
//
//
?>