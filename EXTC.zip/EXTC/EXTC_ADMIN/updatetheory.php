<?php

 include 'conn.php';

 if(isset($_POST['done'])){

 $subject_code = $_GET['subject_code'];
 /*$sem_no=$_POST['sem_no'];
 $subject_name= $_POST['subject_name'];*/
 $faculty_name = $_POST['faculty_name'];

 $query = "SELECT `sem_no` FROM theory_extc WHERE `subject_code` = '$subject_code'";

$res=mysqli_query($conn,$query);
while($row=$res->fetch_assoc()){
	$sem_no = $row ['sem_no'];
	echo $sem_no;
}

 $q = " update theory_extc set faculty_name='$faculty_name' where subject_code='$subject_code' ";
echo $q;
 // $query = mysqli_query($conn,$q);
 // if($conn->connect_error)
	// {
	// 	die("Connectivity Error:".$conn->connect_error);
	// }else {
	// 	echo "connected";
	// }

 // header('location:theory_display.php');
 //}
$query = mysqli_query($conn,$q);
 if(mysqli_query($conn,$q))
 {
 	
	 	switch($sem_no)
		{
			case '3': header('location:theory_display_se.php'); 
						break;
			case '4': header('location:theory_display_se.php'); 
						break;
			case '5': header('location:theory_display_te.php'); 
						break;
			case '6': header('location:theory_display_te.php'); 
						break;
			case '7': header('location:theory_display_be.php'); 
						break;
			case '8': header('location:theory_display_be.php'); 
						break;
		}
 	}else
 	{
 		echo "error";
	 }
	}

?>

<!DOCTYPE html>
<html>
<head>
 <title>Update Theory Subject</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">Update Theory Subject</h1>
 </div><br>

<!--  <label> Sem: </label>
 <input type="text" name="sem_no" class="form-control"> <br>

 <label> Subject_code: </label>
 <input type="text" name="subject_code" class="form-control"> <br>
 <label> Subject_name: </label>
 <input type="text" name="subject_name" class="form-control"> <br> -->
 <label> Faculty_name: </label>
 <input type="text" name="faculty_name" class="form-control"> <br>

 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>

 </div>
 </form>
 </div>
</body>
</html>
