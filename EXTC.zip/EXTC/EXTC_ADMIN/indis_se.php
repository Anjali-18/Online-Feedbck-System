<!DOCTYPE html>
<html>
<head>
	<title>SE EXTC - Student Information</title>

	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<!-- Bootnavbar.css -->
<link href="css/bootnavbar.css" rel="stylesheet">

<style type="text/css">
	.colr{
		color: yellow;
	}
	.co{
		color: blue;
	}
</style>

</head>
<body>
<!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark" id="main_navbar">
  <a class="navbar-brand" href="#" style="color: yellow;">Saraswati College of Engineering</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">

                <!-- HOME  -->
                <li class="nav-item active">
                    <a class="nav-link" href="main1.html">Home <span class="sr-only">(current)</span></a>
                </li>
                <!-- STUDENT -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        Student
                    </a>

                    <!-- STUDENT MARKS -->
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student Marks
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="dispoint_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="dispoint_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="dispoint_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                            <!-- STUDENT INFORMATION -->

                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Student information
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="indis_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="indis_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="indis_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                    </ul>
                    <!-- SUBJECT -->
    <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Subject
            </a>
         
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        
                        <!-- THEORY SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Theory Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="theory_display_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="theory_display_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="theory_display_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                        <!-- Elective SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Elective Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayelec_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="displayelec_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="displayelec_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
                        <!-- PRACTICAL SUBJECTS -->
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    Practical Subjects
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <li><a class="dropdown-item" href="displayprac_se.php">SE</a></li>
                                    <li><a class="dropdown-item" href="displayprac_te.php">TE</a></li>
                                    <li><a class="dropdown-item" href="displayprac_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                            </li>
            </ul>
      </li>

      <!--Elective Details  -->
       <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Elective Details
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">SE</a>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">TE</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="diselecdetail_be.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">BE</a>  
                        </li>
            </ul>
      </li>

      <!-- FEEDBACK -->
      <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Feedback
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Theory</a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="tft_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="tft_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="tft_be.php">BE</a></li>
                                    
                                    </li>
                                </ul>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item dropdown-toggle" href="eligible_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Practical</a> 
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li><a class="dropdown-item" href="pft_se.php">SE</a></li>
                                        <li><a class="dropdown-item" href="pft_te.php">TE</a></li>
                                        <li><a class="dropdown-item" href="pft_be.php">BE</a></li>
                                    
                                    </li>
                                </ul> 
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="lfb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Library</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="ofb.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">Other Facilities</a>  
                        </li>
            </ul>
      </li>

      <!-- ELIGIBILITY -->
       <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Eligibility
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_se.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">SE</a>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_te.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">TE</a>  
                        </li>
                        <li class="nav-item dropdown">
                                <a class="dropdown-item " href="eligible_be.php" id="navbarDropdown1" role="button" aria-haspopup="true" aria-expanded="false">BE</a>  
                        </li>
            </ul>
      </li>
    <!-- LOG OUT -->
      <li class="nav-item">
        <a class="nav-link" href="faclogin.html" style="color: aqua;">Log out</a>
      </li>
                    
                       
 </ul>        
        </div>
    </nav>

 <!-- navbar end -->
	<div>
		<h3 class="mt-5 text-center bg-dark text colr">SE EXTC - STUDENT INFORMATION</h3>
		<br>
		<!-- <button id="displayinfo" class="btn btn-danger">Display</button>

 -->
		<table class="table table-striped table-bordered text-center">
			<thead>
                <th class="co">ID</th>
				<th class="co">GR NO.</th>
				<th class="co">Name</th>
                <th class="co">Roll NO</th>
                <th class="co">Status</th>
				<th class="co">phone NO</th>
				<th class="co">Admission yr</th>
				<th class="co">DOB</th>
				<!-- <th class="co">Age</th> -->
				<th class="co">Dept</th>
				<th class="co">Bloodgp</th>
				<th class="co">caste</th>
				<th class="co">Subcaste</th>
                <th class="co">Delete</th>
			</thead>
			<tbody id="response">
				
			</tbody>
		</table>
		<div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-2">
            <button class="btn btn-success" onclick="window.location.href ='info_se.php';">Export To Excel</button>
            </div>
            <div class="col-md-2">
            <form method="POST">
                <button class="btn btn-success" name="truncatetable">Delete All Records</button>
                        <?php
                            include('conn.php');

                                if(isset($_POST['truncatetable']))
                                {
                                    $sql1="TRUNCATE TABLE studinfo_extc_se";
                                    if(mysqli_query($conn,$sql1))
                                    {
                                        echo "<script>
                                                alert(window.location.href ='main1.html')
                                        </script>";
                                    }else
                                    {
                                        echo "not truncate"; 
                                    }
                                 }

                            ?>
            </form>
            </div>
        </div>
    </div>

	<script type="text/javascript">
		$(document).ready(function(){
			var from=$('#myform');
			$('#submit').click(function(){
				$.ajax(
				{
					url:from.attr("action"),
					type:'post',
					data:$("#myform input").serialize(),

					success:function(data){
						console.log(data);
					}

				});
			});
		

			Display();
		/*$('#displayinfo').click(function(){*/
			function Display(){
			$.ajax({
				url:'displayinfo_se.php',
				type:'post',

				success:function(responsedata){
					$('#response').html(responsedata);
				}
			});
		}
		/*});*/
	});

	</script>
	  <!-- Js for Navbar, Multi-level dropdown -->
  <script src="js/bootnavbar.js" ></script>
    <script>
        $(function () {
            $('#main_navbar').bootnavbar({
                //option
                //animation: false
            });
        })
    </script>

</body>
</html>