
<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="college";

	$name=$_POST['name']; 
	//echo $name;
	$grno=$_POST['grno'];
	$phone=$_POST['phone'];
	$Adyr=$_POST['Adyr'];
	$DOB=$_POST['DOB'];
	$rno=$_POST['rno'];
	$sts=$_POST['sts'];
	$division=$_POST['division'];     
	$dept=$_POST['dept'];
	$blogp=$_POST['blogp'];
	$caste=$_POST['caste'];
	$subcaste=$_POST['subcaste'];
	$SE='SE';
	$TE='TE';
	$BE='BE';
	
	session_start();
   	$_SESSION['name'] = "$name";
   	$_SESSION['rno']=$rno;
   	
   	$conn=new mysqli($servername,$username,$password,$dbname);
   //	echo "connected";
	if($conn->connect_error)
	{
		die("Connectivity Error:".$conn->connect_error);
	}
	else
	{
		if($SE==$Adyr){
						$result=mysqli_query($conn,"SELECT max(`id`) as id FROM studinfo_extc_se");
					 		 
					 	$row = mysqli_fetch_array($result);
    					$id = $row['id'];
    					$id=$id+1;

					 	$sql="INSERT INTO studinfo_extc_se (`id`, `grno`, `name`, `rno`, `sts`, `phone`, `Adyr`, `DOB`, `division`, `dept`, `blogp`, `caste`, `subcaste` ) VALUES ('$id', '$grno', '$name', '$rno', '$sts', '$phone', '$Adyr', '$DOB', '$division', '$dept', '$blogp', '$caste', '$subcaste');";
						echo $sql;
						if(mysqli_query($conn,$sql) or die(mysqli_error($conn)))
						{
							echo'<script>alert("successfully submitted");
							 	window.location = "point.html";
						         </script>';
						}
						else
						{
							echo '<script>alert("Already Submitted");
						    window.location = "point.html";
						    </script>';
							 	
						}
			 }else{
			 	if($TE==$Adyr){
			 				$result=mysqli_query($conn,"SELECT max(`id`) as id FROM studinfo_extc_te");
					 		$row = mysqli_fetch_array($result);
    						$id = $row['id'];
    						$id=$id+1;

					 		$sql="INSERT INTO studinfo_extc_te (`id`, `grno`, `name`, `rno`, `sts`, `phone`, `Adyr`, `DOB`, `division`, `dept`, `blogp`, `caste`, `subcaste` ) VALUES ('$id', '$grno', '$name', '$rno', '$sts', '$phone', '$Adyr', '$DOB', '$division', '$dept', '$blogp', '$caste', '$subcaste');";
								echo $sql;
								if(mysqli_query($conn,$sql) or die(mysqli_error($conn)))
								{
									echo'<script>alert("successfully submitted");
							 		 window.location = "point.html";
						            </script>';
							 	}
								 else
							 	{
							 		echo '<script>alert("Already Submitted");
						            window.location = "point.html";
						            </script>';
							 	
							 	}
					 }else{
					 	if ($BE==$Adyr) {

					 		$result=mysqli_query($conn,"SELECT max(`id`) as id FROM studinfo_extc_be");
					 		$row = mysqli_fetch_array($result);
    						$id = $row['id'];
    						$id=$id+1;

					 		$sql="INSERT INTO studinfo_extc_be (`id`, `grno`, `name`, `rno`, `sts`, `phone`, `Adyr`, `DOB`, `division`, `dept`, `blogp`, `caste`, `subcaste` ) VALUES ('$id', '$grno', '$name', '$rno', '$sts', '$phone', '$Adyr', '$DOB', '$division', '$dept', '$blogp', '$caste', '$subcaste');";
								echo $sql;
								if(mysqli_query($conn,$sql) or die(mysqli_error($conn)))
								{
									echo'<script>alert("successfully submitted");
							 		 window.location = "point.html";
						            </script>';
							 	}
								 else
							 	{
							 		echo '<script>alert("Already Submitted");
						            window.location = "point.html";
						            </script>';
							 	
							 	}
					 		}
						}	
			 		}
	 	
	}

	$conn->close();
?>
